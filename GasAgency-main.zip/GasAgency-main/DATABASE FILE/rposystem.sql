-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 24, 2025 at 05:29 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rposystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `delivery_schedule`
--

CREATE TABLE `delivery_schedule` (
  `id` int(11) NOT NULL,
  `district` varchar(50) NOT NULL,
  `outlet_name` varchar(100) NOT NULL,
  `first_delivery_date` date NOT NULL,
  `second_delivery_date` date NOT NULL,
  `third_delivery_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `delivery_schedule`
--

INSERT INTO `delivery_schedule` (`id`, `district`, `outlet_name`, `first_delivery_date`, `second_delivery_date`, `third_delivery_date`, `created_at`) VALUES
(1, 'Kandy', 'Blueflam Kandy', '2025-01-01', '2025-01-16', '2025-01-30', '2025-01-23 15:45:35'),
(5, 'Kandy', 'Blueflam Kandy', '2025-02-01', '2025-02-06', '2025-02-20', '2025-01-23 16:13:52');

-- --------------------------------------------------------

--
-- Table structure for table `outlets`
--

CREATE TABLE `outlets` (
  `id` int(11) NOT NULL,
  `district` varchar(100) NOT NULL,
  `outlet_name` varchar(255) NOT NULL,
  `outletmanager` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `outlets`
--

INSERT INTO `outlets` (`id`, `district`, `outlet_name`, `outletmanager`) VALUES
(1, 'Kandy', 'Blueflam Kandy', 4),
(2, 'Gampaha', 'Blueflam 2', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `outlet_staff`
--

CREATE TABLE `outlet_staff` (
  `staff_id` int(20) NOT NULL,
  `staff_number` varchar(200) NOT NULL,
  `staff_name` varchar(200) NOT NULL,
  `staff_email` varchar(200) NOT NULL,
  `staff_password` varchar(200) NOT NULL,
  `staff_country` varchar(100) NOT NULL,
  `staff_city` varchar(100) NOT NULL,
  `staff_mobile` varchar(15) NOT NULL,
  `staff_address` varchar(255) NOT NULL,
  `staff_join_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `district` varchar(255) NOT NULL,
  `outlet_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `outlet_staff`
--

INSERT INTO `outlet_staff` (`staff_id`, `staff_number`, `staff_name`, `staff_email`, `staff_password`, `staff_country`, `staff_city`, `staff_mobile`, `staff_address`, `staff_join_date`, `created_at`, `district`, `outlet_name`) VALUES
(1, 'FGAX-4718', 'ilma', 'ilma@gmail.com', 'adcd7048512e64b48da55b027577886ee5a36350', 'Sri Lanka', 'Colombo', '0725227908', 'Colombo', '2025-01-01', '2025-01-11 13:13:31', 'Kandy', 'Blueflam Kandy'),
(2, 'GQHP-8624', 'jone', 'jone@gmail.com', '63982e54a7aeb0d89910475ba6dbd3ca6dd4e5a1', 'Sri Lanka', 'Kamdy', '0725227908', 'kandy', '2025-01-13', '2025-01-13 17:24:07', 'Gampaha', 'Blueflam 2'),
(4, 'TASJ-9546', 'shakeebarsalan', 'shakeeb9809@gmail.com', '63982e54a7aeb0d89910475ba6dbd3ca6dd4e5a1', 'Sri Lanka', 'Colombo', '0725227908', 'Colombo', '2025-01-14', '2025-01-14 05:54:55', 'Gampaha', 'Blueflam 2'),
(5, 'YSHC-9857', 'jonewike', 'jonewike@gmail.com', 'adcd7048512e64b48da55b027577886ee5a36350', 'Sri Lanka', 'Colombo', '0725227908', 'Colombo', '2025-01-24', '2025-01-24 15:24:01', 'Kandy', 'Blueflam Kandy');

-- --------------------------------------------------------

--
-- Table structure for table `refill_requests`
--

CREATE TABLE `refill_requests` (
  `id` int(11) NOT NULL,
  `manager_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `created_date` datetime DEFAULT current_timestamp(),
  `category` varchar(255) NOT NULL,
  `refill_qty` int(11) NOT NULL,
  `outlet_district` varchar(255) NOT NULL,
  `outlet_name` varchar(255) NOT NULL,
  `expected_delivery_date` date NOT NULL,
  `status` varchar(50) DEFAULT 'Pending',
  `isnotification` tinyint(1) NOT NULL DEFAULT 0,
  `scheduled_date` date DEFAULT NULL,
  `isapproved_by_outlet_manager` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `refill_requests`
--

INSERT INTO `refill_requests` (`id`, `manager_id`, `description`, `created_date`, `category`, `refill_qty`, `outlet_district`, `outlet_name`, `expected_delivery_date`, `status`, `isnotification`, `scheduled_date`, `isapproved_by_outlet_manager`) VALUES
(1, 4, 'New Request', '2025-01-07 21:33:13', 'LPG 12.5 kg', 10, 'Kandy', 'Blueflam Kandy', '2025-01-31', 'Approved', 0, '2025-01-30', 0),
(2, 4, 'New Request 2', '2025-01-07 21:35:01', 'LPG 35 kg', 2, 'Kandy', 'Blueflam Kandy', '2025-01-31', 'Approved', 0, '2025-01-16', 0),
(3, 4, 'New Request catagory', '2025-01-24 14:34:43', 'LPG 35 kg', 20, 'Kandy', 'Blueflam Kandy', '2025-01-24', 'Hold', 0, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `refill_requests_customer`
--

CREATE TABLE `refill_requests_customer` (
  `request_id` int(11) NOT NULL,
  `customer_id` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(255) NOT NULL,
  `refill_qty` int(11) NOT NULL,
  `outlet_district` varchar(255) NOT NULL,
  `outlet_name` varchar(255) NOT NULL,
  `expected_delivery_date` date NOT NULL,
  `status` varchar(50) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `isnotification` tinyint(1) NOT NULL DEFAULT 0,
  `request_type` varchar(255) NOT NULL,
  `AssignCylinder` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `refill_requests_customer`
--

INSERT INTO `refill_requests_customer` (`request_id`, `customer_id`, `description`, `category`, `refill_qty`, `outlet_district`, `outlet_name`, `expected_delivery_date`, `status`, `created_at`, `updated_at`, `isnotification`, `request_type`, `AssignCylinder`) VALUES
(2, 'C001', 'New Request 2', 'LPG 35 kg', 1, 'Kandyy', 'Blueflam Kandy', '2025-01-31', 'Pending', '2025-01-13 03:46:18', '2025-01-24 15:07:47', 0, 'Industrial Customer', 0),
(3, '59f45c203a63', 'Customer New Request 3', 'LPG 5 kg', 1, 'Kandy', 'Blueflam Kandy', '2025-01-31', 'Pending', '2025-01-13 03:54:11', '2025-01-24 15:08:07', 0, 'Industrial Customer', 0),
(4, '59f45c203a63', 'Customer New Request 4', 'LPG 5 kg', 1, 'Kandy', 'Blueflam Kandy', '2025-01-30', 'Pending', '2025-01-13 03:54:44', '2025-01-24 15:08:09', 0, 'Industrial Customer', 0),
(5, 'C001', 'Customer New Request 5', 'LPG 5 kg', 1, 'Kandy', 'Blueflam Kandy', '2025-01-02', 'Pending', '2025-01-13 03:56:44', '2025-01-24 15:07:53', 0, 'Industrial Customer', 0),
(9, 'ee4cb173f433', 'Customer New Request 7', 'LPG 5 kg', 1, 'Kandy ', 'Blueflam Kandy ', '2025-01-30', 'Pending', '2025-01-13 04:11:29', '2025-01-24 15:06:21', 0, 'Industrial Customer', 0),
(10, '59f45c203a63', 'Customer New Request 7', 'LPG 5 kg', 1, 'Kandy ', 'Blueflam Kandy ', '2025-01-31', 'Approved', '2025-01-13 04:13:15', '2025-01-24 15:08:13', 0, 'Industrial Customer', 0),
(11, '95d0c56ff0d4', 'Customer New Request 8', 'LPG 12.5 kg', 1, 'colombo', 'Blueflam colombo', '2025-01-30', 'Rejected', '2025-01-13 04:20:36', '2025-01-24 13:57:56', 0, 'Industrial Customer', 0),
(12, 'ee4cb173f433', NULL, 'LPG 12.5 kg', 1, 'Gampaha', 'Blueflam 2', '2025-01-23', 'Ready To Deliver', '2025-01-22 18:01:10', '2025-01-24 15:08:34', 0, 'Industrial Customer', 1),
(13, 'ee4cb173f433', NULL, 'LPG 5 kg', 1, 'Gampaha', 'Blueflam 2', '2025-01-17', 'Pending', '2025-01-22 18:16:48', '2025-01-24 15:08:32', 0, 'Industrial Customer', 0);

-- --------------------------------------------------------

--
-- Table structure for table `rpos_aadmin`
--

CREATE TABLE `rpos_aadmin` (
  `aadmin_id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_number` varchar(100) NOT NULL,
  `admin_mail` varchar(100) NOT NULL,
  `admin_password` varchar(100) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rpos_aadmin`
--

INSERT INTO `rpos_aadmin` (`aadmin_id`, `admin_name`, `admin_number`, `admin_mail`, `admin_password`, `created_at`) VALUES
(8, 'Ilham', 'WXYZ-9580', 'Ilham@gmail.com', 'b2026d922e8dbebda52bd76aba885ee0d416c20e', '2025-01-04 06:05:02.085965');

-- --------------------------------------------------------

--
-- Table structure for table `rpos_admin`
--

CREATE TABLE `rpos_admin` (
  `admin_id` varchar(200) NOT NULL,
  `admin_name` varchar(200) NOT NULL,
  `admin_email` varchar(200) NOT NULL,
  `admin_password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rpos_admin`
--

INSERT INTO `rpos_admin` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
('10e0b6dc958adfb5b094d8935a13aeadbe783c25', 'System Admin', 'admin@gmail.com', '903b21879b4a60fc9103c3334e4f6f62cf6c3a2d');

-- --------------------------------------------------------

--
-- Table structure for table `rpos_complaints`
--

CREATE TABLE `rpos_complaints` (
  `complaint_id` int(11) NOT NULL,
  `customer_id` varchar(200) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `create_date` date NOT NULL,
  `outlet_name` varchar(255) NOT NULL,
  `complaint_text` text NOT NULL,
  `isnotification` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rpos_complaints`
--

INSERT INTO `rpos_complaints` (`complaint_id`, `customer_id`, `customer_name`, `create_date`, `outlet_name`, `complaint_text`, `isnotification`) VALUES
(1, '59f45c203a63', 'ilma', '2025-01-01', 'Blueflam Kandy', 'This branch take too long to refill gas', 0);

-- --------------------------------------------------------

--
-- Table structure for table `rpos_customers`
--

CREATE TABLE `rpos_customers` (
  `customer_id` varchar(200) NOT NULL,
  `customer_name` varchar(200) NOT NULL,
  `customer_phoneno` varchar(200) NOT NULL,
  `customer_email` varchar(200) NOT NULL,
  `customer_password` varchar(200) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `customer_nic` varchar(20) NOT NULL,
  `customer_dob` date DEFAULT NULL,
  `customer_address` varchar(255) NOT NULL,
  `outletid` int(11) DEFAULT NULL,
  `customer_typ` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rpos_customers`
--

INSERT INTO `rpos_customers` (`customer_id`, `customer_name`, `customer_phoneno`, `customer_email`, `customer_password`, `created_at`, `customer_nic`, `customer_dob`, `customer_address`, `outletid`, `customer_typ`) VALUES
('59f45c203a63', 'ilma', '0725227908', 'ilma123@gmail.com', 'adcd7048512e64b48da55b027577886ee5a36350', '2025-01-22 17:47:59.761087', '200012323212', '2025-01-01', 'Colombo', 2, 'Industrial Customer'),
('C001', 'John Doe', '1234567890', 'johndoe@example.com', '92ac0281d4695ec3710f690e029a6320ca7e5244', '2025-01-22 17:42:47.759964', '123456789V', '1985-04-15', '123 Street, City', 1, 'Industrial Customer'),
('ee4cb173f433', 'jhone', '0763364865', 'ilham@gmail.com', 'adcd7048512e64b48da55b027577886ee5a36350', '2025-01-22 16:54:40.464554', '', NULL, '', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `rpos_orders`
--

CREATE TABLE `rpos_orders` (
  `order_id` varchar(200) NOT NULL,
  `order_code` varchar(200) NOT NULL,
  `customer_id` varchar(200) NOT NULL,
  `customer_name` varchar(200) NOT NULL,
  `prod_id` varchar(200) NOT NULL,
  `prod_name` varchar(200) NOT NULL,
  `prod_price` varchar(200) NOT NULL,
  `prod_qty` varchar(200) NOT NULL,
  `order_status` varchar(200) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `isnotification` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rpos_orders`
--

INSERT INTO `rpos_orders` (`order_id`, `order_code`, `customer_id`, `customer_name`, `prod_id`, `prod_name`, `prod_price`, `prod_qty`, `order_status`, `created_at`, `isnotification`) VALUES
('0f79c7b763', 'CKPH-6482', '95d0c56ff0d4', 'ilma', '3d5c6d7750', '12.5 Kg Litro Gas', '4050.00', '2', '', '2025-01-14 12:37:29.837133', 0),
('2839b3734c', 'SWYE-1629', '95d0c56ff0d4', 'ilma', '3d5c6d7750', '12.5 Kg Litro Gas', '4050.00', '2', '', '2025-01-14 12:35:43.396808', 0),
('496de6092e', 'YSWI-7564', '95d0c56ff0d4', 'ilma', '3d5c6d7750', '12.5 Kg Litro Gas', '4050.00', '2', '', '2025-01-14 12:27:49.437041', 0),
('4bcdfd197a', '95', '95d0c56ff0d4', 'MOHAMED ILHAM', '3d5c6d7750', '12.5 Kg Litro Gas', '4050.00', '5', 'Paid', '2025-01-13 11:17:48.770003', 0),
('5827819045', 'AWFJ-1406', '95d0c56ff0d4', 'ilma', '7af4a4c4f2', '15 Kg Litro Gas', '4500', '4', '', '2025-01-14 13:19:40.604993', 0),
('586c4930c1', 'XADZ-2568', '6ad86fd69944', 'MOHAMED ILHAM', '3d5c6d7750', '12.5 Kg Litro Gas', '4050.00', '2', 'Paid', '2025-01-06 09:49:50.255754', 0),
('6a31e4c17f', 'ZSYB-7813', '95d0c56ff0d4', 'ilma', '3d5c6d7750', '12.5 Kg Litro Gas', '4050.00', '2', '', '2025-01-14 12:37:01.591833', 0),
('6b83f2058f', 'MFWD-3087', '95d0c56ff0d4', 'ilma', '3d5c6d7750', '12.5 Kg Litro Gas', '4050.00', '2', '', '2025-01-14 12:36:19.909693', 0),
('82e172bfab', 'MFCQ-8293', '95d0c56ff0d4', 'ilma', '3d5c6d7750', '12.5 Kg Litro Gas', '4050.00', '2', '', '2025-01-13 10:16:09.300497', 0),
('84e41012ae', '98', '95d0c56ff0d4', 'ilma', '3d5c6d7750', '12.5 Kg Litro Gas', '4050.00', '3', '', '2025-01-13 11:13:00.936452', 0),
('85c1d165ba', 'CQKS-9718', '95d0c56ff0d4', 'ilma', '3d5c6d7750', '12.5 Kg Litro Gas', '4050.00', '2', '', '2025-01-13 11:11:46.227110', 0),
('a513933f30', 'RTOZ-9384', '95d0c56ff0d4', 'ilma', '3d5c6d7750', '12.5 Kg Litro Gas', '4050.00', '2', '', '2025-01-14 13:19:47.087753', 0),
('b20eb060aa', 'RFJD-8297', '95d0c56ff0d4', 'ilma', '3d5c6d7750', '12.5 Kg Litro Gas', '4050.00', '4', '', '2025-01-14 12:27:06.316754', 0),
('d25eab0924', 'UOAH-6984', '95d0c56ff0d4', 'ilma', '3d5c6d7750', '12.5 Kg Litro Gas', '4050.00', '2', '', '2025-01-14 12:39:00.366356', 0);

-- --------------------------------------------------------

--
-- Table structure for table `rpos_pass_resets`
--

CREATE TABLE `rpos_pass_resets` (
  `reset_id` int(20) NOT NULL,
  `reset_code` varchar(200) NOT NULL,
  `reset_token` varchar(200) NOT NULL,
  `reset_email` varchar(200) NOT NULL,
  `reset_status` varchar(200) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rpos_pass_resets`
--

INSERT INTO `rpos_pass_resets` (`reset_id`, `reset_code`, `reset_token`, `reset_email`, `reset_status`, `created_at`) VALUES
(1, '63KU9QDGSO', '4ac4cee0a94e82a2aedc311617aa437e218bdf68', 'sysadmin@icofee.org', 'Pending', '2020-08-17 15:20:14.318643');

-- --------------------------------------------------------

--
-- Table structure for table `rpos_payments`
--

CREATE TABLE `rpos_payments` (
  `pay_id` varchar(200) NOT NULL,
  `pay_code` varchar(200) NOT NULL,
  `order_code` varchar(200) NOT NULL,
  `customer_id` varchar(200) NOT NULL,
  `pay_amt` varchar(200) NOT NULL,
  `pay_method` varchar(200) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `isnotification` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rpos_payments`
--

INSERT INTO `rpos_payments` (`pay_id`, `pay_code`, `order_code`, `customer_id`, `pay_amt`, `pay_method`, `created_at`, `isnotification`) VALUES
('337bf8', 'RO56QCGSUI', '95', '95d0c56ff0d4', '20250', 'Paypal', '2025-01-13 16:47:48.767475', 0),
('7593c3', 'S1BCNEAVO5', 'XADZ-2568', '6ad86fd69944', '8100', 'Card', '2025-01-06 15:19:50.254037', 0);

-- --------------------------------------------------------

--
-- Table structure for table `rpos_products`
--

CREATE TABLE `rpos_products` (
  `prod_id` varchar(200) NOT NULL,
  `prod_code` varchar(200) NOT NULL,
  `prod_name` varchar(200) NOT NULL,
  `prod_img` varchar(200) NOT NULL,
  `prod_desc` longtext NOT NULL,
  `prod_price` varchar(200) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `prod_qty` int(11) NOT NULL,
  `prod_category` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rpos_products`
--

INSERT INTO `rpos_products` (`prod_id`, `prod_code`, `prod_name`, `prod_img`, `prod_desc`, `prod_price`, `created_at`, `prod_qty`, `prod_category`) VALUES
('3d5c6d7750', 'QIGL-2075', '12.5 Kg Litro Gas', 'gas12.5k.png', 'LITRO REGULAR\r\nLitro Regular contains 12.5kg LP Gas. Good enough for an Extended family.', '4050.00', '2025-01-24 14:37:55.405514', 69, 'LPG 12.5 kg'),
('7af4a4c4f2', 'GCKM-7328', '15 Kg Litro Gas', 'gas12.5k.png', 'new 15 Kg Litro Gas', '4500', '2025-01-14 18:49:40.603092', 46, 'LPG 15 kg');

-- --------------------------------------------------------

--
-- Table structure for table `rpos_staff`
--

CREATE TABLE `rpos_staff` (
  `staff_id` int(20) NOT NULL,
  `staff_name` varchar(200) NOT NULL,
  `staff_number` varchar(200) NOT NULL,
  `staff_email` varchar(200) NOT NULL,
  `staff_password` varchar(200) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `staff_country` varchar(255) DEFAULT NULL,
  `staff_city` varchar(255) DEFAULT NULL,
  `staff_mobile` varchar(20) DEFAULT NULL,
  `staff_address` text DEFAULT NULL,
  `staff_join_date` date DEFAULT NULL,
  `ismanagerassigned` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rpos_staff`
--

INSERT INTO `rpos_staff` (`staff_id`, `staff_name`, `staff_number`, `staff_email`, `staff_password`, `created_at`, `staff_country`, `staff_city`, `staff_mobile`, `staff_address`, `staff_join_date`, `ismanagerassigned`) VALUES
(3, 'insath', 'FOND-1327', 'insath@gmail.com', '12345', '2025-01-06 14:45:15.763396', 'Sri Lanka', 'Kamdy', '0725227908', 'kandy', '2025-01-01', 0),
(4, 'Shakeeb', 'IARK-8410', 'Shakeeb@gmail.com', 'adcd7048512e64b48da55b027577886ee5a36350', '2025-01-21 16:53:38.366331', 'Sri Lanka', 'Colombo', '0725227908', 'Colombo', '2024-01-01', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `delivery_schedule`
--
ALTER TABLE `delivery_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `outlets`
--
ALTER TABLE `outlets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `outlet_staff`
--
ALTER TABLE `outlet_staff`
  ADD PRIMARY KEY (`staff_id`);

--
-- Indexes for table `refill_requests`
--
ALTER TABLE `refill_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `refill_requests_customer`
--
ALTER TABLE `refill_requests_customer`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `rpos_aadmin`
--
ALTER TABLE `rpos_aadmin`
  ADD PRIMARY KEY (`aadmin_id`);

--
-- Indexes for table `rpos_admin`
--
ALTER TABLE `rpos_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `rpos_complaints`
--
ALTER TABLE `rpos_complaints`
  ADD PRIMARY KEY (`complaint_id`);

--
-- Indexes for table `rpos_customers`
--
ALTER TABLE `rpos_customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `rpos_pass_resets`
--
ALTER TABLE `rpos_pass_resets`
  ADD PRIMARY KEY (`reset_id`);

--
-- Indexes for table `rpos_payments`
--
ALTER TABLE `rpos_payments`
  ADD PRIMARY KEY (`pay_id`),
  ADD KEY `order` (`order_code`);

--
-- Indexes for table `rpos_products`
--
ALTER TABLE `rpos_products`
  ADD PRIMARY KEY (`prod_id`);

--
-- Indexes for table `rpos_staff`
--
ALTER TABLE `rpos_staff`
  ADD PRIMARY KEY (`staff_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `delivery_schedule`
--
ALTER TABLE `delivery_schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `outlets`
--
ALTER TABLE `outlets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `outlet_staff`
--
ALTER TABLE `outlet_staff`
  MODIFY `staff_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `refill_requests`
--
ALTER TABLE `refill_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `refill_requests_customer`
--
ALTER TABLE `refill_requests_customer`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `rpos_aadmin`
--
ALTER TABLE `rpos_aadmin`
  MODIFY `aadmin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `rpos_complaints`
--
ALTER TABLE `rpos_complaints`
  MODIFY `complaint_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `rpos_pass_resets`
--
ALTER TABLE `rpos_pass_resets`
  MODIFY `reset_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `rpos_staff`
--
ALTER TABLE `rpos_staff`
  MODIFY `staff_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
