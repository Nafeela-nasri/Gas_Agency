<?php
session_start();
unset($_SESSION['customer_id']);
session_destroy();
header("location:http://localhost/GasAgency/GasAgency/GAMS/admin/index.php");
exit;
