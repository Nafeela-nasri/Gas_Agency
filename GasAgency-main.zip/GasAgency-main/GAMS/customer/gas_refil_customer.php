<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();

if (!isset($_SESSION['customer_id'])) {
    die("Unauthorized access! Please log in.");
}

$staff_id = $_SESSION['customer_id'];
// Check if there is an existing refill request for the current month
$currentMonth = date('Y-m'); // Format as YYYY-MM
$checkQuery = "SELECT COUNT(*) AS request_count FROM refill_requests_customer 
               WHERE customer_id = ? AND DATE_FORMAT(expected_delivery_date, '%Y-%m') = ?";
$stmt = $mysqli->prepare($checkQuery);
$stmt->bind_param('is', $staff_id, $currentMonth);
$stmt->execute();
$stmt->bind_result($requestCount);
$stmt->fetch();
$stmt->close();

// Delete Refill Request
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $adn = "DELETE FROM refill_requests_customer WHERE request_id = ? AND customer_id = ?";
    $stmt = $mysqli->prepare($adn);
    $stmt->bind_param('ii', $id, $staff_id);
    $result = $stmt->execute();
    $stmt->close();

    if ($result) {
        // Success message and redirect
        echo "<script>
                window.location.href = 'gas_refil_customer.php';
              </script>";
    } else {
        echo "<script>alert('$err');</script>";
    }
}

require_once('partials/_head.php');
?>

<body>
    <!-- Sidenav -->
    <?php
    require_once('partials/_sidebar.php');
    ?>
    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php
        require_once('partials/_topnav.php');
        ?>
        <!-- Header -->
        <div style="background-image: url(../admin/assets/img/theme/restro00.jpg); background-size: cover;" class="header pb-8 pt-5 pt-md-8">
            <span class="mask bg-gradient-dark opacity-8"></span>
            <div class="container-fluid">
                <div class="header-body"></div>
            </div>
        </div>
        <!-- Page content -->
        <div class="container-fluid mt--8">
            <!-- Table -->
            <div class="row">
                <div class="col">
                    <div class="card shadow">
                        <div class="card-header border-0">
                            <a href="javascript:void(0)" onclick="validateRefillRequest()" class="btn btn-outline-success">
                                <i class="fas fa-plus"></i>
                                Add New Refill Request
                            </a>
                        </div>
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col">Request ID</th>
                                        <th scope="col">Customer Name</th>
                                        <th scope="col">Request Type</th>
                                        <th scope="col">Category</th>
                                        <th scope="col">Outlet District</th>
                                        <th scope="col">Outlet Name</th>
                                        <th scope="col">Expected Delivery</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $ret = "SELECT rr.*, rs.customer_name 
                                            FROM refill_requests_customer rr 
                                            INNER JOIN rpos_customers rs 
                                            ON rr.customer_id = rs.customer_id 
                                            WHERE rr.customer_id = ? ";
                                    $stmt = $mysqli->prepare($ret);
                                    $stmt->bind_param('i', $staff_id);
                                    $stmt->execute();
                                    $res = $stmt->get_result();
                                    while ($request = $res->fetch_object()) {
                                    ?>
                                        <tr>
                                            <td><?php echo $request->request_id; ?></td>
                                            <td><?php echo $request->customer_name; ?></td>
                                            <td><?php echo $request->request_type; ?></td>
                                            <td><?php echo $request->category; ?></td>
                                            <td><?php echo $request->outlet_district; ?></td>
                                            <td><?php echo $request->outlet_name; ?></td>
                                            <td><?php echo $request->expected_delivery_date; ?></td>
                                            <td>
                                                <?php
                                                if ($request->status == 'Pending') {
                                                    echo '<span class="badge badge-warning">Pending</span>';
                                                } elseif ($request->status == 'Approved') {
                                                    echo '<span class="badge badge-success">Approved</span>';
                                                } elseif ($request->status == 'Rejected') {
                                                    echo '<span class="badge badge-danger">Rejected</span>';
                                                } elseif  ($request->status == 'Ready To Deliver')  {
                                                    echo '<span class="badge badge-success">Ready To Deliver</span>';
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <a href="update_refill_request.php?update=<?php echo $request->request_id; ?>">
                                                    <button class="btn btn-sm btn-primary">
                                                        <i class="fas fa-edit"></i>
                                                        Update
                                                    </button>
                                                </a>
                                                <a href="gas_refil_customer.php?delete=<?php echo $request->request_id; ?>" onclick="return confirm('Are you sure you want to delete this request?');">
                                                    <button class="btn btn-sm btn-danger">
                                                        <i class="fas fa-trash"></i>
                                                        Delete
                                                    </button>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer -->
            <?php
            require_once('partials/_footer.php');
            ?>
        </div>
    </div>
    <!-- Modal Popup -->
    <div id="validationModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <p>ALL Ready Refill Request Added Please Request After 14 Days </p>
        </div>
    </div>
    <!-- Argon Scripts -->
    <?php
    require_once('partials/_scripts.php');
    ?>

    <script>
        const requestCount = <?php echo $requestCount; ?>;

        function validateRefillRequest() {
            if (requestCount > 0) {
                showModal();
            } else {
                window.location.href = "add_refil_request.php";
            }
        }

        function showModal() {
            const modal = document.getElementById('validationModal');
            modal.style.display = 'block';
        }

        function closeModal() {
            const modal = document.getElementById('validationModal');
            modal.style.display = 'none';
        }
    </script>

    <style>
        /* Modal styling */
        .modal {
            display: none;
            position: fixed;
            z-index: 9999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal-content {
            background-color: #fff;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 30%;
            text-align: center;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }

        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</body>

</html>
