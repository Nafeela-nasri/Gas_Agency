<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();

if (isset($_GET['update'])) {
    $update = intval($_GET['update']);
} else {
    die("Refill ID not provided!");
}

// Fetch Existing Data
$ret = "SELECT * FROM refill_requests_customer WHERE request_id  = ?";
$stmt = $mysqli->prepare($ret);

if (!$stmt) {
    die("Error preparing statement: " . $mysqli->error);
}

$stmt->bind_param('i', $update);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows == 0) {
    die("No refill request found with the given ID!");
}

$refill = $res->fetch_object();

// Update Refill Request
if (isset($_POST['updateRefillRequest'])) {
    if (
        empty($_POST['description']) ||
        empty($_POST['category']) ||
        empty($_POST['outlet_district']) ||
        empty($_POST['outlet_name']) ||
        empty($_POST['expected_delivery_date'])
    ) {
        $err = "All fields are required.";
    } else {
        // Capture updated data
        $description = $_POST['description'];
        $category = $_POST['category'];
        $refill_qty = 1;
        $outlet_district = $_POST['outlet_district'];
        $outlet_name = $_POST['outlet_name'];
        $expected_delivery_date = $_POST['expected_delivery_date'];
        $status = $_POST['status'];

        // Update query
        $updateQuery = "UPDATE refill_requests_customer SET description = ?, category = ?, refill_qty = ?, outlet_district = ?, outlet_name = ?, expected_delivery_date = ?, status = ? WHERE request_id  = ?";
        $updateStmt = $mysqli->prepare($updateQuery);

        if (!$updateStmt) {
            die("Error preparing update statement: " . $mysqli->error);
        }

        $updateStmt->bind_param(
            'ssssssss',
            $description,
            $category,
            $refill_qty,
            $outlet_district,
            $outlet_name,
            $expected_delivery_date,
            $status,
            $update
        );

        $updateStmt->execute();

        if ($updateStmt->affected_rows > 0) {
            $success = "Refill Request Updated Successfully!";
            header("refresh:1; url=gas_refil_customer.php");
        } else {
            $err = "No changes made or error occurred.";
        }
    }
}

require_once('partials/_head.php');
?>

<body>
  <!-- Sidenav -->
  <?php
  require_once('partials/_sidebar.php');
  ?>
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <?php
    require_once('partials/_topnav.php');
    $update = $_GET['update'];
    $ret = "SELECT * FROM refill_requests_customer WHERE request_id  =  ?";
    $stmt = $mysqli->prepare($ret);
    $stmt->bind_param('i', $update);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($refill = $res->fetch_object()) {
    ?>
      <!-- Header -->
      <div style="background-image: url(../admin/assets/img/theme/restro00.jpg); background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
        <span class="mask bg-gradient-dark opacity-8"></span>
        <div class="container-fluid">
          <div class="header-body">
          </div>
        </div>
      </div>
      <!-- Page content -->
      <div class="container-fluid mt--8">
        <!-- Table -->
        <div class="row">
          <div class="col">
            <div class="card shadow">
              <div class="card-header border-0">
                <h3>Update Refill Request</h3>
              </div>
              <div class="card-body">
                <form method="POST">
                  <div class="form-row">
                    <div class="col-md-6">
                      <label>Description</label>
                      <input type="text" name="description" value="<?php echo $refill->description; ?>" class="form-control">
                    </div>
                    <div class="col-md-6">
                      <label>Category</label>
                      <select name="category" class="form-control">
                        <option value="LPG 5 kg" <?php if ($refill->category == "LPG 5 kg") echo "selected"; ?>>LPG 5 kg</option>
                        <option value="LPG 12.5 kg" <?php if ($refill->category == "LPG 12.5 kg") echo "selected"; ?>>LPG 12.5 kg</option>
                        <option value="LPG 15 kg" <?php if ($refill->category == "LPG 15 kg") echo "selected"; ?>>LPG 15 kg</option>
                        <option value="LPG 19 kg" <?php if ($refill->category == "LPG 19 kg") echo "selected"; ?>>LPG 19 kg</option>
                        <option value="LPG 35 kg" <?php if ($refill->category == "LPG 35 kg") echo "selected"; ?>>LPG 35 kg</option>
                        <option value="LPG 45 kg" <?php if ($refill->category == "LPG 45 kg") echo "selected"; ?>>LPG 45 kg</option>
                      </select>
                    </div>
                  </div>
                  <hr>
                  <div class="form-row">
                  <div class="col-md-6">
                      <label>Expected Delivery Date</label>
                      <input type="date" name="expected_delivery_date" value="<?php echo $refill->expected_delivery_date; ?>" class="form-control">
                    </div>
                    <div class="col-md-6">
                      <label>Outlet District</label>
                      <input type="text" name="outlet_district" value="<?php echo $refill->outlet_district; ?>" class="form-control">
                    </div>
                  </div>
                  <hr>
                  <div class="form-row">
                    <div class="col-md-6">
                      <label>Outlet Name</label>
                      <input type="text" name="outlet_name" value="<?php echo $refill->outlet_name; ?>" class="form-control">
                    </div>
                   
                  </div>
                  <hr>
                  <div class="form-row">
                    <div class="col-md-6">
                      <label>Status</label>
                      <select name="status" class="form-control">
                        <option value="Pending" <?php if ($refill->status == "Pending") echo "selected"; ?>>Pending</option>
                      </select>
                    </div>
                  </div>
                  <br>
                  <div class="form-row">
                    <div class="col-md-6">
                      <input type="submit" name="updateRefillRequest" value="Update Refill Request" class="btn btn-success">
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    <?php
    }
    ?>
    <!-- Footer -->
    <?php
    require_once('partials/_footer.php');
    ?>
  </div>
  </div>
  <!-- Argon Scripts -->
  <?php
  require_once('partials/_scripts.php');
  ?>
</body>

</html>
