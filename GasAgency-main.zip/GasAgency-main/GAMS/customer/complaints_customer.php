<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();

require_once('partials/_head.php');
?>

<body>
  <!-- Sidenav -->
  <?php
  require_once('partials/_sidebar.php');
  ?>
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <?php
    require_once('partials/_topnav.php');
    ?>
    <!-- Header -->
    <div style="background-image: url(../admin/assets/img/theme/restro00.jpg); background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
      <span class="mask bg-gradient-dark opacity-8"></span>
      <div class="container-fluid">
        <div class="header-body">
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--8">
      <!-- Table -->
      <div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0">
              <h3>Your Complaints</h3>
            </div>
            <div class="card-header border-0">
                            <a href="add_complaint.php" class="btn btn-outline-success">
                                <i class="fas fa-user-plus"></i> Add New Complaint
                            </a>
            </div>

            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">Complaint ID</th>
                    <th scope="col">Create Date</th>
                    <th scope="col">Outlet Name</th>
                    <th scope="col">Complaint Text</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  // Fetch complaints for the logged-in customer
                  $customer_id = $_SESSION['customer_id'];
                  $ret = "SELECT * FROM rpos_complaints WHERE customer_id = ? ORDER BY create_date DESC";
                  $stmt = $mysqli->prepare($ret);
                  $stmt->bind_param('s', $customer_id);
                  $stmt->execute();
                  $res = $stmt->get_result();

                  // Display complaint records
                  while ($complaint = $res->fetch_object()) {
                  ?>
                    <tr>
                      <td><?php echo $complaint->complaint_id; ?></td>
                      <td><?php echo date('d M Y', strtotime($complaint->create_date)); ?></td>
                      <td><?php echo $complaint->outlet_name; ?></td>
                      <td><?php echo $complaint->complaint_text; ?></td>
                    </tr>
                  <?php } ?>
                </tbody>
              </table>
              <?php
              // Check if no complaints found
              if ($res->num_rows === 0) {
                echo "<p class='text-center mt-3'>No complaints found.</p>";
              }
              ?>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
      <?php
      require_once('partials/_footer.php');
      ?>
    </div>
  </div>
  <!-- Argon Scripts -->
  <?php
  require_once('partials/_scripts.php');
  ?>
</body>

</html>
