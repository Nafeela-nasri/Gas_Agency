<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
include('config/code-generator.php');
require_once 'C:/xampp/htdocs/GasAgency/GasAgency/PHPMailer/src/PHPMailer.php';
require_once 'C:/xampp/htdocs/GasAgency/GasAgency/PHPMailer/src/Exception.php';
require_once 'C:/xampp/htdocs/GasAgency/GasAgency/PHPMailer/src/SMTP.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

check_login();

$customer_id = $_SESSION['customer_id'];
$customer_type = "";
$refill_qty = 1; // Default refill quantity for Domestic Customers

// Fetch outlet details and customer type from database
$outletQuery = "SELECT o.district, o.outlet_name, rc.customer_typ, rc.customer_email, rc.customer_name FROM rpos_customers rc 
                JOIN outlets o ON rc.outletid = o.id 
                WHERE rc.customer_id = ?";
$outletStmt = $mysqli->prepare($outletQuery);
$outletStmt->bind_param('s', $customer_id);
$outletStmt->execute();
$outletStmt->bind_result($outlet_district, $outlet_name, $customer_type, $customer_email, $customer_name);
$outletStmt->fetch();
$outletStmt->close();

if (isset($_POST['addRefillRequest'])) {
    if (empty($_POST['category']) || empty($_POST['expected_delivery_date'])) {
        $err = "Category and Expected Delivery Date are required.";
    } else {
        $category = $_POST['category'];
        $expected_delivery_date = $_POST['expected_delivery_date'];
        $refill_qty = ($customer_type == "Industrial Customer") ? $_POST['refill_qty'] : 1;

        // Check product availability
        $productQuery = "SELECT prod_qty FROM rpos_products WHERE prod_category = ? AND district = ? AND outlet = ?";
        $productStmt = $mysqli->prepare($productQuery);
        $productStmt->bind_param('sss', $category, $outlet_district, $outlet_name);
        $productStmt->execute();
        $productStmt->bind_result($prod_qty);
        $productStmt->fetch();
        $productStmt->close();

        if ($prod_qty >= $refill_qty) {
            $assignCylinder = 1;
            $status = "Ready To Deliver";

            // Reduce the available quantity
            $updateProductQuery = "UPDATE rpos_products SET prod_qty = prod_qty - ? WHERE prod_category = ? AND district = ? AND outlet = ?";
            $updateProductStmt = $mysqli->prepare($updateProductQuery);
            $updateProductStmt->bind_param('isss', $refill_qty, $category, $outlet_district, $outlet_name);
            $updateProductStmt->execute();
            $updateProductStmt->close();
        } else {
            $assignCylinder = 0;
            $status = "Pending";
        }

        // Insert into database
        $postQuery = "INSERT INTO refill_requests_customer (customer_id, category, refill_qty, outlet_district, outlet_name, expected_delivery_date, status, request_type, AssignCylinder) 
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $postStmt = $mysqli->prepare($postQuery);
        $postStmt->bind_param('ssssssssi', $customer_id, $category, $refill_qty, $outlet_district, $outlet_name, $expected_delivery_date, $status, $customer_type, $assignCylinder);
        
        if ($postStmt->execute()) {
            $success = "Refill Request Added Successfully.";
            
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'shakeebar9809@gmail.com';
                $mail->Password   = 'ahgb joum brif ivtv'; // Use App Password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;
                
                $mail->setFrom('shakeebar9809@gmail.com', 'GasbyGas Refill System');
                $mail->addAddress($customer_email);
                
                $mail->isHTML(true);
                
                if ($assignCylinder == 1) {
                    $tomorrowDate = date("Y-m-d", strtotime("+1 day"));
                    $mail->Subject = "Cylinder Assigned";
                    $mail->Body = "<p>Dear $customer_name,</p>
                                   <p>Your refill request for <strong>$category</strong> has been assigned and is <strong>Ready To Deliver</strong>.</p>
                                   <p><strong>Pickup Date:</strong> $tomorrowDate</p>
                                   <p>Please visit our outlet in <strong>$outlet_district</strong> at <strong>$outlet_name</strong> to make the payment and collect your refill.</p>
                                   <p>Thank you for choosing us!</p>";
                } else {
                    $mail->Subject = "Refill Request Pending";
                    $mail->Body = "<p>Dear $customer_name,</p>
                                   <p>Your refill request for <strong>$category</strong> is currently <strong>Pending</strong> due to inventory unavailability at the outlet.</p>
                                   <p>Please be patient, and we will inform you as soon as stock is available.</p>
                                   <p>Thank you for your understanding.</p>";
                }
                
                $mail->send();
            } catch (Exception $e) {
                error_log("Email could not be sent. Mailer Error: {$mail->ErrorInfo}");
            }
            
            header("refresh:1; url=gas_refil_customer.php");
        } else {
            $err = "Error occurred. Please try again.";
        }
    }
}
require_once('partials/_head.php');
?>

<body>
  <?php require_once('partials/_sidebar.php'); ?>
  <div class="main-content">
    <?php require_once('partials/_topnav.php'); ?>
    <div style="background-image: url(../admin/assets/img/theme/restro00.jpg); background-size: cover;" class="header pb-8 pt-5 pt-md-8">
      <span class="mask bg-gradient-dark opacity-8"></span>
      <div class="container-fluid">
        <div class="header-body"></div>
      </div>
    </div>
    <div class="container-fluid mt--8">
      <div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0">
              <h3>Please Fill All Fields</h3>
            </div>
            <div class="card-body">
              <form method="POST">
                <div class="form-row">
                    <div class="col-md-6">
                        <label>Category</label>
                        <select name="category" class="form-control">
                          <option value="LPG 5 kg">LPG 5 kg</option>
                          <option value="LPG 12.5 kg">LPG 12.5 kg</option>
                          <option value="LPG 15 kg">LPG 15 kg</option>
                          <option value="LPG 19 kg">LPG 19 kg</option>
                          <option value="LPG 35 kg">LPG 35 kg</option>
                          <option value="LPG 45 kg">LPG 45 kg</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label>Expected Delivery Date</label>
                        <input type="date" name="expected_delivery_date" class="form-control">
                    </div>
                </div>
                <hr>
                <div class="form-row">
                    <div class="col-md-6">
                        <label>Refill Quantity</label>
                        <?php if ($customer_type == "Industrial Customer"): ?>
                            <input type="number" name="refill_qty" class="form-control" placeholder="Enter quantity" required>
                        <?php else: ?>
                            <input type="text" class="form-control" value="1" readonly>
                        <?php endif; ?>
                    </div>
                </div>
                <hr>
                <div class="form-row" style="display:none;">
                  <div class="col-md-6">
                    <label>Outlet District</label>
                    <input type="text" name="outlet_district" class="form-control" value="<?php echo $outlet_district; ?>" readonly>
                  </div>
                  <div class="col-md-6">
                    <label>Outlet Name</label>
                    <input type="text" name="outlet_name" class="form-control" value="<?php echo $outlet_name; ?>" readonly>
                  </div>
                </div>
                <hr>
                <div class="form-row">
                  <div class="col-md-6">
                    <input type="submit" name="addRefillRequest" value="Add Refill Request" class="btn btn-success">
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <?php require_once('partials/_footer.php'); ?>
    </div>
  </div>
  <?php require_once('partials/_scripts.php'); ?>
</body>
</html>