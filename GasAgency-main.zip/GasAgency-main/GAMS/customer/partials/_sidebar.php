<?php
$customer_id = $_SESSION['customer_id'];
//$login_id = $_SESSION['login_id'];
$ret = "SELECT * FROM  rpos_customers  WHERE customer_id = '$customer_id'";
$stmt = $mysqli->prepare($ret);
$stmt->execute();
$res = $stmt->get_result();
while ($customer = $res->fetch_object()) {
  $current_page = basename($_SERVER['PHP_SELF']);
?>
  <nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
      <!-- Toggler -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <!-- Brand -->
      <a class="navbar-brand pt-0" href="dashboard.php" 
   style="text-decoration: none; display: flex; align-items: center; justify-content: center;">
    <h1 id="logo-text" 
        style="
            font-size: 34px; 
            font-weight: 900; 
            color: #0056b3; 
            margin: 0; 
            padding: 0; 
            font-family: 'Arial', sans-serif; 
            position: relative; 
            display: inline-block; 
            transition: color 0.3s ease, transform 0.3s ease;
        ">
        Gas<span style="color: #ff5722;">by</span>Gas
        <span 
            style="
                position: absolute; 
                bottom: -8px; 
                left: 0; 
                width: 100%; 
                height: 4px; 
                background: linear-gradient(90deg, #0056b3, #ff5722); 
                border-radius: 2px; 
                transition: transform 0.3s ease;
                transform: scaleX(0); 
                transform-origin: left;
            " 
            id="logo-underline"></span>
    </h1>
</a>

<script>
    // Add hover effect to make the logo interactive
    const logoText = document.getElementById("logo-text");
    const logoUnderline = document.getElementById("logo-underline");

    logoText.addEventListener("mouseover", function() {
        this.style.color = "#ff5722";
        this.style.transform = "scale(1.1)";
        logoUnderline.style.transform = "scaleX(1)";
    });

    logoText.addEventListener("mouseout", function() {
        this.style.color = "#0056b3";
        this.style.transform = "scale(1)";
        logoUnderline.style.transform = "scaleX(0)";
    });
</script>


      <h3  class="text-overflow m-0"  style="font-size: 1.2rem;   font-weight: bold;  color: #4a4a4a;  margin-top: 10px;  margin-bottom: 10px;   text-align: center;  text-transform: uppercase;  letter-spacing: 1px; line-height: 1.5;">
          Customer
      </h3>
      <!-- User -->
      <ul class="nav align-items-center d-md-none">
        <li class="nav-item dropdown">
          <a class="nav-link nav-link-icon" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="ni ni-bell-55"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right" aria-labelledby="navbar-default_dropdown_1">
          </div>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <div class="media align-items-center">
              <span class="avatar avatar-sm rounded-circle">
                <img alt='Image placeholder' src='../admin/assets/img/brand/repos.png'>
              </span>
            </div>
          </a>
          <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
            <div class=" dropdown-header noti-title">
              <h6 class="text-overflow m-0">Welcome!</h6>
            </div>
            <a href="change_profile.php" class="dropdown-item">
              <i class="ni ni-single-02"></i>
              <span>My profile</span>
            </a>
            <div class="dropdown-divider"></div>
            <a href="logout.php" class="dropdown-item">
              <i class="ni ni-user-run"></i>
              <span>Logout</span>
            </a>
          </div>
        </li>
      </ul>
      <!-- Collapse -->
      <div class="collapse navbar-collapse" id="sidenav-collapse-main">
        <!-- Collapse header -->
        <div class="navbar-collapse-header d-md-none">
          <div class="row">
            <div class="col-6 collapse-brand">
              <a href="dashboard.php">
                <img src="../admin/assets/img/brand/repos.png">
              </a>
            </div>
            <div class="col-6 collapse-close">
              <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                <span></span>
                <span></span>
              </button>
            </div>
          </div>
        </div>
        <!-- Form -->
        <form class="mt-4 mb-3 d-md-none">
          <div class="input-group input-group-rounded input-group-merge">
            <input type="search" class="form-control form-control-rounded form-control-prepended" placeholder="Search" aria-label="Search">
            <div class="input-group-prepend">
              <div class="input-group-text">
                <span class="fa fa-search"></span>
              </div>
            </div>
          </div>
        </form>
        <!-- Navigation -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="dashboard.php" style="<?php echo ($current_page == 'dashboard.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="ni ni-tv-2 "  style="<?php echo ($current_page == 'dashboard.php') ?  'color: white;' : 'color: #007bff;'; ?>"></i> Dashboard
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="change_profile.php" style="<?php echo ($current_page == 'change_profile.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="fas fa-users "  style="<?php echo ($current_page == 'change_profile.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> My Profile
            </a>
          </li>
          <!-- <li class="nav-item">
            <a class="nav-link" href="orders.php" style="<?php echo ($current_page == 'orders.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="ni ni-cart"  style="<?php echo ($current_page == 'orders.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i>Make Order
            </a>
          </li> -->

          <li class="nav-item">
            <a class="nav-link" href="gas_refil_customer.php" style="<?php echo ($current_page == 'gas_refil_customer.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="fas fa-gas-pump" style="<?php echo ($current_page == 'gas_refil_customer.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Gas Refill
            </a>
          </li>



          <!-- <li class="nav-item">
            <a class="nav-link" href="token_manage.php" style="<?php echo ($current_page == 'token_manage.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="fas fa-ticket-alt" style="<?php echo ($current_page == 'token_manage.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Token Management
            </a>
          </li> -->

          <li class="nav-item">
            <a class="nav-link" href="receipts.php" style="<?php echo ($current_page == 'receipts.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="ni ni-credit-card "  style="<?php echo ($current_page == 'receipts.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Payments
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'complaints_customer.php') ? 'active' : ''; ?>" href="complaints_customer.php"  style="<?php echo ($current_page == 'complaints_customer.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="fas fa-exclamation-circle" style="<?php echo ($current_page == 'complaints_customer.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Customer Complaints
            </a>
          </li>

          <!-- <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'notifications_customer.php') ? 'active' : ''; ?>" href="notifications_customer.php"  style="<?php echo ($current_page == 'notifications_customer.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="ni ni-bell-55" style="<?php echo ($current_page == 'notifications_customer.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Notification
            </a>
          </li> -->



        </ul>
        <!-- Divider -->
        <hr class="my-3">
        <!-- Heading -->
        <h6 class="navbar-heading text-muted">Reporting</h6>
        <!-- Navigation -->
        <ul class="navbar-nav mb-md-3">
          <li class="nav-item">
            <a class="nav-link" href="orders_reports.php" style="<?php echo ($current_page == 'orders_reports.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="fas fa-shopping-basket"  style="<?php echo ($current_page == 'orders_reports.php') ? 'color: white;' : ''; ?>"></i> My Orders
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="payments_reports.php" style="<?php echo ($current_page == 'payments_reports.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="fas fa-funnel-dollar"  style="<?php echo ($current_page == 'payments_reports.php') ? 'color: white;' : ''; ?>"></i> My Payments
            </a>
          </li>
        </ul>
        <hr class="my-3">
        <ul class="navbar-nav mb-md-3">
          <li class="nav-item">
            <a class="nav-link" href="logout.php">
              <i class="fas fa-sign-out-alt text-danger"></i> Log Out
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

<?php } ?>