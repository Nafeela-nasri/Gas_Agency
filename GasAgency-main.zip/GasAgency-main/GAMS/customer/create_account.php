<?php
session_start();
include('config/config.php');

// Add new customer details
if (isset($_POST['addCustomer'])) {
    // Check if any fields are empty
    if (
        empty($_POST["customer_phoneno"]) || empty($_POST["customer_name"]) || empty($_POST['customer_email']) ||
        empty($_POST['customer_password']) || empty($_POST['customer_nic']) || empty($_POST['customer_dob']) || 
        empty($_POST['customer_address']) || empty($_POST['outletid']) || empty($_POST['customer_typ'])
    ) {
        $err = "Blank Values Not Accepted";
    } else {
        // Capture customer data from form
        $customer_id = $_POST['customer_id'];
        $customer_name = $_POST['customer_name'];
        $customer_phoneno = $_POST['customer_phoneno'];
        $customer_email = $_POST['customer_email'];
        $customer_password = sha1(md5($_POST['customer_password'])); // Hash the password
        $customer_nic = $_POST['customer_nic'];
        $customer_dob = $_POST['customer_dob'];
        $customer_address = $_POST['customer_address'];
        $outletid = $_POST['outletid'];
        $customer_typ = $_POST['customer_typ']; // Capture Customer Type

        // Insert captured information into the database table
        $postQuery = "INSERT INTO rpos_customers 
            (customer_id, customer_name, customer_phoneno, customer_email, customer_password, customer_nic, customer_dob, customer_address, outletid, customer_typ) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $postStmt = $mysqli->prepare($postQuery);
        // Bind parameters with proper data types
        $rc = $postStmt->bind_param('ssssssssss', $customer_id, $customer_name, $customer_phoneno, $customer_email, $customer_password, $customer_nic, $customer_dob, $customer_address, $outletid, $customer_typ);
        $postStmt->execute();

        if ($postStmt) {
            $success = "Customer Account Created" &&   header("location: http://localhost/GasAgency/GasAgency/GAMS/admin/dashboard.php");
        } else {
            $err = "Please Try Again Or Try Later";
        }
    }
}

// Fetch outlet data
$outletsQuery = "SELECT id, outlet_name, district FROM outlets";
$outletsStmt = $mysqli->prepare($outletsQuery);
$outletsStmt->execute();
$outletsResult = $outletsStmt->get_result();

require_once('partials/_head.php');
require_once('config/code-generator.php');
?>

<body class="bg-dark">
    <div class="main-content">
        <div class="header bg-gradient-primary py-7">
            <div class="container">
                <div class="header-body text-center mb-7">
                    <div class="row justify-content-center">
                        <div class="col-lg-5 col-md-6">
                            <h1 class="text-white">GasbyGas</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page content -->
        <div class="container mt--8 pb-5">
            <div class="row justify-content-center">
                <div class="col-lg-5 col-md-7">
                    <div class="card bg-secondary shadow border-0">
                        <div class="card-body px-lg-5 py-lg-5">
                            <form method="post" role="form">
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                                        </div>
                                        <input class="form-control" required name="customer_name" placeholder="Full Name" type="text">
                                        <input class="form-control" value="<?php echo $cus_id; ?>" required name="customer_id" type="hidden">
                                    </div>
                                </div>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-phone"></i></span>
                                        </div>
                                        <input class="form-control" required name="customer_phoneno" placeholder="Phone Number" type="text">
                                    </div>
                                </div>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                                        </div>
                                        <input class="form-control" required name="customer_email" placeholder="Email" type="email">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                                        </div>
                                        <input class="form-control" required name="customer_password" placeholder="Password" type="password">
                                    </div>
                                </div>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-id-card"></i></span>
                                        </div>
                                        <input class="form-control" required name="customer_nic" placeholder="NIC" type="text">
                                    </div>
                                </div>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-calendar-alt"></i></span>
                                        </div>
                                        <input class="form-control" required name="customer_dob" placeholder="Date of Birth" type="date">
                                    </div>
                                </div>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-home"></i></span>
                                        </div>
                                        <input class="form-control" required name="customer_address" placeholder="Address" type="text">
                                    </div>
                                </div>
                                <!-- Customer Type Dropdown -->
                                <div class="form-group mb-3">
                                    <select class="form-control" required name="customer_typ">
                                        <option value="">Select Customer Type</option>
                                        <option value="Industrial Customer">Industrial Customer</option>
                                        <option value="Domestic Customer">Domestic Customer</option>
                                    </select>
                                </div>
                                <div class="form-group mb-3">
                                    <select class="form-control" required name="outletid">
                                        <option value="">Select Outlet</option>
                                        <?php while ($row = $outletsResult->fetch_assoc()) { ?>
                                            <option value="<?php echo $row['id']; ?>">
                                                <?php echo $row['outlet_name'] . ' (' . $row['district'] . ')'; ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <div class="text-left">
                                        <button type="submit" name="addCustomer" class="btn btn-primary my-4">Create Account</button>
                                        <a href="index.php" class="btn btn-success pull-right">Log In</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-6">
                            <a href="../admin/forgot_pwd.php" target="_blank" class="text-light"><small>Forgot password?</small></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <?php
    require_once('partials/_footer.php');
    ?>
    <!-- Argon Scripts -->
    <?php
    require_once('partials/_scripts.php');
    ?>
</body>
</html>
