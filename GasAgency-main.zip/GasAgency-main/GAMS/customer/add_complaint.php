<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
include('config/code-generator.php');

check_login();
if (isset($_POST['submit_complaint'])) {
    // Prevent Posting Blank Values
    if (empty($_POST['customer_name']) || empty($_POST['create_date']) || empty($_POST['outlet_name']) || empty($_POST['complaint'])) {
        $err = "Blank Values Not Accepted";
    } else {
        $complaint_id = ''; // Auto-incremented primary key
        $customer_id = $_SESSION['customer_id'];
        $customer_name = $_POST['customer_name'];
        $create_date = $_POST['create_date'];
        $outlet_name = $_POST['outlet_name'];
        $complaint = $_POST['complaint'];

        // Insert Captured information into the database table
        $postQuery = "INSERT INTO rpos_complaints (customer_id, customer_name, create_date, outlet_name, complaint_text) VALUES(?,?,?,?,?)";
        $postStmt = $mysqli->prepare($postQuery);
        // Bind parameters
        $rc = $postStmt->bind_param('sssss', $customer_id, $customer_name, $create_date, $outlet_name, $complaint);
        $postStmt->execute();
        // Declare a variable which will be passed to the alert function
        if ($postStmt) {
            $success = "Complaint Submitted" && header("refresh:1; url=complaints.php");
        } else {
            $err = "Please Try Again Or Try Later";
        }
    }
}
require_once('partials/_head.php');
?>

<body>
    <!-- Sidenav -->
    <?php
    require_once('partials/_sidebar.php');
    ?>
    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php
        require_once('partials/_topnav.php');
        ?>
        <!-- Header -->
        <div style="background-image: url(../admin/assets/img/theme/restro00.jpg); background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
            <span class="mask bg-gradient-dark opacity-8"></span>
            <div class="container-fluid">
                <div class="header-body">
                </div>
            </div>
        </div>
        <!-- Page content -->
        <div class="container-fluid mt--8">
            <!-- Table -->
            <div class="row">
                <div class="col">
                    <div class="card shadow">
                        <div class="card-header border-0">
                            <h3>Submit a Complaint</h3>
                        </div>
                        <div class="card-body">
                            <form method="POST" enctype="multipart/form-data">
                                <div class="form-group col-md-4">
                                    <label>Customer Name</label>
                                    <?php
                                    // Load All Customers
                                    $customer_id = $_SESSION['customer_id'];
                                    $ret = "SELECT * FROM  rpos_customers WHERE customer_id = '$customer_id' ";
                                    $stmt = $mysqli->prepare($ret);
                                    $stmt->execute();
                                    $res = $stmt->get_result();
                                    while ($cust = $res->fetch_object()) {
                                    ?>
                                        <input class="form-control" readonly name="customer_name" value="<?php echo $cust->customer_name; ?>">
                                    <?php } ?>
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Create Date</label>
                                    <input type="date" name="create_date" class="form-control" required>
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Outlet Name</label>
                                    <input type="text" name="outlet_name" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label>Complaint</label>
                                    <textarea name="complaint" class="form-control" rows="5" required></textarea>
                                </div>
                                <div class="form-group">
                                    <input type="submit" name="submit_complaint" value="Submit Complaint" class="btn btn-danger">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer -->
            <?php
            require_once('partials/_footer.php');
            ?>
        </div>
    </div>
    <!-- Argon Scripts -->
    <?php
    require_once('partials/_scripts.php');
    ?>
</body>

</html>
