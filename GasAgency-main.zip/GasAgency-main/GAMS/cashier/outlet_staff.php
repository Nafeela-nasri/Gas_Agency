<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();

// Delete Outlet Staff
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $adn = "DELETE FROM outlet_staff WHERE staff_id = ?";
    $stmt = $mysqli->prepare($adn);
    $stmt->bind_param('s', $id);
    $stmt->execute();
    $stmt->close();
    if ($stmt) {
        $success = "Deleted" && header("refresh:1; url=outlet_staff.php");
    } else {
        $err = "Try Again Later";
    }
}

require_once('partials/_head.php');
?>

<body>
    <!-- Sidenav -->
    <?php require_once('partials/_sidebar.php'); ?>
    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php require_once('partials/_topnav.php'); ?>
        <!-- Header -->
        <div style="background-image: url(../admin/assets/img/theme/restro00.jpg); background-size: cover;" class="header pb-8 pt-5 pt-md-8">
            <span class="mask bg-gradient-dark opacity-8"></span>
            <div class="container-fluid">
                <div class="header-body"></div>
            </div>
        </div>
        <!-- Page content -->
        <div class="container-fluid mt--8">
            <!-- Table -->
            <div class="row">
                <div class="col">
                    <div class="card shadow">
                        <div class="card-header border-0">
                            <a href="add_outlet_staff.php" class="btn btn-outline-success">
                                <i class="fas fa-user-plus"></i> Add New Staff
                            </a>
                        </div>
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col">Staff Number</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Outlet District</th>
                                        <th scope="col">Outlet Name</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Mobile</th>
                                        <th scope="col">Country</th>
                                        <th scope="col">City</th>
                                        <th scope="col">Join Date</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $district = $_SESSION['district'];
                                    $outlet_name = $_SESSION['outlet_name'];

                                    $ret = "SELECT * FROM outlet_staff WHERE district = ? AND outlet_name = ? ORDER BY created_at DESC";
                                    $stmt = $mysqli->prepare($ret);
                                    $stmt->bind_param('ss', $district, $outlet_name);
                                    $stmt->execute();
                                    $res = $stmt->get_result();
                                    while ($staff = $res->fetch_object()) {
                                    ?>
                                        <tr>
                                            <td><?php echo $staff->staff_number; ?></td>
                                            <td><?php echo $staff->staff_name; ?></td>
                                            <td><?php echo $staff->district; ?></td>
                                            <td><?php echo $staff->outlet_name; ?></td>
                                            <td><?php echo $staff->staff_email; ?></td>
                                            <td><?php echo $staff->staff_mobile; ?></td>
                                            <td><?php echo $staff->staff_country; ?></td>
                                            <td><?php echo $staff->staff_city; ?></td>
                                            <td><?php echo $staff->staff_join_date; ?></td>
                                            <td>
                                                <a href="update_outlet_staff.php?update=<?php echo $staff->staff_id; ?>">
                                                    <button class="btn btn-sm btn-primary">
                                                        <i class="fas fa-user-edit"></i> Update
                                                    </button>
                                                </a>
                                                <a href="outlet_staff.php?delete=<?php echo $staff->staff_id; ?>" onclick="return confirm('Are you sure you want to delete this staff member?');">
                                                    <button class="btn btn-sm btn-danger">
                                                        <i class="fas fa-trash"></i> Delete
                                                    </button>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer -->
            <?php require_once('partials/_footer.php'); ?>
        </div>
    </div>
    <!-- Argon Scripts -->
    <?php require_once('partials/_scripts.php'); ?>
</body>

</html>
