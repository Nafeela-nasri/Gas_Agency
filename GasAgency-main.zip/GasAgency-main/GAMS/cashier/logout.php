<?php
session_start();
unset($_SESSION['staff_id']);
session_destroy();
header("location:http://localhost/GasAgency/GasAgency/GAMS/admin/index.php");
exit;
