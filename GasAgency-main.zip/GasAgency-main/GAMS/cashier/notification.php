<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();

require_once('partials/_head.php');
?>

<body>
  <!-- Sidenav -->
  <?php
  require_once('partials/_sidebar.php');
  ?>
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <?php
    require_once('partials/_topnav.php');
    ?>
    <!-- Header -->
    <div style="background-image: url(../admin/assets/img/theme/restro00.jpg); background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
      <span class="mask bg-gradient-dark opacity-8"></span>
      <div class="container-fluid">
        <div class="header-body">
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--8">
      <!-- Table -->
      <div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0">
              <h3>Your Notifications</h3>
            </div>

            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">Notification ID</th>
                    <th scope="col">Description</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  // SQL query to get notifications with is_notification = 0
                  $ret = "SELECT * FROM notification_details_customer WHERE is_notification = 0 ORDER BY createddate DESC";
                  $stmt = $mysqli->prepare($ret);
                  $stmt->execute();
                  $res = $stmt->get_result();
                  $notification_count = 1; // Start the auto-increment ID

                  // Display notification records
                  while ($notification = $res->fetch_object()) {
                    // Get the table name and main_id
                    $table_name = $notification->table_name;
                    $main_id = $notification->main_id;
                    $description = "";

                    // Depending on the table name, get the corresponding data
                    if ($table_name == 'rpos_orders') {
                      // Fetch order details
                      $order_query = "SELECT * FROM rpos_orders WHERE order_id = ?";
                      $order_stmt = $mysqli->prepare($order_query);
                      $order_stmt->bind_param("i", $main_id);
                      $order_stmt->execute();
                      $order_res = $order_stmt->get_result();
                      $order = $order_res->fetch_object();
                      $description = "Customer New Order - Order ID: " . $order->order_id;
                      $link = "orders.php?id=" . $main_id;
                    } elseif ($table_name == 'refill_requests_customer') {
                      // Fetch refill request details
                      $refill_query = "SELECT * FROM refill_requests_customer WHERE request_id = ?";
                      $refill_stmt = $mysqli->prepare($refill_query);
                      $refill_stmt->bind_param("i", $main_id);
                      $refill_stmt->execute();
                      $refill_res = $refill_stmt->get_result();
                      $refill = $refill_res->fetch_object();
                      $description = "Customer New Refill Request - Request ID: " . $refill->request_id;
                      $link = "RefilRequest.php?id=" . $main_id;
                    } elseif ($table_name == 'rpos_complaints') {
                      // Fetch complaint details
                      $complaint_query = "SELECT * FROM rpos_complaints WHERE complaint_id = ?";
                      $complaint_stmt = $mysqli->prepare($complaint_query);
                      $complaint_stmt->bind_param("i", $main_id);
                      $complaint_stmt->execute();
                      $complaint_res = $complaint_stmt->get_result();
                      $complaint = $complaint_res->fetch_object();
                      $description = "New Customer Complaint - Complaint ID: " . $complaint->complaint_id;
                      $link = "complaint_managment.php?id=" . $main_id;
                    } elseif ($table_name == 'rpos_payments') {
                      // Fetch payment details
                      $payment_query = "SELECT * FROM rpos_payments WHERE pay_id = ?";
                      $payment_stmt = $mysqli->prepare($payment_query);
                      $payment_stmt->bind_param("i", $main_id);
                      $payment_stmt->execute();
                      $payment_res = $payment_stmt->get_result();
                      $payment = $payment_res->fetch_object();
                      $description = "New Payment Details - Payment ID: " . $payment->pay_id;
                      $link = "payments.php?id=" . $main_id;
                    }

                    // Display notification row with auto-incrementing ID
                    ?>
                    <tr>
                      <td><?php echo $notification_count++; ?></td>
                      <td><?php echo $description; ?></td>
                      <td>
                        <a href="<?php echo $link; ?>" class="btn btn-info btn-sm">
                          <i class="fas fa-eye"></i> View
                        </a>
                      </td>
                    </tr>
                  <?php } ?>
                </tbody>
              </table>
              <?php
              // Check if no notifications found
              if ($res->num_rows === 0) {
                echo "<p class='text-center mt-3'>No notifications found.</p>";
              }
              ?>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
      <?php
      require_once('partials/_footer.php');
      ?>
    </div>
  </div>
  <!-- Argon Scripts -->
  <?php
  require_once('partials/_scripts.php');
  ?>
</body>

</html>
