<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $adn = "DELETE FROM rpos_products WHERE prod_id = ?";
    $stmt = $mysqli->prepare($adn);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();
    
    if ($stmt) {
        header("refresh:1; url=products.php");
        exit();
    } else {
        $err = "Try Again Later";
    }
}

require_once('partials/_head.php');
?>

<body>
    <?php require_once('partials/_sidebar.php'); ?>
    <div class="main-content">
        <?php require_once('partials/_topnav.php'); ?>
        <div style="background-image: url(../admin/assets/img/theme/restro00.jpg); background-size: cover;" class="header pb-8 pt-5 pt-md-8">
            <span class="mask bg-gradient-dark opacity-8"></span>
            <div class="container-fluid">
                <div class="header-body"></div>
            </div>
        </div>
        <div class="container-fluid mt--8">
            <div class="row">
                <div class="col">
                    <div class="card shadow">
                        <div class="card-header border-0">Food Items</div>
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col">Image</th>
                                        <th scope="col">Product Code</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Price</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Category</th>
                                        <!-- <th scope="col">Actions</th> -->
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $district = $_SESSION['district'];
                                    $outlet_name = $_SESSION['outlet_name'];
                                    
                                    $query = "SELECT * FROM rpos_products WHERE district = ? AND outlet = ?";
                                    $stmt = $mysqli->prepare($query);
                                    $stmt->bind_param('ss', $district, $outlet_name);
                                    $stmt->execute();
                                    $res = $stmt->get_result();
                                    
                                    while ($prod = $res->fetch_object()) {
                                    ?>
                                        <tr>
                                            <td>
                                                <img src="../admin/assets/img/products/<?= $prod->prod_img ?: 'default.jpg' ?>" height="60" width="60" class="img-thumbnail">
                                            </td>
                                            <td><?= $prod->prod_code; ?></td>
                                            <td><?= $prod->prod_name; ?></td>
                                            <td>Lkr <?= $prod->prod_price; ?></td>
                                            <td><?= $prod->prod_qty; ?></td>
                                            <td><?= $prod->prod_category; ?></td>
                                            <!-- <td>
                                                <a href="delete_product.php?delete=<?= $prod->prod_id; ?>">
                                                    <button class="btn btn-sm btn-danger">
                                                        <i class="fas fa-trash"></i> Delete
                                                    </button>
                                                </a>
                                                <a href="update_product.php?update=<?= $prod->prod_id; ?>">
                                                    <button class="btn btn-sm btn-primary">
                                                        <i class="fas fa-edit"></i> Update
                                                    </button>
                                                </a>
                                            </td> -->
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php require_once('partials/_footer.php'); ?>
        </div>
    </div>
    <?php require_once('partials/_scripts.php'); ?>
</body>
</html>
