<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();

// Ensure staff_id is set in the session
if (!isset($_SESSION['staff_id'])) {
    die("Unauthorized access! Please log in.");
}

$staff_id = $_SESSION['staff_id']; // Get the staff_id from the session

// Delete Refill Request
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $adn = "DELETE FROM refill_requests WHERE id = ? AND manager_id = ?";
    $stmt = $mysqli->prepare($adn);
    $stmt->bind_param('ii', $id, $staff_id);
    $stmt->execute();
    $stmt->close();
    if ($stmt) {
        $success = "Refill Request Deleted" && header("refresh:1; url=RefilRequest.php");
    } else {
        $err = "Try Again Later";
    }
}

// Approve Refill Request
if (isset($_GET['approve'])) {
    $id = $_GET['approve'];
    $updateQuery = "UPDATE refill_requests SET isapproved_by_outlet_manager = 1, manager_status = 'Approved' WHERE id = ? AND manager_id = ?";
    $stmt = $mysqli->prepare($updateQuery);
    $stmt->bind_param('ii', $id, $staff_id);
    $stmt->execute();
    $stmt->close();
    if ($stmt) {
        $success = "Refill Request Approved" && header("refresh:1; url=RefilRequest.php");
    } else {
        $err = "Try Again Later";
    }
}

require_once('partials/_head.php');
?>

<body>
    <!-- Sidenav -->
    <?php require_once('partials/_sidebar.php'); ?>

    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php require_once('partials/_topnav.php'); ?>

        <!-- Header -->
        <div style="background-image: url(../admin/assets/img/theme/restro00.jpg); background-size: cover;" class="header pb-8 pt-5 pt-md-8">
            <span class="mask bg-gradient-dark opacity-8"></span>
            <div class="container-fluid">
                <div class="header-body"></div>
            </div>
        </div>

        <!-- Page content -->
        <div class="container-fluid mt--8">
            <!-- Table -->
            <div class="row">
                <div class="col">
                    <div class="card shadow">
                        <div class="card-header border-0"></div>
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col">Request ID</th>
                                        <th scope="col">Manager Name</th>
                                        <th scope="col">Description</th>
                                        <th scope="col">Category</th>
                                        <th scope="col">Refill Qty</th>
                                        <th scope="col">Outlet District</th>
                                        <th scope="col">Outlet Name</th>
                                        <th scope="col">Expected Delivery</th>
                                        <th scope="col">Dispatch Date</th>
                                        <th scope="col">Manager Status</th>
                                        <th scope="col">Dispatch Status</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                        // Get session values
                                        $district = $_SESSION['district'];
                                        $outlet_name = $_SESSION['outlet_name'];

                                        // SQL Query to Fetch Refill Requests with Manager Name and Outlet Filters
                                        $ret = "SELECT rr.*, rs.staff_name 
                                                FROM refill_requests rr 
                                                INNER JOIN outlet_staff rs 
                                                ON rr.manager_id = rs.staff_id 
                                                WHERE rr.outlet_district = ? 
                                                AND rr.outlet_name = ? 
                                                ORDER BY rr.created_date DESC";

                                        $stmt = $mysqli->prepare($ret);
                                        $stmt->bind_param('ss', $district, $outlet_name); // Filter by district and outlet name
                                        $stmt->execute();
                                        $res = $stmt->get_result();
                                        while ($request = $res->fetch_object()) {
                                        ?>
                                        <tr>
                                            <td><?php echo $request->id; ?></td>
                                            <td><?php echo $request->staff_name; ?></td>
                                            <td><?php echo $request->description; ?></td>
                                            <td><?php echo $request->category; ?></td>
                                            <td><?php echo $request->refill_qty; ?></td>
                                            <td><?php echo $request->outlet_district; ?></td>
                                            <td><?php echo $request->outlet_name; ?></td>
                                            <td><?php echo $request->expected_delivery_date; ?></td>
                                            <td>
                                                <?php
                                                if (!empty($request->scheduled_date)) {
                                                    echo $request->scheduled_date;
                                                } else {
                                                    echo "Not Assigned Yet";
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php
                                                if ($request->manager_status == 'Pending') {
                                                    echo '<span class="badge badge-warning">Pending</span>';
                                                } elseif ($request->manager_status == 'Approved') {
                                                    echo '<span class="badge badge-success">Approved</span>';
                                                } elseif ($request->manager_status == 'Rejected') {
                                                    echo '<span class="badge badge-danger">Rejected</span>';
                                                } else {
                                                    echo '<span class="badge badge-warning">Pending</span>';
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php
                                                if ($request->status == 'Pending') {
                                                    echo '<span class="badge badge-warning">Pending</span>';
                                                } elseif ($request->status == 'Approved') {
                                                    echo '<span class="badge badge-success">Approved</span>';
                                                } elseif ($request->status == 'Rejected') {
                                                    echo '<span class="badge badge-danger">Rejected</span>';
                                                } else {
                                                    echo '<span class="badge badge-secondary">Unknown</span>';
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <a href="update_refill_request.php?update=<?php echo $request->id; ?>">
                                                    <button class="btn btn-sm btn-primary">
                                                        <i class="fas fa-edit"></i>
                                                        Update
                                                    </button>
                                                </a>
                                                <a href="RefilRequest.php?delete=<?php echo $request->id; ?>" onclick="return confirm('Are you sure you want to delete this request?');">
                                                    <button class="btn btn-sm btn-danger">
                                                        <i class="fas fa-trash"></i>
                                                        Delete
                                                    </button>
                                                </a>
                                                <?php if ($request->isapproved_by_outlet_manager == 0) { ?>
                                                    <a href="RefilRequest.php?approve=<?php echo $request->id; ?>" onclick="return confirm('Are you sure you want to approve this request?');">
                                                        <button class="btn btn-sm btn-success">
                                                            <i class="fas fa-check"></i>
                                                            Approve
                                                        </button>
                                                    </a>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer -->
            <?php require_once('partials/_footer.php'); ?>
        </div>
    </div>
    <!-- Argon Scripts -->
    <?php require_once('partials/_scripts.php'); ?>
</body>

</html>
