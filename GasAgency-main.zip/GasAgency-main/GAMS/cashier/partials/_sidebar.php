<?php
$staff_id = $_SESSION['staff_id'];
//$login_id = $_SESSION['login_id'];
$ret = "SELECT * FROM  rpos_staff  WHERE staff_id = '$staff_id'";
$stmt = $mysqli->prepare($ret);
$stmt->execute();
$res = $stmt->get_result();


// $notification_query = "SELECT COUNT(*) AS unread_count FROM notification_details_customer WHERE is_notification = 0";
// $notification_stmt = $mysqli->prepare($notification_query);
// $notification_stmt->execute();
// $notification_result = $notification_stmt->get_result();
// $unread_notifications = $notification_result->fetch_object()->unread_count;



while ($staff_id = $res->fetch_object()) {

  // Get the current file name to match for active link
  $current_page = basename($_SERVER['PHP_SELF']);
?>
  <nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
      <!-- Toggler -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <!-- Brand -->
      <a class="navbar-brand pt-0" href="dashboard.php" 
   style="text-decoration: none; display: flex; align-items: center; justify-content: center;">
    <h1 id="logo-text" 
        style="
            font-size: 34px; 
            font-weight: 900; 
            color: #0056b3; 
            margin: 0; 
            padding: 0; 
            font-family: 'Arial', sans-serif; 
            position: relative; 
            display: inline-block; 
            transition: color 0.3s ease, transform 0.3s ease;
        ">
        Gas<span style="color: #ff5722;">by</span>Gas
        <span 
            style="
                position: absolute; 
                bottom: -8px; 
                left: 0; 
                width: 100%; 
                height: 4px; 
                background: linear-gradient(90deg, #0056b3, #ff5722); 
                border-radius: 2px; 
                transition: transform 0.3s ease;
                transform: scaleX(0); 
                transform-origin: left;
            " 
            id="logo-underline"></span>
    </h1>
</a>

<script>
    // Add hover effect to make the logo interactive
    const logoText = document.getElementById("logo-text");
    const logoUnderline = document.getElementById("logo-underline");

    logoText.addEventListener("mouseover", function() {
        this.style.color = "#ff5722";
        this.style.transform = "scale(1.1)";
        logoUnderline.style.transform = "scaleX(1)";
    });

    logoText.addEventListener("mouseout", function() {
        this.style.color = "#0056b3";
        this.style.transform = "scale(1)";
        logoUnderline.style.transform = "scaleX(0)";
    });
</script>



      <h3  class="text-overflow m-0"  style="font-size: 1.1rem;   font-weight: bold;  color: #4a4a4a;  margin-top: 10px;  margin-bottom: 10px;   text-align: center;  text-transform: uppercase;  letter-spacing: 1px; line-height: 1.5;">
          Outlet Manager
      </h3>

      <!-- User -->
      <ul class="nav align-items-center d-md-none">
        <li class="nav-item dropdown">
          <a class="nav-link nav-link-icon" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="ni ni-bell-55"></i>
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <div class="media align-items-center">
              <span class="avatar avatar-sm rounded-circle">
                <img alt="Image placeholder" src="../assets/img/">
              </span>
            </div>
          </a>
          <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
            <div class="dropdown-header noti-title">
              <h6 class="text-overflow m-0">Welcome!</h6>
            </div>
            <a href="change_profile.php" class="dropdown-item">
              <i class="ni ni-single-02"></i>
              <span>My profile</span>
            </a>
            <div class="dropdown-divider"></div>
            <a href="logout.php" class="dropdown-item">
              <i class="ni ni-user-run"></i>
              <span>Logout</span>
            </a>
          </div>
        </li>
      </ul>
      <!-- Collapse -->
      <div class="collapse navbar-collapse" id="sidenav-collapse-main">
        <!-- Navigation -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>" href="dashboard.php"  style="<?php echo ($current_page == 'dashboard.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="ni ni-tv-2 " style="<?php echo ($current_page == 'dashboard.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Dashboard
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'products.php') ? 'active' : ''; ?>" href="products.php"  style="<?php echo ($current_page == 'products.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="ni ni-bullet-list-67" style="<?php echo ($current_page == 'products.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Inventory
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'RefilRequest.php') ? 'active' : ''; ?>" href="RefilRequest.php"  style="<?php echo ($current_page == 'RefilRequest.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="ni ni-basket " style="<?php echo ($current_page == 'RefilRequest.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Refill Request
            </a>
          </li>
          <!-- <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'deliveryshedule_outlate.php') ? 'active' : ''; ?>" href="deliveryshedule_outlate.php"  style="<?php echo ($current_page == 'deliveryshedule_outlate.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="fas fa-truck " style="<?php echo ($current_page == 'deliveryshedule_outlate.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Delivery Scheduling
            </a>
          </li> -->
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'customes.php') ? 'active' : ''; ?>" href="customes.php"  style="<?php echo ($current_page == 'customes.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="fas fa-users " style="<?php echo ($current_page == 'customes.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Customers
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'outlet_staff.php') ? 'active' : ''; ?>" href="outlet_staff.php"  style="<?php echo ($current_page == 'outlet_staff.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="fas fa-user-tie " style="<?php echo ($current_page == 'outlet_staff.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Outlet Staff
            </a>
          </li>
          <!-- <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'orders.php') ? 'active' : ''; ?>" href="orders.php"  style="<?php echo ($current_page == 'orders.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="ni ni-cart" style="<?php echo ($current_page == 'orders.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Orders
            </a>
          </li> -->
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'complaint_managment.php') ? 'active' : ''; ?>" href="complaint_managment.php"  style="<?php echo ($current_page == 'complaint_managment.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="fas fa-exclamation-circle " style="<?php echo ($current_page == 'complaint_managment.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Customer Complaints
            </a>
          </li>
          <!-- <li class="nav-item">
                    <a class="nav-link <?php echo ($current_page == 'notification.php') ? 'active' : ''; ?>"
                        href="notification.php"
                        style="<?php echo ($current_page == 'notification.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
                        <i class="ni ni-bell-55"
                            style="<?php echo ($current_page == 'notification.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i>
                        Notification
                        <?php if ($unread_notifications > 0): ?>
                            <span class="badge badge-danger ml-2"><?php echo $unread_notifications; ?></span>
                        <?php endif; ?>
                    </a>
                </li> -->
          <!-- <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'payments.php') ? 'active' : ''; ?>" href="payments.php"  style="<?php echo ($current_page == 'payments.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="ni ni-credit-card " style="<?php echo ($current_page == 'payments.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Payments
            </a>
          </li> -->
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'receipts.php') ? 'active' : ''; ?>" 
              href="receipts.php"  
              style="<?php echo ($current_page == 'receipts.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="fas fa-file-invoice-dollar" 
                style="<?php echo ($current_page == 'receipts.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Receipts
            </a>
          </li>

          </li>
        </ul>
        <!-- Divider -->
        <hr class="my-3">
        <!-- Reporting -->
        <h6 class="navbar-heading text-muted">Reporting</h6>
        <ul class="navbar-nav mb-md-3">
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'orders_reports.php') ? 'active' : ''; ?>" href="orders_reports.php" style="<?php echo ($current_page == 'orders_reports.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="fas fa-shopping-basket" style="<?php echo ($current_page == 'orders_reports.php') ? 'color: white;' : ''; ?>"></i> Orders
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'payments_reports.php') ? 'active' : ''; ?>" href="payments_reports.php" style="<?php echo ($current_page == 'payments_reports.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="fas fa-funnel-dollar" style="<?php echo ($current_page == 'payments_reports.php') ? 'color: white;' : ''; ?>"></i> Payments
            </a>
          </li>
        </ul>
        <!-- Log Out -->
        <hr class="my-3">
        <ul class="navbar-nav mb-md-3">
          <li class="nav-item">
            <a class="nav-link" href="logout.php">
              <i class="fas fa-sign-out-alt text-danger"></i> Log Out
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
<?php } ?>
