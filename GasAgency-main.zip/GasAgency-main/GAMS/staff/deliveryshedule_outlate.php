<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();

// Confirm Delivery Schedule
if (isset($_GET['confirm'])) {
    $id = $_GET['confirm'];
    $adn = "UPDATE delivery_schedule SET status = 'Confirmed' WHERE schedule_id = ?";
    $stmt = $mysqli->prepare($adn);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();
    if ($stmt) {
        $success = "Confirmed";
        header("refresh:1; url=deliveryshedule_outlate.php");
    } else {
        $err = "Try Again Later";
    }
}

require_once('partials/_head.php');
?>

<body>
  <!-- Sidenav -->
  <?php require_once('partials/_sidebar.php'); ?>
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <?php require_once('partials/_topnav.php'); ?>
    <!-- Header -->
    <div style="background-image: url(assets/img/theme/delivery.jpg); background-size: cover;" class="header pb-8 pt-5 pt-md-8">
      <span class="mask bg-gradient-dark opacity-8"></span>
      <div class="container-fluid">
        <div class="header-body">
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--8">
      <!-- Table -->
      <div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0">
              <a href="add_delivery_schedule.php" class="btn btn-outline-success">
                <i class="fas fa-calendar-plus"></i>
                Add New Delivery Schedule
              </a>
            </div>
            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">Description</th>
                    <th scope="col">Refill Request</th>
                    <th scope="col">Created Date</th>
                    <th scope="col">Scheduled Date</th>
                    <th scope="col">Delivery Period (days)</th>
                    <th scope="col">Status</th>
                    <th scope="col">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $query = "
                    SELECT ds.*, rr.description AS refill_description
                    FROM delivery_schedule ds
                    JOIN refill_requests rr ON ds.refill_request_id = rr.id
                    WHERE rr.manager_id = ?
                    ORDER BY ds.created_date DESC
                  ";
                  $stmt = $mysqli->prepare($query);
                  $staff_id = $_SESSION['outlet_staff_id'];
                  $stmt->bind_param('i', $staff_id);
                  $stmt->execute();
                  $result = $stmt->get_result();
                  while ($schedule = $result->fetch_object()) {
                    // Determine the status class
                    $status_class = ($schedule->status == 'Confirmed') ? 'text-success' : '';
                  ?>
                    <tr>
                      <td><?php echo htmlspecialchars($schedule->description); ?></td>
                      <td><?php echo htmlspecialchars($schedule->refill_description); ?></td>
                      <td><?php echo htmlspecialchars($schedule->created_date); ?></td>
                      <td><?php echo htmlspecialchars($schedule->scheduled_date); ?></td>
                      <td><?php echo htmlspecialchars($schedule->delivery_period); ?></td>
                      <td class="<?php echo $status_class; ?>"><?php echo htmlspecialchars($schedule->status); ?></td>
                      <td>
                        <?php if ($schedule->status != 'Confirmed') { ?>
                          <a href="deliveryshedule_outlate.php?confirm=<?php echo $schedule->schedule_id; ?>" onclick="return confirm('Are you sure you want to confirm this schedule?');">
                            <button class="btn btn-sm btn-success">
                              <i class="fas fa-check"></i>
                              Confirm
                            </button>
                          </a>
                        <?php } ?>
                      </td>
                    </tr>
                  <?php
                  }
                  $stmt->close();
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
      <?php require_once('partials/_footer.php'); ?>
    </div>
  </div>
  <!-- Argon Scripts -->
  <?php require_once('partials/_scripts.php'); ?>
</body>

</html>
