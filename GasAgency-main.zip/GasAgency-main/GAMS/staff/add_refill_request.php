<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
include('config/code-generator.php');

check_login();

// Get district and outlet name from session
$district = $_SESSION['district'];
$outlet_name = $_SESSION['outlet_name'];

// Add Refill Request
if (isset($_POST['addRefillRequest'])) {
    if (
        empty($_POST['description']) ||
        empty($_POST['category']) ||
        empty($_POST['refill_qty']) ||
        empty($_POST['expected_delivery_date'])
    ) {
        $err = "All fields are required.";
    } else {
        // Capture data from the form
        $manager_id = $_SESSION['outlet_staff_id'];
        $description = $_POST['description'];
        $category = $_POST['category'];
        $refill_qty = $_POST['refill_qty'];
        $expected_delivery_date = $_POST['expected_delivery_date'];
        $status = "Pending"; // Status is hidden but set as "Pending"

        // Insert captured data into the table
        $postQuery = "INSERT INTO refill_requests (manager_id, description, category, refill_qty, outlet_district, outlet_name, expected_delivery_date, status)
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $postStmt = $mysqli->prepare($postQuery);
        $rc = $postStmt->bind_param(
            'ississss',
            $manager_id,
            $description,
            $category,
            $refill_qty,
            $district,  // From session
            $outlet_name, // From session
            $expected_delivery_date,
            $status
        );
        $postStmt->execute();

        // Check if the query was successful
        if ($postStmt) {
            $success = "Refill Request Added" && header("refresh:1; url=RefilRequest.php");
        } else {
            $err = "Error occurred. Please try again.";
        }
    }
}
require_once('partials/_head.php');
?>

<body>
  <!-- Sidenav -->
  <?php
  require_once('partials/_sidebar.php');
  ?>
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <?php
    require_once('partials/_topnav.php');
    ?>
    <!-- Header -->
    <div style="background-image: url(../admin/assets/img/theme/restro00.jpg); background-size: cover;" class="header pb-8 pt-5 pt-md-8">
      <span class="mask bg-gradient-dark opacity-8"></span>
      <div class="container-fluid">
        <div class="header-body">
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--8">
      <!-- Table -->
      <div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0">
              <h3>Please Fill All Fields</h3>
            </div>
            <div class="card-body">
              <form method="POST">
                <div class="form-row">
                  <div class="col-md-6">
                    <label>Description</label>
                    <input type="text" name="description" class="form-control">
                  </div>
                </div>
                <hr>
                <div class="form-row">
                    <div class="col-md-6">
                        <label>Category</label>
                        <select name="category" class="form-control">
                        <option value="LPG 5 kg">LPG 5 kg</option>
                        <option value="LPG 12.5 kg">LPG 12.5 kg</option>
                        <option value="LPG 15 kg">LPG 15 kg</option>
                        <option value="LPG 19 kg">LPG 19 kg</option>
                        <option value="LPG 35 kg">LPG 35 kg</option>
                        <option value="LPG 45 kg">LPG 45 kg</option>
                        </select>
                    </div>
                  <div class="col-md-6">
                    <label>Refill Quantity</label>
                    <input type="number" name="refill_qty" class="form-control" value="">
                  </div>
                </div>
                <hr>
                <!-- Hidden Fields for District and Outlet Name -->
                <input type="hidden" name="outlet_district" value="<?php echo $district; ?>">
                <input type="hidden" name="outlet_name" value="<?php echo $outlet_name; ?>">

                <div class="form-row">
                  <div class="col-md-6">
                    <label>Expected Delivery Date</label>
                    <input type="date" name="expected_delivery_date" class="form-control" value="">
                  </div>
                </div>

                <!-- Hidden Status Field -->
                <input type="hidden" name="status" value="Pending">

                <br>
                <div class="form-row">
                  <div class="col-md-6">
                    <input type="submit" name="addRefillRequest" value="Add Refill Request" class="btn btn-success">
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
      <?php
      require_once('partials/_footer.php');
      ?>
    </div>
  </div>
  <!-- Argon Scripts -->
  <?php
  require_once('partials/_scripts.php');
  ?>
</body>

</html>
