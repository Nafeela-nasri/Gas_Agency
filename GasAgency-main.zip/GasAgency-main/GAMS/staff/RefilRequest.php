<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();
require_once 'C:/xampp/htdocs/GasAgency/GasAgency/PHPMailer/src/PHPMailer.php';
require_once 'C:/xampp/htdocs/GasAgency/GasAgency/PHPMailer/src/Exception.php';
require_once 'C:/xampp/htdocs/GasAgency/GasAgency/PHPMailer/src/SMTP.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
// Ensure staff_id is set in the session
if (!isset($_SESSION['outlet_staff_id'])) {
    die("Unauthorized access! Please log in.");
}

$staff_id = $_SESSION['outlet_staff_id']; // Get the staff_id from the session

// Delete Refill Request
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $adn = "DELETE FROM refill_requests WHERE id = ? AND manager_id = ?";
    $stmt = $mysqli->prepare($adn);
    $stmt->bind_param('ii', $id, $staff_id); // Add staff_id to the WHERE condition
    $stmt->execute();
    $stmt->close();
    if ($stmt) {
        $success = "Refill Request Deleted" && header("refresh:1; url=refill_requests.php");
    } else {
        $err = "Try Again Later";
    }
}

// Confirm as Received
if (isset($_GET['confirm_received'])) {
    $id = $_GET['confirm_received'];
    
    // Update the isconfirm column to 1
    $update_isconfirm = "UPDATE refill_requests SET isconfirm = 1 WHERE id = ?";
    $stmt = $mysqli->prepare($update_isconfirm);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    
    if ($stmt) {
        // Fetch the refill request details
        $get_request = "SELECT refill_qty, outlet_district, outlet_name, category FROM refill_requests WHERE id = ?";
        $stmt = $mysqli->prepare($get_request);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $request = $result->fetch_object();

        // Get product details from rpos_products table based on the request details
        $get_product = "SELECT prod_qty FROM rpos_products WHERE prod_category = ? AND outlet = ? AND district = ?";
        $stmt = $mysqli->prepare($get_product);
        $stmt->bind_param('sss', $request->category, $request->outlet_name, $request->outlet_district);
        $stmt->execute();
        $result = $stmt->get_result();
        $product = $result->fetch_object();

        // Update product quantity in rpos_products
        $new_qty = $product->prod_qty + $request->refill_qty;
        $update_product_qty = "UPDATE rpos_products SET prod_qty = ? WHERE prod_category = ? AND outlet = ? AND district = ?";
        $stmt = $mysqli->prepare($update_product_qty);
        $stmt->bind_param('isss', $new_qty, $request->category, $request->outlet_name, $request->outlet_district);
        $stmt->execute();

        // Check and update refill requests in refill_requests_customer table
        $update_customer_refill = "UPDATE refill_requests_customer SET AssignCylinder = 1, status = ? WHERE outlet_district = ? AND outlet_name = ? AND category = ? ";
        $stmt = $mysqli->prepare($update_customer_refill);
        $new_status = 'Ready To Deliver';  // Set the new status value
        $stmt->bind_param('ssss', $new_status, $request->outlet_district, $request->outlet_name, $request->category);
        $stmt->execute();
        

        // Get customer_id from refill_requests_customer
        $get_customer_id = "SELECT customer_id FROM refill_requests_customer WHERE outlet_district = ? AND outlet_name = ? AND category = ?";
        $stmt = $mysqli->prepare($get_customer_id);
        $stmt->bind_param('sss', $request->outlet_district, $request->outlet_name, $request->category);
        $stmt->execute();
        $result = $stmt->get_result();
        $customer_data = $result->fetch_object();

        if ($customer_data) {
            // Fetch customer email based on customer_id from rpos_customers
            $get_customer_email = "SELECT customer_email, customer_name FROM rpos_customers WHERE customer_id = ?";
            $stmt = $mysqli->prepare($get_customer_email);
            $stmt->bind_param('i', $customer_data->customer_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $customer = $result->fetch_object();

            // Send email using PHPMailer
            $mail = new PHPMailer(true);
            try {
                // SMTP Settings
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com'; // Use your SMTP server
                $mail->SMTPAuth   = true;
                $mail->Username   = 'shakeebar9809@gmail.com'; // Your Gmail address
                $mail->Password   = 'ahgb joum brif ivtv'; // SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;

                // Sender & Recipient
                $mail->setFrom('shakeebar9809@gmail.com', 'GasbyGas Refill System');
                $mail->addAddress('nihmanusrath20@gmail.com');

                // Email Content
                $mail->isHTML(true);
                $mail->Subject = "Cylinder Assigned";

                // Get current and tomorrow's date
                $currentDate = date("Y-m-d");
                $tomorrowDate = date("Y-m-d", strtotime("+1 day"));

                // Retrieve session variables
                $district = $_SESSION['district'] ?? 'your district';
                $outletName = $_SESSION['outlet_name'] ?? 'your nearest outlet';

                // Email Content
                $mail->Body = "<p>Dear $customer->customer_name,</p>
                            <p>Your refill request for <strong>$request->category</strong> has been assigned and is <strong>Ready To Deliver</strong>.</p>
                            <p><strong>Pickup Date:</strong> $tomorrowDate</p>
                            <p>Please visit our outlet in <strong>$district</strong> at <strong>$outletName</strong> to make the payment and collect your refill.</p>
                            <p>Thank you for choosing us!</p>";

                $mail->send();
                $success = "Refill Request Confirmed as Received, Customer Requests Updated, Product Quantity Adjusted, and Email Sent!";
                header("refresh:1; url=RefilRequest.php");
            } catch (Exception $e) {
                error_log("Email could not be sent. Mailer Error: {$mail->ErrorInfo}");
                $err = "Error in sending email notification!";
            }
        } else {
            $err = "Error: Customer ID not found!";
        }
    } else {
        $err = "Error in confirming request!";
    }
}

require_once('partials/_head.php');
?>


<body>
    <!-- Sidenav -->
    <?php
    require_once('partials/_sidebar.php');
    ?>
    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php
        require_once('partials/_topnav.php');
        ?>
        <!-- Header -->
        <div style="background-image: url(../admin/assets/img/theme/restro00.jpg); background-size: cover;" class="header pb-8 pt-5 pt-md-8">
            <span class="mask bg-gradient-dark opacity-8"></span>
            <div class="container-fluid">
                <div class="header-body"></div>
            </div>
        </div>
        <!-- Page content -->
        <div class="container-fluid mt--8">
            <!-- Table -->
            <div class="row">
                <div class="col">
                    <div class="card shadow">
                        <div class="card-header border-0">
                            <a href="add_refill_request.php" class="btn btn-outline-success">
                                <i class="fas fa-plus"></i>
                                Add New Refill Request
                            </a>
                        </div>
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col">Request ID</th>
                                        <th scope="col">Manager Name</th>
                                        <th scope="col">Description</th>
                                        <th scope="col">Category</th>
                                        <th scope="col">Refill Qty</th>
                                        <th scope="col">Outlet District</th>
                                        <th scope="col">Outlet Name</th>
                                        <th scope="col">Expected Delivery</th>
                                        <th scope="col">Dispatch Date</th>
                                        <th scope="col">Manager Status</th>
                                        <th scope="col">Dispatch Status</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                        // Get session values
                                        $district = $_SESSION['district'];
                                        $outlet_name = $_SESSION['outlet_name'];

                                        // SQL Query to Fetch Refill Requests with Manager Name and Outlet Filters
                                        $ret = "SELECT rr.*, rs.staff_name 
                                                FROM refill_requests rr 
                                                INNER JOIN outlet_staff rs 
                                                ON rr.manager_id = rs.staff_id 
                                                WHERE rr.outlet_district = ? 
                                                AND rr.outlet_name = ? 
                                                ORDER BY rr.created_date DESC";

                                        $stmt = $mysqli->prepare($ret);
                                        $stmt->bind_param('ss', $district, $outlet_name); // Filter by district and outlet name
                                        $stmt->execute();
                                        $res = $stmt->get_result();
                                        while ($request = $res->fetch_object()) {
                                        ?>

                                        <tr>
                                        <td><?php echo $request->id; ?></td>
                                            <td><?php echo $request->staff_name; ?></td>
                                            <td><?php echo $request->description; ?></td>
                                            <td><?php echo $request->category; ?></td>
                                            <td><?php echo $request->refill_qty; ?></td>
                                            <td><?php echo $request->outlet_district; ?></td>
                                            <td><?php echo $request->outlet_name; ?></td>
                                            <td><?php echo $request->expected_delivery_date; ?></td>
                                            <td>
                                                <?php
                                                if (!empty($request->scheduled_date)) {
                                                    echo $request->scheduled_date;
                                                } else {
                                                    echo "Not Assigned Yet";
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php
                                                if ($request->manager_status == 'Pending') {
                                                    echo '<span class="badge badge-warning">Pending</span>';
                                                } elseif ($request->manager_status == 'Approved') {
                                                    echo '<span class="badge badge-success">Approved</span>';
                                                } elseif ($request->manager_status == 'Rejected') {
                                                    echo '<span class="badge badge-danger">Rejected</span>';
                                                } else {
                                                    echo '<span class="badge badge-warning">Pending</span>';
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php
                                                if ($request->status == 'Pending') {
                                                    echo '<span class="badge badge-warning">Pending</span>';
                                                } elseif ($request->status == 'Approved') {
                                                    echo '<span class="badge badge-success">Approved</span>';
                                                } elseif ($request->status == 'Rejected') {
                                                    echo '<span class="badge badge-danger">Rejected</span>';
                                                } else {
                                                    echo '<span class="badge badge-secondary">Unknown</span>';
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php
                                                // Show Confirm as Received button if status is Approved and isconfirm is 0
                                                if ($request->status == 'Approved' && $request->isconfirm == 0) {
                                                    echo '<a href="RefilRequest.php?confirm_received=' . $request->id . '">
                                                            <button class="btn btn-sm btn-success">
                                                                <i class="fas fa-check"></i>
                                                                Confirm as Received
                                                            </button>
                                                          </a>';
                                                } else {
                                                    echo '<a href="update_refill_request.php?update=' . $request->id . '">
                                                            <button class="btn btn-sm btn-primary">
                                                                <i class="fas fa-edit"></i>
                                                                Update
                                                            </button>
                                                          </a>';
                                                    echo '<a href="RefilRequest.php?delete=' . $request->id . '" onclick="return confirm(\'Are you sure you want to delete this request?\');">
                                                            <button class="btn btn-sm btn-danger">
                                                                <i class="fas fa-trash"></i>
                                                                Delete
                                                            </button>
                                                          </a>';
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer -->
            <?php
            require_once('partials/_footer.php');
            ?>
        </div>
    </div>
    <!-- Argon Scripts -->
    <?php
    require_once('partials/_scripts.php');
    ?>
</body>

</html>
