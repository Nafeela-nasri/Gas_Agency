<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
require_once 'C:/xampp/htdocs/GasAgency/GasAgency/PHPMailer/src/PHPMailer.php';
require_once 'C:/xampp/htdocs/GasAgency/GasAgency/PHPMailer/src/Exception.php';
require_once 'C:/xampp/htdocs/GasAgency/GasAgency/PHPMailer/src/SMTP.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

check_login();

if (!isset($_SESSION['outlet_staff_id'])) {
    die("Unauthorized access! Please log in.");
}

// Function to send email
function sendEmail($to, $subject, $message)
{
    $mail = new PHPMailer(true);
    try {
        // SMTP Settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.example.com'; // Change to your SMTP server
        $mail->SMTPAuth   = true;
        $mail->Username = 'shakeebar9809@gmail.com';                  // Your Gmail address
        $mail->Password = 'ahgb joum brif ivtv';                     // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Sender & Recipient
        $mail->setFrom('GasbyGas.com', 'LPG Refill System');
        $mail->addAddress($to);

        // Email Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $message;

        $mail->send();
    } catch (Exception $e) {
        error_log("Email could not be sent. Mailer Error: {$mail->ErrorInfo}");
    }
}

// Update status logic
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_status'])) {
        $request_id = $_POST['request_id'];
        $new_status = $_POST['status'];

        // Get customer email
        $query = "SELECT rs.customer_email, rs.customer_name, rr.category FROM refill_requests_customer rr
                  INNER JOIN rpos_customers rs ON rr.customer_id = rs.customer_id WHERE rr.request_id = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('i', $request_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $customer = $result->fetch_object();
        $email = $customer->customer_email;
        $name = $customer->customer_name;
        $category = $customer->category;

        $query = "UPDATE refill_requests_customer SET status = ? WHERE request_id = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('si', $new_status, $request_id);

        if ($stmt->execute()) {
            $success = "Status updated successfully!";

            // Send email notification
            $subject = "LPG Refill Request Status Update";
            $message = "<p>Dear $name,</p>
                        <p>Your LPG refill request for <strong>$category</strong> has been updated to: <strong>$new_status</strong>.</p>
                        <p>Thank you for using our services!</p>";
            sendEmail($email, $subject, $message);
        } else {
            $error = "Failed to update status. Please try again.";
        }
    } elseif (isset($_POST['assign_cylinder'])) {
        $request_id = $_POST['request_id'];

        // Fetch category and customer email
        $query = "SELECT rs.customer_email, rs.customer_name, rr.category FROM refill_requests_customer rr
                  INNER JOIN rpos_customers rs ON rr.customer_id = rs.customer_id WHERE rr.request_id = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('i', $request_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $customer = $result->fetch_object();
        $email = $customer->customer_email;
        $name = $customer->customer_name;
        $category = $customer->category;

        // Check available stock
        $query = "SELECT SUM(prod_qty) AS total_qty FROM rpos_products WHERE prod_category = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('s', $category);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_object();
        $available_qty = $row->total_qty ?? 0;

        if ($available_qty > 0) {
            // Reduce stock
            $query = "UPDATE rpos_products SET prod_qty = prod_qty - 1 WHERE prod_category = ? AND prod_qty > 0 LIMIT 1";
            $stmt = $mysqli->prepare($query);
            $stmt->bind_param('s', $category);
    
            if ($stmt->execute() && $stmt->affected_rows > 0) {
                // Update status and assign cylinder
                $query = "UPDATE refill_requests_customer SET Assigncylinder = 1, status = 'Ready To Deliver' WHERE request_id = ?";
                $stmt = $mysqli->prepare($query);
                $stmt->bind_param('i', $request_id);
    
                if ($stmt->execute()) {
                    $success = "Cylinder assigned successfully!";
            
                    // Send email notification using PHPMailer
                    $mail = new PHPMailer(true);
                    try {
                        // SMTP Settings
                        $mail->isSMTP();
                        $mail->Host       = 'smtp.gmail.com'; // Use your SMTP server
                        $mail->SMTPAuth   = true;
                        $mail->Username   = 'shakeebar9809@gmail.com'; // Your Gmail address
                        $mail->Password   = 'ahgb joum brif ivtv'; // SMTP password
                        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                        $mail->Port       = 587;
            
                        // Sender & Recipient
                        $mail->setFrom('shakeebar9809@gmail.com', 'GasbyGas Refill System');
                        $mail->addAddress($email);
            
                        // Email Content
                        $mail->isHTML(true);
                        $mail->Subject = "Cylinder Assigned";
                      // Get current and tomorrow's date
                        $currentDate = date("Y-m-d");
                        $tomorrowDate = date("Y-m-d", strtotime("+1 day"));

                        // Retrieve session variables
                        $district = $_SESSION['district'] ?? 'your district';
                        $outletName = $_SESSION['outlet_name'] ?? 'your nearest outlet';

                        // Email Content
                        $mail->Body = "<p>Dear $name,</p>
                                    <p>Your refill request for <strong>$category</strong> has been assigned and is <strong>Ready To Deliver</strong>.</p>
                                    <p><strong>Pickup Date:</strong> $tomorrowDate</p>
                                    <p>Please visit our outlet in <strong>$district</strong> at <strong>$outletName</strong> to make the payment and collect your refill.</p>
                                    <p>Thank you for choosing us!</p>";

                        $mail->send();
                    } catch (Exception $e) {
                        error_log("Email could not be sent. Mailer Error: {$mail->ErrorInfo}");
                    }
                } else {
                    $error = "Failed to assign cylinder. Please try again.";
                }
            } else {
                $error = "Failed to update product stock. Please try again.";
            }
        } else {
            $error = "No balance available for $category. Please add a refill request.";
        }
    }
}

// Fetch balance quantities
$categories = ["LPG 5 kg", "LPG 12.5 kg", "LPG 15 kg", "LPG 19 kg", "LPG 35 kg", "LPG 45 kg"];
$balances = [];
foreach ($categories as $category) {
    $query = "SELECT SUM(prod_qty) AS total_qty FROM rpos_products WHERE prod_category = ? AND district = ? AND outlet = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param('sss', $category, $_SESSION['district'], $_SESSION['outlet_name']);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_object();
    $balances[$category] = $row->total_qty ?? 0;
}

require_once('partials/_head.php');
?>
<body>
    <!-- Sidenav -->
    <?php require_once('partials/_sidebar.php'); ?>
    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php require_once('partials/_topnav.php'); ?>
        <!-- Header -->
        <div style="background-image: url(../admin/assets/img/theme/restro00.jpg); background-size: cover;" class="header pb-8 pt-5 pt-md-8">
            <span class="mask bg-gradient-dark opacity-8"></span>
            <div class="container-fluid">
                <div class="header-body"></div>
            </div>
        </div>
        <!-- Page content -->
        <div class="container-fluid mt--8">
            <?php if (isset($success)) { ?>
                <div class="alert alert-success">
                    <?php echo $success; ?>
                </div>
            <?php } ?>
            <?php if (isset($error)) { ?>
                <div class="alert alert-danger">
                    <?php echo $error; ?>
                </div>
            <?php } ?>
            
            <!-- Balance quantities in boxes -->
            <div class="row mb-4">
                <?php foreach ($balances as $category => $qty) { ?>
                    <div class="col-md-4 mb-3">
                        <div class="card shadow" style="border-radius: 10px; border: 1px solid #4CAF50;">
                            <div class="card-body text-center">
                                <h5 class="card-title" style="font-weight: bold; color: #4CAF50;">
                                    <?php echo $category; ?>
                                </h5>
                                <p class="card-text" style="font-size: 20px; font-weight: bold; color: #333;">
                                    <?php echo $qty; ?> Units
                                </p>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>

            <!-- Table -->
            <div class="row">
                <div class="col">
                    <div class="card shadow">
                        <div class="card-header border-0"></div>
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col">Request ID</th>
                                        <th scope="col">Customer Name</th>
                                        <th scope="col">Request Type</th>
                                        <th scope="col">Category</th>
                                        <th scope="col">Outlet District</th>
                                        <th scope="col">Outlet Name</th>
                                        <th scope="col">Expected Delivery</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Assign Cylinder</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                        $ret = "SELECT rr.*, rs.customer_name 
                                                FROM refill_requests_customer rr 
                                                INNER JOIN rpos_customers rs ON rr.customer_id = rs.customer_id 
                                                WHERE rr.outlet_district = ? AND rr.outlet_name = ? 
                                                ORDER BY rr.created_at DESC";

                                        $stmt = $mysqli->prepare($ret);
                                        $stmt->bind_param('ss', $_SESSION['district'], $_SESSION['outlet_name']);
                                        $stmt->execute();
                                        $res = $stmt->get_result();

                                        while ($request = $res->fetch_object()) {
                                        ?>

                                        <tr>
                                            <td><?php echo $request->request_id; ?></td>
                                            <td><?php echo $request->customer_name; ?></td>
                                            <td><?php echo $request->request_type; ?></td>
                                            <td><?php echo $request->category; ?></td>
                                            <td><?php echo $request->outlet_district; ?></td>
                                            <td><?php echo $request->outlet_name; ?></td>
                                            <td><?php echo $request->expected_delivery_date; ?></td>
                                            <td style="font-weight: bold; color: <?php echo ($request->status == 'Ready To Deliver') ? 'green' : (($request->status == 'Rejected') ? 'red' : 'orange'); ?>;">
                                                <?php echo $request->status; ?>
                                            </td>
                                            <td>
                                                <?php if ($request->AssignCylinder == 1) { ?>
                                                    <span style="color: green; font-weight: bold;">Already Assigned</span>
                                                <?php } else { ?>
                                                    <form method="POST" action="">
                                                        <input type="hidden" name="request_id" value="<?php echo $request->request_id; ?>">
                                                        <button type="submit" name="assign_cylinder" class="btn btn-sm btn-primary">Assign Cylinder</button>
                                                    </form>
                                                <?php } ?>
                                            </td>
                                            <td>
                                            <?php if ($request->AssignCylinder == 1) { ?>
                                                <span style="color: green; font-weight: bold;">Ready To Deliver</span>
                                                <?php } else { ?>

                                                <form method="POST" action="" style="display: flex; align-items: center;">
                                                    <input type="hidden" name="request_id" value="<?php echo $request->request_id; ?>">
                                                    <select name="status" class="form-control" onchange="this.form.submit()" 
                                                        style="
                                                            width: 160px; 
                                                            height: 32px; 
                                                            border: 1px solid #4CAF50; 
                                                            border-radius: 5px; 
                                                            padding: 2px 8px; 
                                                            background-color: #f9f9f9; 
                                                            font-size: 13px; 
                                                            color: #333; 
                                                            transition: all 0.3s ease-in-out; 
                                                            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
                                                        "
                                                        onfocus="this.style.borderColor='#3e8e41'" 
                                                        onblur="this.style.borderColor='#4CAF50'">
                                                        <option value="Pending" <?php if ($request->status == 'Pending') echo 'selected'; ?>>Pending</option>
                                                        <option value="Approved" <?php if ($request->status == 'Approved') echo 'selected'; ?>>Approved</option>
                                                        <option value="Rejected" <?php if ($request->status == 'Rejected') echo 'selected'; ?>>Rejected</option>

                                                    </select>
                                                    <input type="hidden" name="update_status" value="1">
                                                </form>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer -->
            <?php require_once('partials/_footer.php'); ?>
        </div>
    </div>
    <!-- Argon Scripts -->
    <?php require_once('partials/_scripts.php'); ?>
</body>

</html>
