<?php
session_start();
unset($_SESSION['outlet_staff_id']);
session_destroy();
header("location:http://localhost/GasAgency/GasAgency/GAMS/admin/index.php");
exit;
