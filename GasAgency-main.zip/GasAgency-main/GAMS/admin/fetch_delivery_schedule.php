<?php
include('config/config.php');
header('Content-Type: application/json');

if (isset($_GET['request_id'])) {
    $id = intval($_GET['request_id']);

    $query = "SELECT first_delivery_date, second_delivery_date, third_delivery_date 
              FROM delivery_schedule 
              WHERE district = (SELECT outlet_district FROM refill_requests WHERE id = ?) 
                AND outlet_name = (SELECT outlet_name FROM refill_requests WHERE id = ?)";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param('ii', $id, $id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($result) {
        echo json_encode(['success' => true, 'schedule' => $result]);
    } else {
        echo json_encode(['success' => false]);
    }
}
