<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();

header('Content-Type: application/json');

$response = [];


// Fetch all orders
$orders_query = "SELECT o.*, c.customer_name FROM rpos_orders o JOIN rpos_customers c ON o.customer_id = c.customer_id ORDER BY o.created_at DESC";
$orders_result = $mysqli->query($orders_query);

$orders = [];
while ($row = $orders_result->fetch_assoc()) {
    $orders[] = $row;
}

$response['orders'] = $orders;

// Return JSON response
echo json_encode($response);
$mysqli->close();
?>
