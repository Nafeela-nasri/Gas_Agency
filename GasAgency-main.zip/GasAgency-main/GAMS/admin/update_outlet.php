<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();

// Update Outlet
if (isset($_POST['updateOutlet'])) {
    // Prevent posting blank values
    if (empty($_POST['district']) || empty($_POST['outlet_name'])) {
        $err = "Blank Values Not Accepted";
    } else {
        $district = $_POST['district'];
        $outlet_name = $_POST['outlet_name'];
        $update_id = $_GET['update'];

        // Update the database
        $postQuery = "UPDATE outlets SET district = ?, outlet_name = ? WHERE id = ?";
        $postStmt = $mysqli->prepare($postQuery);
        $rc = $postStmt->bind_param('ssi', $district, $outlet_name, $update_id);
        $postStmt->execute();

        // Declare a variable which will be passed to alert function
        if ($postStmt) {
            $success = "Outlet Updated Successfully" && header("refresh:1; url=outletmanagement.php");
        } else {
            $err = "Please Try Again Or Try Later";
        }
    }
}

require_once('partials/_head.php');
?>

<body>
  <!-- Sidenav -->
  <?php
  require_once('partials/_sidebar.php');
  ?>
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <?php
    require_once('partials/_topnav.php');
    $update_id = $_GET['update'];
    $ret = "SELECT * FROM outlets WHERE id = ?";
    $stmt = $mysqli->prepare($ret);
    $stmt->bind_param('i', $update_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($outlet = $res->fetch_object()) {
    ?>
    <!-- Header -->
    <div style="background-image: url(assets/img/theme/restro00.jpg); background-size: cover;" class="header pb-8 pt-5 pt-md-8">
      <span class="mask bg-gradient-dark opacity-8"></span>
      <div class="container-fluid">
        <div class="header-body"></div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--8">
      <div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0">
              <h3>Update Outlet Details</h3>
            </div>
            <div class="card-body">
              <form method="POST">
                <div class="form-row">
                  <div class="col-md-6">
                    <label>District</label>
                    <select name="district" class="form-control">
                      <option value="" disabled>-- Select District --</option>
                      <option value="Colombo" <?php if ($outlet->district == 'Colombo') echo 'selected'; ?>>Colombo</option>
                      <option value="Gampaha" <?php if ($outlet->district == 'Gampaha') echo 'selected'; ?>>Gampaha</option>
                      <option value="Kandy" <?php if ($outlet->district == 'Kandy') echo 'selected'; ?>>Kandy</option>
                      <option value="Galle" <?php if ($outlet->district == 'Galle') echo 'selected'; ?>>Galle</option>
                      <option value="Jaffna" <?php if ($outlet->district == 'Jaffna') echo 'selected'; ?>>Jaffna</option>
                      <option value="Matara" <?php if ($outlet->district == 'Matara') echo 'selected'; ?>>Matara</option>
                      <option value="Kurunegala" <?php if ($outlet->district == 'Kurunegala') echo 'selected'; ?>>Kurunegala</option>
                      <option value="Anuradhapura" <?php if ($outlet->district == 'Anuradhapura') echo 'selected'; ?>>Anuradhapura</option>
                      <option value="Ratnapura" <?php if ($outlet->district == 'Ratnapura') echo 'selected'; ?>>Ratnapura</option>
                      <option value="Trincomalee" <?php if ($outlet->district == 'Trincomalee') echo 'selected'; ?>>Trincomalee</option>
                      <option value="Hambantota" <?php if ($outlet->district == 'Hambantota') echo 'selected'; ?>>Hambantota</option>
                      <option value="Badulla" <?php if ($outlet->district == 'Badulla') echo 'selected'; ?>>Badulla</option>
                      <option value="Batticaloa" <?php if ($outlet->district == 'Batticaloa') echo 'selected'; ?>>Batticaloa</option>
                      <option value="Polonnaruwa" <?php if ($outlet->district == 'Polonnaruwa') echo 'selected'; ?>>Polonnaruwa</option>
                      <option value="Monaragala" <?php if ($outlet->district == 'Monaragala') echo 'selected'; ?>>Monaragala</option>
                    </select>
                  </div>
                  <div class="col-md-6">
                    <label>Outlet Name</label>
                    <input type="text" name="outlet_name" class="form-control" value="<?php echo $outlet->outlet_name; ?>">
                  </div>
                </div>
                <br>
                <div class="form-row">
                  <div class="col-md-6">
                    <input type="submit" name="updateOutlet" value="Update Outlet" class="btn btn-success">
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
      <?php
      require_once('partials/_footer.php');
    }
      ?>
    </div>
  </div>
  <!-- Argon Scripts -->
  <?php
  require_once('partials/_scripts.php');
  ?>
</body>
</html>
