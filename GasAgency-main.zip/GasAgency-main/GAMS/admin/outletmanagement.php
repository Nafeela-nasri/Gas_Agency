<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();

// Update Outlet Manager on dropdown change
if (isset($_POST['updateManager'])) {
    $outletId = $_POST['outlet_id'];
    $newStaffId = $_POST['staff_id'];

    // Fetch the current manager for the outlet
    $currentManagerQuery = "SELECT outletmanager FROM outlets WHERE id = ?";
    $stmt = $mysqli->prepare($currentManagerQuery);
    $stmt->bind_param('i', $outletId);
    $stmt->execute();
    $stmt->bind_result($currentManagerId);
    $stmt->fetch();
    $stmt->close();

    // Update the current manager's ismanagerassigned to 0 (if there is one)
    if ($currentManagerId) {
        $resetManagerQuery = "UPDATE rpos_staff SET ismanagerassigned = 0 WHERE staff_id = ?";
        $stmt = $mysqli->prepare($resetManagerQuery);
        $stmt->bind_param('i', $currentManagerId);
        $stmt->execute();
        $stmt->close();
    }

    // Assign the new manager and set ismanagerassigned to 1
    $updateOutletQuery = "UPDATE outlets SET outletmanager = ? WHERE id = ?";
    $stmt = $mysqli->prepare($updateOutletQuery);
    $stmt->bind_param('ii', $newStaffId, $outletId);
    $stmt->execute();
    $stmt->close();

    $updateStaffQuery = "UPDATE rpos_staff SET ismanagerassigned = 1 WHERE staff_id = ?";
    $stmt = $mysqli->prepare($updateStaffQuery);
    $stmt->bind_param('i', $newStaffId);
    $stmt->execute();
    $stmt->close();

    if ($stmt) {
        $success = "Outlet Manager Assigned Successfully";
    } else {
        $err = "Failed To Assign Outlet Manager. Try Again.";
    }
}

require_once('partials/_head.php');
?>

<body>
  <!-- Sidenav -->
  <?php require_once('partials/_sidebar.php'); ?>
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <?php require_once('partials/_topnav.php'); ?>
    <!-- Header -->
    <div style="background-image: url(assets/img/theme/outlet-bg.jpg); background-size: cover;" class="header pb-8 pt-5 pt-md-8">
      <span class="mask bg-gradient-dark opacity-8"></span>
      <div class="container-fluid">
        <div class="header-body"></div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--8">
      <!-- Table -->
      <div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0">
              <a href="add_outlet.php" class="btn btn-outline-success">
                <i class="fas fa-plus-circle"></i>
                Add New Outlet
              </a>
            </div>
            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">District Name</th>
                    <th scope="col">Outlet Name</th>
                    <th scope="col">Outlet Manager</th>
                    <th scope="col">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $ret = "SELECT * FROM outlets";
                  $stmt = $mysqli->prepare($ret);
                  $stmt->execute();
                  $res = $stmt->get_result();
                  while ($outlet = $res->fetch_object()) {
                  ?>
                    <tr>
                      <td><?php echo $outlet->district; ?></td>
                      <td><?php echo $outlet->outlet_name; ?></td>
                      <td>
                        <form method="POST" class="d-inline">
                          <input type="hidden" name="outlet_id" value="<?php echo $outlet->id; ?>">
                          <select name="staff_id" class="form-control" onchange="this.form.submit()">
                            <option value="" disabled selected>Assign Manager</option>
                            <?php
                            $staffQuery = "SELECT staff_id, staff_name FROM rpos_staff WHERE ismanagerassigned = 0 OR staff_id = ?";
                            $stmtStaff = $mysqli->prepare($staffQuery);
                            $stmtStaff->bind_param('i', $outlet->outletmanager);
                            $stmtStaff->execute();
                            $staffRes = $stmtStaff->get_result();
                            while ($staff = $staffRes->fetch_object()) {
                              $selected = ($staff->staff_id == $outlet->outletmanager) ? "selected" : "";
                              echo "<option value='$staff->staff_id' $selected>$staff->staff_name</option>";
                            }
                            ?>
                          </select>
                          <input type="hidden" name="updateManager" value="1">
                        </form>
                      </td>
                      <td>
                        <a href="manage_outlets.php?delete=<?php echo $outlet->id; ?>">
                          <button class="btn btn-sm btn-danger">
                            <i class="fas fa-trash"></i>
                            Delete
                          </button>
                        </a>

                        <a href="update_outlet.php?update=<?php echo $outlet->id; ?>">
                          <button class="btn btn-sm btn-primary">
                            <i class="fas fa-edit"></i>
                            Update
                          </button>
                        </a>
                      </td>
                    </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
      <?php require_once('partials/_footer.php'); ?>
    </div>
  </div>
  <!-- Argon Scripts -->
  <?php require_once('partials/_scripts.php'); ?>
</body>

</html>
