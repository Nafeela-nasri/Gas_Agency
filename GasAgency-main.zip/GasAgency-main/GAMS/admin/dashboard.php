<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();
require_once('partials/_head.php');
require_once('partials/_analytics.php');
?>

<body style="background-color:rgb(141, 148, 160);"> <!-- Set the background color to light gray -->
  <?php require_once('partials/_sidebar.php'); ?>
  <div class="main-content" style="background-color: #f4f6f9;"> <!-- Main content background -->
    <?php require_once('partials/_topnav.php'); ?>
    
    <div class="header pb-8 pt-5 pt-md-8" style="background: linear-gradient(to right,rgb(142, 130, 130), #dcdcdc);"> <!-- Professional gradient header -->
      <div class="container-fluid">
        <div class="header-body">
          <div class="row">
            <div class="col-xl-4 col-lg-6">
              <div class="card card-stats" style="background-color: #ffffff; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);">
                <div class="card-body">
                  <h5 class="card-title text-uppercase text-muted mb-0">Total Outlets</h5>
                  <span class="h2 font-weight-bold mb-0" id="outlets-count">Loading...</span>
                </div>
              </div>
            </div>
            <div class="col-xl-4 col-lg-6">
              <div class="card card-stats" style="background-color: #ffffff; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);">
                <div class="card-body">
                  <h5 class="card-title text-uppercase text-muted mb-0">Total Refill Requests</h5>
                  <span class="h2 font-weight-bold mb-0" id="refill-count">Loading...</span>
                </div>
              </div>
            </div>
            <div class="col-xl-4 col-lg-6">
              <div class="card card-stats" style="background-color: #ffffff; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);">
                <div class="card-body">
                  <h5 class="card-title text-uppercase text-muted mb-0">Total Inventory</h5>
                  <span class="h2 font-weight-bold mb-0" id="inventory-count">Loading...</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="container-fluid mt--7">
      <div class="row">
        <div class="col-xl-6">
          <div class="card shadow" style="background-color: #ffffff; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);">
            <div class="card-header">Sales Overview</div>
            <div class="card-body">
              <canvas id="salesChart"></canvas>
            </div>
          </div>
        </div>
        <div class="col-xl-5">
          <div class="card shadow" style="height: 390px; background-color: #ffffff; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);">
            <div class="card-header">Orders Analysis</div>
            <div class="card-body" style="height: 20px; margin-left: 100px;">
              <canvas id="ordersChart"></canvas>
            </div> 
          </div>
        </div>
      </div>
      
      <div class="row mt-5">
        <div class="col-xl-12">
          <div class="card shadow" style="background-color: #ffffff; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);">
            <div class="card-header">Recent Orders</div>
            <div class="card-body" style="padding: 0 15px;">
              <!-- Search Box -->
              <div class="search-box mb-3">
                <input type="text" id="searchInput" class="form-control" placeholder="Search orders..." />
              </div>
              
              <!-- Orders Table -->
              <table class="table table-striped" id="ordersTable" style="background-color: #ffffff;">
                <thead>
                  <tr>
                    <th>Code</th>
                    <th>Customer</th>
                    <th>Product</th>
                    <th>Qty</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <!-- Data will be filled dynamically using DataTables -->
                </tbody>
              </table>
              
              <!-- Pagination Controls -->
              <div class="pagination-controls text-left mt-3">
                <button type="button" class="btn btn-primary" id="prevBtn">Previous</button>
                <button type="button" class="btn btn-primary" id="nextBtn">Next</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <?php require_once('partials/_footer.php'); ?>
    </div>
  </div>
  
  <?php require_once('partials/_scripts.php'); ?>
  
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
  <script>
    $(document).ready(function () {
      // Fetch dashboard counts
      $.ajax({
        url: 'fetch_dashboard_data.php',
        method: 'GET',
        dataType: 'json',
        success: function (data) {
          $('#outlets-count').text(data.total_outlets);
          $('#refill-count').text(data.total_refill_requests);
          $('#inventory-count').text(data.total_inventory);
        },
        error: function () {
          console.error('Error fetching dashboard data');
        }
      });

      // Initialize DataTable for recent orders with custom pagination
      const ordersTable = $('#ordersTable').DataTable({
        ajax: {
          url: 'fetch_orders.php',
          method: 'GET',
          dataType: 'json',
          dataSrc: 'orders'
        },
        columns: [
          { data: 'order_code' },
          { data: 'customer_name' },
          { data: 'prod_name' },
          { data: 'prod_qty' },
          { data: 'order_status' }
        ],
        pageLength: 5, // Show 5 records per page
        pagingType: "simple", // Show only 'Previous' and 'Next' buttons
        language: {
          paginate: {
            next: 'Next',
            previous: 'Previous'
          }
        },
        dom: 'Bfrtip', // For additional control over DataTable features (like buttons)
        searching: false // Disable default search box
      });

      // Handling the search feature
      $('#searchInput').on('keyup', function () {
        ordersTable.search(this.value).draw();
      });

      // Pagination Button functionality
      $('#prevBtn').click(function () {
        if (ordersTable.page() > 0) {
          ordersTable.page('previous').draw('page');
        }
      });

      $('#nextBtn').click(function () {
        if (ordersTable.page() < ordersTable.page.info().pages - 1) {
          ordersTable.page('next').draw('page');
        }
      });

      // Fetch and display chart data
      $.ajax({
        url: 'fetch_chart_data.php',
        method: 'GET',
        dataType: 'json',
        success: function (data) {
          // Sales Overview Chart
          const salesLabels = data.monthly_income.map(item => item.month); 
          const salesData = data.monthly_income.map(item => item.total);
          new Chart(document.getElementById('salesChart'), {
            type: 'line',
            data: {
              labels: salesLabels,
              datasets: [{
                label: 'Sales',
                data: salesData,
                borderColor: 'blue',
                fill: false
              }]
            }
          });

          // Orders Analysis Chart
          const ordersLabels = data.monthly_orders.map(item => item.month); 
          const ordersData = data.monthly_orders.map(item => item.total);
          new Chart(document.getElementById('ordersChart'), {
            type: 'pie',
            data: {
              labels: ordersLabels,
              datasets: [{
                data: ordersData,
                backgroundColor: ['green', 'red']
              }]
            }
          });
        },
        error: function () {
          console.error('Error fetching chart data');
        }
      });
    });
  </script>

  <style>
    /* Custom Styles for Table and Pagination */
    #ordersTable {
      font-size: 14px;
      border-collapse: collapse;
      width: 100%;
    }
    
    #ordersTable th, #ordersTable td {
      padding: 12px;
      border: 1px solid #ddd;
      text-align: left;
    }

    #ordersTable th {
      background-color: #f2f2f2;
    }

    #ordersTable tbody tr:hover {
      background-color: #f1f1f1;
    }

    .search-box input {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 14px;
    }

    .pagination-controls button {
      margin: 0 10px;
      padding: 8px 15px;
      font-size: 14px;
      border: none;
      border-radius: 4px;
      background-color: #007bff;
      color: white;
      cursor: pointer;
    }

    .pagination-controls button:hover {
      background-color: #0056b3;
    }

    .pagination-controls button:disabled {
      background-color: #dcdcdc;
      cursor: not-allowed;
    }
  </style>
</body>
</html>
