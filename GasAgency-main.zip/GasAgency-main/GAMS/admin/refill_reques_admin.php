<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();
require_once 'C:/xampp/htdocs/GasAgency/GasAgency/PHPMailer/src/PHPMailer.php';
require_once 'C:/xampp/htdocs/GasAgency/GasAgency/PHPMailer/src/Exception.php';
require_once 'C:/xampp/htdocs/GasAgency/GasAgency/PHPMailer/src/SMTP.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
// Handle status update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $id = intval($_POST['request_id']);
    $status = $_POST['status'];
    $update_query = "UPDATE refill_requests SET status = ? WHERE id = ?";
    $stmt = $mysqli->prepare($update_query);
    $stmt->bind_param('si', $status, $id);
    $stmt->execute();
    $stmt->close();
    if ($stmt) {
        $success = "Status updated successfully." && header("refresh:1; url=refill_reques_admin.php");
    } else {
        $err = "Failed to update status. Try again.";
    }
}

// Handle scheduled date saving
if (isset($_POST['save_schedule'])) {
    $refill_request_id = intval($_POST['refill_request_id']);
    $scheduled_date = $_POST['scheduled_date'];
    $status = $_POST['status'];

    // Step 1: Retrieve the category, outlet_district, and outlet_name from the refill_requests table
    $query = "SELECT category, outlet_district, outlet_name FROM refill_requests WHERE id = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param('i', $refill_request_id);
    $stmt->execute();
    $stmt->bind_result($category, $outlet_district, $outlet_name);
    $stmt->fetch();
    $stmt->close();

    // Step 2: Search in refill_requests_customer for matching outlet_district, outlet_name, and category
    $query_customer = "SELECT customer_id, request_id FROM refill_requests_customer 
                       WHERE outlet_district = ? AND outlet_name = ? AND category = ?";
    $stmt_customer = $mysqli->prepare($query_customer);
    $stmt_customer->bind_param('sss', $outlet_district, $outlet_name, $category);
    $stmt_customer->execute();
    $stmt_customer->bind_result($customer_id, $request_id);
    $stmt_customer->fetch();
    $stmt_customer->close();

    // Step 3: Check if matching customer_id exists in rpos_customers table and retrieve the customer email
    $query_customer_email = "SELECT customer_email FROM rpos_customers WHERE customer_id = ?";
    $stmt_email = $mysqli->prepare($query_customer_email);
    $stmt_email->bind_param('i', $customer_id);
    $stmt_email->execute();
    $stmt_email->bind_result($customer_email);
    $stmt_email->fetch();
    $stmt_email->close();

    // Step 4: Calculate checkday (4 days before scheduled_date)
    $checkday = date("Y-m-d", strtotime($scheduled_date . " -4 days"));

    // Step 5: Update refill_requests table with the scheduled date and status
    $update_query = "UPDATE refill_requests SET status = ?, scheduled_date = ? WHERE id = ?";
    $stmt_update = $mysqli->prepare($update_query);
    $stmt_update->bind_param('ssi', $status, $scheduled_date, $refill_request_id);
    $stmt_update->execute();
    $stmt_update->close();

    // Step 6: Send email notification using PHPMailer
    if ($stmt_update) {
        $success = "Scheduled date saved successfully.";



        // Send email notification
        $mail = new PHPMailer(true);
        try {
            // SMTP Settings
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com'; // Use your SMTP server
            $mail->SMTPAuth   = true;
            $mail->Username   = 'shakeebar9809@gmail.com'; // Your Gmail address
            $mail->Password   = 'ahgb joum brif ivtv'; // SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;

            // Sender & Recipient
            $mail->setFrom('shakeebar9809@gmail.com', 'GasbyGas Refill System');
            $mail->addAddress($customer_email);

            // Email Content
            $mail->isHTML(true);
            $mail->Subject = "Cylinder Pickup Information";

            // Email Body
            $mail->Body = "<p>Dear Sir/Madam,</p>
                            <p>Your Request Token ID: <strong>$request_id</strong> for category <strong>$category</strong> will be available at <strong>$outlet_district</strong> at <strong>$outlet_name</strong> on <strong>$scheduled_date</strong>.</p>
                            <p>Please make the payment and handover your Cylinder before <strong>$checkday</strong>.</p>
                            <p>Thank you for choosing us!</p>";

            // Send the email
            $mail->send();
        } catch (Exception $e) {
            error_log("Email could not be sent. Mailer Error: {$mail->ErrorInfo}");
        }

        // Redirect to the page with success message
        header("refresh:1; url=refill_reques_admin.php");
    } else {
        $err = "Failed to save scheduled date. Try again.";
    }
}



require_once('partials/_head.php');
?>

<body>
    <!-- Sidenav -->
    <?php require_once('partials/_sidebar.php'); ?>

    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php require_once('partials/_topnav.php'); ?>

        <!-- Header -->
        <div style="background-image: url(assets/img/theme/restro00.jpg); background-size: cover;" class="header pb-8 pt-5 pt-md-8">
            <span class="mask bg-gradient-dark opacity-8"></span>
            <div class="container-fluid">
                <div class="header-body"></div>
            </div>
        </div>

        <!-- Page content -->
        <div class="container-fluid mt--8">
            <!-- Success/Error Messages -->
            <!-- <?php if (isset($success)) { ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php } ?>
            <?php if (isset($err)) { ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $err; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php } ?> -->

            <!-- Table -->
            <div class="row">
                <div class="col">
                    <div class="card shadow">
                        <div class="card-header border-0">
                            Refill Requests
                        </div>
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col">Request ID</th>
                                        <th scope="col">Manager Name</th>
                                        <th scope="col">Description</th>
                                        <th scope="col">Category</th>
                                        <th scope="col">Refill Qty</th>
                                        <th scope="col">Outlet District</th>
                                        <th scope="col">Outlet Name</th>
                                        <th scope="col">Expected Delivery</th>
                                        <th scope="col">Dispacth Status</th>
                                        <th scope="col">Manager Status</th>
                                        <th scope="col" style="width: 200px;">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $ret = "SELECT rr.*, rs.staff_name FROM refill_requests rr INNER JOIN rpos_staff rs ON rr.manager_id = rs.staff_id  WHERE rr.isapproved_by_outlet_manager = 1  ORDER BY rr.created_date DESC";
                                    $stmt = $mysqli->prepare($ret);
                                    $stmt->execute();
                                    $res = $stmt->get_result();
                                    while ($request = $res->fetch_object()) {
                                    ?>
                                        <tr>
                                            <td><?php echo $request->id; ?></td>
                                            <td><?php echo $request->staff_name; ?></td>
                                            <td><?php echo $request->description; ?></td>
                                            <td><?php echo $request->category; ?></td>
                                            <td><?php echo $request->refill_qty; ?></td>
                                            <td><?php echo $request->outlet_district; ?></td>
                                            <td><?php echo $request->outlet_name; ?></td>
                                            <td><?php echo $request->expected_delivery_date; ?></td>
                                            <td>
                                                <span class="badge <?php
                                                    switch ($request->status) {
                                                        case 'Pending':
                                                            echo 'badge-warning';
                                                            break;
                                                        case 'Approved':
                                                            echo 'badge-success';
                                                            break;
                                                        case 'Rejected':
                                                            echo 'badge-danger';
                                                            break;
                                                        default:
                                                            echo 'badge-light';
                                                            break;
                                                    }
                                                ?>">
                                                    <?php echo $request->status; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge <?php
                                                    switch ($request->manager_status) {
                                                        case 'Pending':
                                                            echo 'badge-warning';
                                                            break;
                                                        case 'Approved':
                                                            echo 'badge-success';
                                                            break;
                                                        case 'Rejected':
                                                            echo 'badge-danger';
                                                            break;
                                                        default:
                                                            echo 'badge-light';
                                                            break;
                                                    }
                                                ?>">
                                                    <?php echo $request->manager_status; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($request->status != 'Approved'): ?>
                                                    <form method="POST" action="">
                                                        <input type="hidden" name="request_id" value="<?php echo $request->id; ?>">
                                                        <select name="status" class="form-select" style="min-width: 150px;" onchange="handleStatusChange(this, <?php echo $request->id; ?>)">
                                                            <option value="Pending" <?php if ($request->status == 'Pending') echo 'selected'; ?>>Pending</option>
                                                            <option value="Approved" <?php if ($request->status == 'Approved') echo 'selected'; ?>>Approved</option>
                                                            <option value="Rejected" <?php if ($request->status == 'Rejected') echo 'selected'; ?>>Rejected</option>
                                                        </select>
                                                        <input type="hidden" name="update_status" value="1">
                                                    </form>
                                                <?php endif; ?>
                                            </td>

                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="scheduleModal" tabindex="-1" aria-labelledby="scheduleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form method="POST" action="">
                            <div class="modal-header">
                                <h5 class="modal-title" id="scheduleModalLabel">Select Scheduled Date</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="refill_request_id" id="refill_request_id" value="">
                                <input type="hidden" name="status" value="Approved"> <!-- Hidden status field -->
                   
                                <div class="form-group">
                                    <label for="scheduled_date">Choose Date</label>
                                    <select name="scheduled_date" id="scheduled_date" class="form-select"></select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" name="save_schedule" class="btn btn-primary">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>



            <!-- Footer -->
            <?php require_once('partials/_footer.php'); ?>
        </div>
    </div>

    <!-- Argon Scripts -->
    <?php require_once('partials/_scripts.php'); ?>

    <script>
function handleStatusChange(select, requestId) {
    const form = select.closest('form'); // Get the parent form of the select element

    // If the selected status is "Approved", fetch delivery dates and show the modal
    if (select.value === 'Approved') {
        // Fetch delivery dates for the "Approved" status
        fetch(`fetch_delivery_schedule.php?request_id=${requestId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const modal = new bootstrap.Modal(document.getElementById('scheduleModal'));
                    const dropdown = document.getElementById('scheduled_date');
                    dropdown.innerHTML = ''; // Clear existing options

                    // Populate dropdown with delivery dates
                    Object.entries(data.schedule).forEach(([key, date]) => {
                        const option = document.createElement('option');
                        option.value = date;
                        option.textContent = `${key.replace(/_/g, ' ')}: ${date}`;
                        dropdown.appendChild(option);
                    });

                    document.getElementById('refill_request_id').value = requestId;
                    modal.show();
                } else {
                    alert('No delivery schedule found for this outlet.');
                }
            })
            .catch(error => console.error('Error fetching delivery schedule:', error));
    }

    // For any other status change, submit the form to update the status in the database
    else {
        form.submit(); // Submit the form immediately to update the status
    }
}
</script>



    <!-- Include Bootstrap JS -->
    
 

 
