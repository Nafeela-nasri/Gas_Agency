<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();
require_once('partials/_head.php');

// Fetch product quantity data
$query = "SELECT prod_name, prod_qty FROM rpos_products ORDER BY prod_qty DESC";
$result = mysqli_query($mysqli, $query);

$product_names = [];
$product_quantities = [];

while ($row = mysqli_fetch_assoc($result)) {
    $product_names[] = $row['prod_name'];
    $product_quantities[] = $row['prod_qty'];
}
?>

<body>
    <!-- Sidebar -->
    <?php require_once('partials/_sidebar.php'); ?>

    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php require_once('partials/_topnav.php'); ?>

        <!-- Header -->
        <div class="bg-gradient-primary pt-5 pb-8">
            <div class="container-fluid">
                <div class="header-body text-center">
                    <h2 class="text-white display-3">Product Quantity Report</h2>
                    <p class="text-white mb-0">Overview of product quantities </p>
                </div>
            </div>
        </div>

        <!-- Page content -->
        <div class="container-fluid mt--8">
            <div class="row">
                <div class="col-xl-8 col-lg-12 col-md-12">
                    <div class="card shadow border-0">
                        <div class="card-body">
                            <h5 class="card-title">Product Quantity Overview</h5>
                            <canvas id="quantity_chart" style="height: 400px;"></canvas>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-12 col-md-12">
                    <div class="card shadow border-0">
                        <div class="card-header bg-transparent">
                            <h5 class="mb-0">Actions</h5>
                        </div>
                        <div class="card-body">
                            <div class="btn-group-vertical w-100">
                                <button class="btn btn-outline-primary btn-lg mb-3" onclick="downloadPDF()">
                                    <i class="fas fa-file-pdf"></i> Download PDF
                                </button>
                                <button class="btn btn-outline-success btn-lg mb-3" onclick="downloadExcel()">
                                    <i class="fas fa-file-excel"></i> Download Excel
                                </button>
                                <button class="btn btn-outline-info btn-lg" onclick="downloadCSV()">
                                    <i class="fas fa-file-csv"></i> Download CSV
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col">
                    <div class="card shadow border-0">
                        <div class="card-header bg-transparent">
                            <h5 class="mb-0">Product List</h5>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover" id="product_table">
                                <thead class="thead-light">
                                    <tr>
                                        <th>Product Name</th>
                                        <th>Quantity</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($product_names as $index => $name) { ?>
                                        <tr>
                                            <td><?php echo $name; ?></td>
                                            <td><?php echo $product_quantities[$index]; ?></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- Footer -->
        <?php require_once('partials/_footer.php'); ?>
    </div>

    <!-- Include Bootstrap and Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Quantity Chart Script -->
    <script>
        window.onload = function () {
            var ctx = document.getElementById("quantity_chart").getContext('2d');
            var quantityChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($product_names); ?>,
                    datasets: [{
                        label: 'Product Quantity',
                        backgroundColor: '#4e73df',
                        borderColor: '#4e73df',
                        borderWidth: 1,
                        data: <?php echo json_encode($product_quantities); ?>,
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Quantity'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Products'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: true,
                            position: 'top'
                        }
                    }
                }
            });
        };
    </script>

    <!-- Download Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.23/jspdf.plugin.autotable.min.js"></script>

    <script>
        function downloadPDF() {
            const { jsPDF } = window.jspdf;
            let doc = new jsPDF();
            doc.text("Product Quantity Report", 20, 10);
            doc.autoTable({ html: '#product_table', startY: 20 });
            doc.save("Product_Quantity_Report.pdf");
        }

        function downloadCSV() {
            let table = document.getElementById("product_table");
            let rows = Array.from(table.rows);
            let csvContent = rows.map(row => Array.from(row.cells).map(cell => cell.textContent).join(",")).join("\n");
            let blob = new Blob([csvContent], { type: "text/csv" });
            let link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = "Product_Quantity_Report.csv";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        function downloadExcel() {
            let table = document.getElementById("product_table");
            let rows = Array.from(table.rows);
            let xlsContent = rows.map(row => `<tr>${Array.from(row.cells).map(cell => `<td>${cell.textContent}</td>`).join("")}</tr>`).join("");
            let excelFile = `<table>${xlsContent}</table>`;
            let blob = new Blob([excelFile], { type: "application/vnd.ms-excel" });
            let link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = "Product_Quantity_Report.xls";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    </script>

    <!-- Argon Scripts -->
    <?php require_once('partials/_scripts.php'); ?>
</body>
</html>
