<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();
require_once('partials/_head.php');

// Retrieve revenue data from database (Grouped by Date)
$sql = "SELECT DATE(created_at) as revenue_date, SUM(pay_amt) as total_revenue FROM rpos_payments GROUP BY DATE(created_at) ORDER BY revenue_date ASC";
$result = mysqli_query($mysqli, $sql);

$dates = array();
$revenues = array();

while ($row = mysqli_fetch_assoc($result)) {
    $dates[]  = $row['revenue_date'];
    $revenues[] = $row['total_revenue'];
}
?>

<body>
    <!-- Sidebar -->
    <?php require_once('partials/_sidebar.php'); ?>

    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php require_once('partials/_topnav.php'); ?>

        <!-- Header -->
        <div class="bg-gradient-primary pt-5 pb-8">
            <div class="container-fluid">
                <div class="header-body text-center">
                    <h2 class="text-white display-3">Revenue Report</h2>
                    <p class="text-white mb-0">Overview of daily revenue </p>
                </div>
            </div>
        </div>

        <!-- Page content -->
        <div class="container-fluid mt--8">
            <!-- Revenue Chart -->
            <div class="row">
                <div class="col-xl-8 col-lg-12 col-md-12">
                    <div class="card shadow border-0">
                        <div class="card-body">
                            <h5 class="card-title">Revenue Overview</h5>
                            <canvas id="revenue_chart" style="height: 400px;"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Download Buttons -->
                <div class="col-xl-4 col-lg-12 col-md-12">
                    <div class="card shadow border-0">
                        <div class="card-header bg-transparent">
                            <h5 class="mb-0">Actions</h5>
                        </div>
                        <div class="card-body">
                            <div class="btn-group-vertical w-100">
                                <button class="btn btn-outline-primary btn-lg mb-3" onclick="downloadPDF()">
                                    <i class="fas fa-file-pdf"></i> Download PDF
                                </button>
                                <button class="btn btn-outline-success btn-lg mb-3" onclick="downloadExcel()">
                                    <i class="fas fa-file-excel"></i> Download Excel
                                </button>
                                <button class="btn btn-outline-info btn-lg" onclick="downloadCSV()">
                                    <i class="fas fa-file-csv"></i> Download CSV
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <?php require_once('partials/_footer.php'); ?>
        </div>
    </div>

    <!-- Include Bootstrap and Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Revenue Chart Script -->
    <script>
        window.onload = function () {
            var ctx = document.getElementById("revenue_chart").getContext('2d');
            var revenueChart = new Chart(ctx, {
                type: 'line', // Line chart for revenue trend
                data: {
                    labels: <?php echo json_encode($dates); ?>,
                    datasets: [{
                        label: 'Revenue ($)',
                        backgroundColor: "rgba(75, 192, 192, 0.2)",
                        borderColor: "rgba(75, 192, 192, 1)",
                        borderWidth: 2,
                        pointBackgroundColor: "rgba(75, 192, 192, 1)",
                        data: <?php echo json_encode($revenues); ?>,
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Total Revenue ($)'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Date'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: true,
                            position: 'top'
                        }
                    }
                }
            });
        }
    </script>

    <!-- Download Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.23/jspdf.plugin.autotable.min.js"></script>

    <script>
        function downloadPDF() {
            const { jsPDF } = window.jspdf;
            let doc = new jsPDF();
            doc.text("Revenue Report", 20, 10);
            doc.autoTable({ html: '#revenue_chart', startY: 20 });
            doc.save("Revenue_Report.pdf");
        }

        function downloadCSV() {
            let table = document.getElementById("revenue_chart");
            let rows = Array.from(table.rows);
            let csvContent = rows.map(row => Array.from(row.cells).map(cell => cell.textContent).join(",")).join("\n");
            let blob = new Blob([csvContent], { type: "text/csv" });
            let link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = "Revenue_Report.csv";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        function downloadExcel() {
            let table = document.getElementById("revenue_chart");
            let rows = Array.from(table.rows);
            let xlsContent = rows.map(row => `<tr>${Array.from(row.cells).map(cell => `<td>${cell.textContent}</td>`).join("")}</tr>`).join("");
            let excelFile = `<table>${xlsContent}</table>`;
            let blob = new Blob([excelFile], { type: "application/vnd.ms-excel" });
            let link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = "Revenue_Report.xls";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    </script>

    <!-- Argon Scripts -->
    <?php require_once('partials/_scripts.php'); ?>
</body>
</html>
