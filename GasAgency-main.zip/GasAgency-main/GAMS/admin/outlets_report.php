<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();
require_once('partials/_head.php');

// Fetch outlet details with related refill requests
$query = "SELECT o.id, o.district, o.outlet_name,
          (SELECT COUNT(*) FROM refill_requests_customer WHERE outlet_name = o.outlet_name) AS customer_refills,
          (SELECT COUNT(*) FROM refill_requests WHERE outlet_name = o.outlet_name) AS outlet_refills
          FROM outlets o ORDER BY o.district ASC";
$result = mysqli_query($mysqli, $query);
$outlet_reports = [];
$labels = [];
$customerRefills = [];
$outletRefills = [];

while ($row = mysqli_fetch_assoc($result)) {
    $outlet_reports[] = $row;
    $labels[] = $row['outlet_name'];
    $customerRefills[] = $row['customer_refills'];
    $outletRefills[] = $row['outlet_refills'];
}
?>

<body>
    <!-- Sidebar -->
    <?php require_once('partials/_sidebar.php'); ?>

    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php require_once('partials/_topnav.php'); ?>

        <!-- Header -->
        <div class="bg-gradient-primary pt-5 pb-8">
            <div class="container-fluid">
                <div class="header-body text-center">
                    <h2 class="text-white display-3">Outlet Report</h2>
                    <p class="text-white mb-0">Overview of refill requests for each outlet</p>
                </div>
            </div>
        </div>

        <!-- Page content -->
        <div class="container-fluid mt--8">
            <div class="row">
                <div class="col-xl-8 col-lg-12 col-md-12">
                    <div class="card shadow border-0">
                        <div class="card-body">
                            <h5 class="card-title">Refill Request Overview</h5>
                            <canvas id="refillChart" style="height: 400px;"></canvas>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-12 col-md-12">
                    <div class="card shadow border-0">
                        <div class="card-header bg-transparent">
                            <h5 class="mb-0">Actions</h5>
                        </div>
                        <div class="card-body">
                            <div class="btn-group-vertical w-100">
                                <button class="btn btn-outline-danger btn-lg mb-3" onclick="downloadPDF()">
                                    <i class="fas fa-file-pdf"></i> Download PDF
                                </button>
                                <button class="btn btn-outline-success btn-lg mb-3" onclick="downloadExcel()">
                                    <i class="fas fa-file-excel"></i> Download Excel
                                </button>
                                <button class="btn btn-outline-primary btn-lg" onclick="downloadCSV()">
                                    <i class="fas fa-file-csv"></i> Download CSV
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col">
                    <div class="card shadow border-0">
                        <div class="card-header bg-transparent">
                            <h5 class="mb-0">Outlet List</h5>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover" id="outlet_table">
                                <thead class="thead-light">
                                    <tr>
                                        <th>Outlet ID</th>
                                        <th>District</th>
                                        <th>Outlet Name</th>
                                        <th>Customer Refill Requests</th>
                                        <th>Outlet Refill Requests</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($outlet_reports as $row) { ?>
                                        <tr>
                                            <td><?php echo $row['id']; ?></td>
                                            <td><?php echo $row['district']; ?></td>
                                            <td><?php echo $row['outlet_name']; ?></td>
                                            <td><?php echo $row['customer_refills']; ?></td>
                                            <td><?php echo $row['outlet_refills']; ?></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- Footer -->
        <?php require_once('partials/_footer.php'); ?>
    </div>

    <!-- Include Bootstrap and Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Refill Chart Script -->
    <script>
        let ctx = document.getElementById('refillChart').getContext('2d');
        let refillChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($labels); ?>,
                datasets: [
                    {
                        label: 'Customer Refill Requests',
                        data: <?php echo json_encode($customerRefills); ?>,
                        backgroundColor: 'rgba(54, 162, 235, 0.6)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Outlet Refill Requests',
                        data: <?php echo json_encode($outletRefills); ?>,
                        backgroundColor: 'rgba(255, 99, 132, 0.6)',
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        function downloadPDF() {
            const { jsPDF } = window.jspdf;
            let doc = new jsPDF();
            doc.text("Outlet Refill Request Report", 20, 10);
            doc.autoTable({ html: '#outlet_table', startY: 20 });
            doc.save("Outlet_Refill_Request_Report.pdf");
        }

        function downloadCSV() {
            let table = document.getElementById("outlet_table");
            let rows = Array.from(table.rows);
            let csvContent = rows.map(row => Array.from(row.cells).map(cell => cell.textContent).join(",")).join("\n");
            let blob = new Blob([csvContent], { type: "text/csv" });
            let link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = "Outlet_Refill_Request_Report.csv";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        function downloadExcel() {
            let table = document.getElementById("outlet_table");
            let rows = Array.from(table.rows);
            let xlsContent = rows.map(row => `<tr>${Array.from(row.cells).map(cell => `<td>${cell.textContent}</td>`).join("")}</tr>`).join("");
            let excelFile = `<table>${xlsContent}</table>`;
            let blob = new Blob([excelFile], { type: "application/vnd.ms-excel" });
            let link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = "Outlet_Refill_Request_Report.xls";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    </script>

    <!-- Argon Scripts -->
    <?php require_once('partials/_scripts.php'); ?>
</body>
</html>
