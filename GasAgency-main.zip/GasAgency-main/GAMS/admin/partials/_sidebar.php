<?php
$admin_id = $_SESSION['aadmin_id'];
$ret = "SELECT * FROM rpos_aadmin WHERE aadmin_id = '$admin_id'";
$stmt = $mysqli->prepare($ret);
$stmt->execute();
$res = $stmt->get_result();
while ($admin = $res->fetch_object()) {

  $current_page = basename($_SERVER['PHP_SELF']);

?>
  <nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
      <!-- Toggler -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <!-- Brand -->
      <a class="navbar-brand pt-0" href="dashboard.php" 
   style="text-decoration: none; display: flex; align-items: center; justify-content: center;">
    <h1 id="logo-text" 
        style="
            font-size: 34px; 
            font-weight: 900; 
            color: #0056b3; 
            margin: 0; 
            padding: 0; 
            font-family: 'Arial', sans-serif; 
            position: relative; 
            display: inline-block; 
            transition: color 0.3s ease, transform 0.3s ease;
        ">
        Gas<span style="color: #ff5722;">by</span>Gas
        <span 
            style="
                position: absolute; 
                bottom: -8px; 
                left: 0; 
                width: 100%; 
                height: 4px; 
                background: linear-gradient(90deg, #0056b3, #ff5722); 
                border-radius: 2px; 
                transition: transform 0.3s ease;
                transform: scaleX(0); 
                transform-origin: left;
            " 
            id="logo-underline"></span>
    </h1>
</a>

<script>
    // Add hover effect to make the logo interactive
    const logoText = document.getElementById("logo-text");
    const logoUnderline = document.getElementById("logo-underline");

    logoText.addEventListener("mouseover", function() {
        this.style.color = "#ff5722";
        this.style.transform = "scale(1.1)";
        logoUnderline.style.transform = "scaleX(1)";
    });

    logoText.addEventListener("mouseout", function() {
        this.style.color = "#0056b3";
        this.style.transform = "scale(1)";
        logoUnderline.style.transform = "scaleX(0)";
    });
</script>

      <h3  class="text-overflow m-0"  style="font-size: 1.2rem;   font-weight: bold;  color: #4a4a4a;  margin-top: 10px;  margin-bottom: 10px;   text-align: center;  text-transform: uppercase;  letter-spacing: 1px; line-height: 1.5;">
          Super Admin
      </h3>

      <!-- User -->
      <ul class="nav align-items-center d-md-none">
        <li class="nav-item dropdown">
          <a class="nav-link nav-link-icon" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="ni ni-bell-55"></i>
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <div class="media align-items-center">
              <span class="avatar avatar-sm rounded-circle">
                <img alt="Image placeholder" src="assets/img/theme/team-1-800x800.jpg">
              </span>
            </div>
          </a>
          <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
            <a href="change_profile.php" class="dropdown-item">
              <i class="ni ni-single-02"></i>
              <span>My profile</span>
            </a>
            <a href="logout.php" class="dropdown-item">
              <i class="ni ni-user-run"></i>
              <span>Logout</span>
            </a>
          </div>
        </li>
      </ul>
      <!-- Collapse -->
      <div class="collapse navbar-collapse" id="sidenav-collapse-main">
        <!-- Navigation -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>" href="dashboard.php"   style="<?php echo ($current_page == 'dashboard.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="ni ni-tv-2 "  style="<?php echo ($current_page == 'dashboard.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Dashboard
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'admin.php') ? 'active' : ''; ?>" href="admin.php" style="<?php echo ($current_page == 'admin.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="fas fa-chess-king "  style="<?php echo ($current_page == 'admin.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Admin
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'products.php') ? 'active' : ''; ?>" href="products.php" style="<?php echo ($current_page == 'products.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="ni ni-box-2 "  style="<?php echo ($current_page == 'products.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Inventory
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'outlet_inventory.php') ? 'active' : ''; ?>" href="outlet_inventory.php" style="<?php echo ($current_page == 'outlet_inventory.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="ni ni-box-2 "  style="<?php echo ($current_page == 'outlet_inventory.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Outlet Inventory
            </a>
          </li>

          <li class="nav-item">
              <a 
                class="nav-link <?php echo ($current_page == 'outletmanagement.php') ? 'active' : ''; ?>" 
                href="outletmanagement.php" 
                style="<?php echo ($current_page == 'outletmanagement.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
                <i 
                  class="fas fa-store" 
                  style="<?php echo ($current_page == 'outletmanagement.php') ? 'color: white;' : 'color: #007bff;'; ?>">
                </i> Outlet Management
              </a>
            </li>



          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'customes.php') ? 'active' : ''; ?>" href="customes.php" style="<?php echo ($current_page == 'customes.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="fas fa-users "  style="<?php echo ($current_page == 'customes.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Customers
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'hrm.php') ? 'active' : ''; ?>" href="hrm.php" style="<?php echo ($current_page == 'hrm.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class=" fas fa-sitemap"  style="<?php echo ($current_page == 'hrm.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Outlet Manager
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'refill_reques_admin.php') ? 'active' : ''; ?>" href="refill_reques_admin.php" style="<?php echo ($current_page == 'refill_reques_admin.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="ni ni-basket "  style="<?php echo ($current_page == 'refill_reques_admin.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Refill Request
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'deliveryshedule.php') ? 'active' : ''; ?>" href="deliveryshedule.php" style="<?php echo ($current_page == 'deliveryshedule.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="fas fa-truck "  style="<?php echo ($current_page == 'deliveryshedule.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Delivery Scheduling
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'complaint_managment.php') ? 'active' : ''; ?>" href="complaint_managment.php" style="<?php echo ($current_page == 'complaint_managment.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="fas fa-exclamation-circle "  style="<?php echo ($current_page == 'complaint_managment.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Customer Complaints
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'orders.php') ? 'active' : ''; ?>" href="orders.php" style="<?php echo ($current_page == 'orders.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="ni ni-cart "  style="<?php echo ($current_page == 'orders.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Orders
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'payments.php') ? 'active' : ''; ?>" href="payments.php" style="<?php echo ($current_page == 'payments.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="ni ni-credit-card "  style="<?php echo ($current_page == 'payments.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Payments
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'receipts.php') ? 'active' : ''; ?>" href="receipts.php" style="<?php echo ($current_page == 'receipts.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
              <i class="fas fa-file-invoice-dollar "  style="<?php echo ($current_page == 'receipts.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Receipts
            </a>
          </li>
        </ul>
        <hr class="my-3">
        <!-- Reporting -->
        <h6 class="navbar-heading text-muted">Reporting</h6>
        <ul class="navbar-nav mb-md-3">
        <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'revenue_report.php') ? 'active' : ''; ?>" href="revenue_report.php" 
              style="<?php echo ($current_page == 'revenue_report.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
                <i class="fas fa-dollar-sign" style="<?php echo ($current_page == 'revenue_report.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Revenue Report
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'sales_report.php') ? 'active' : ''; ?>" href="sales_report.php" 
              style="<?php echo ($current_page == 'sales_report.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
                <i class="fas fa-chart-line" style="<?php echo ($current_page == 'sales_report.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Sales Report
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'customer_report.php') ? 'active' : ''; ?>" href="customer_report.php" 
              style="<?php echo ($current_page == 'customer_report.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
                <i class="fas fa-users" style="<?php echo ($current_page == 'customer_report.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Customer Report
            </a>
        </li>

        <!-- <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'customer_payment.php') ? 'active' : ''; ?>" href="customer_payment.php" 
              style="<?php echo ($current_page == 'customer_payment.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
                <i class="fas fa-credit-card" style="<?php echo ($current_page == 'customer_payment.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Customer Payment
            </a>
        </li> -->

        <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'refill_request_report.php') ? 'active' : ''; ?>" href="refill_request_report.php" 
              style="<?php echo ($current_page == 'refill_request_report.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
                <i class="fas fa-sync-alt" style="<?php echo ($current_page == 'refill_request_report.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Refill Request Report
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'outlets_report.php') ? 'active' : ''; ?>" href="outlets_report.php" 
              style="<?php echo ($current_page == 'outlets_report.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
                <i class="fas fa-store" style="<?php echo ($current_page == 'outlets_report.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Outlets Report
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php echo ($current_page == 'quantity_report.php') ? 'active' : ''; ?>" href="quantity_report.php" 
              style="<?php echo ($current_page == 'quantity_report.php') ? 'background-color: #007bff; color: white;' : ''; ?>">
                <i class="fas fa-boxes" style="<?php echo ($current_page == 'quantity_report.php') ? 'color: white;' : 'color: #007bff;'; ?>"></i> Quantity Report
            </a>
        </li>



        </ul>
        <hr class="my-3">
        <ul class="navbar-nav mb-md-3">
          <li class="nav-item">
            <a class="nav-link" href="logout.php">
              <i class="fas fa-sign-out-alt text-danger"></i> Log Out
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  
<?php } ?>
