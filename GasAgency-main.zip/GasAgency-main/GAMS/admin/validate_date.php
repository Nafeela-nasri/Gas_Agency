<?php
include('config/config.php');

$data = json_decode(file_get_contents('php://input'), true);

$district = $data['district'] ?? '';
$outletName = $data['outletName'] ?? '';
$date = $data['date'] ?? '';

$response = ['valid' => true, 'message' => ''];

if ($district && $outletName && $date) {
    $month = date('Y-m', strtotime($date));
    $query = "SELECT first_delivery_date, second_delivery_date, third_delivery_date 
              FROM delivery_schedule 
              WHERE district = ? AND outlet_name = ? AND DATE_FORMAT(first_delivery_date, '%Y-%m') = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param('sss', $district, $outletName, $month);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        if (in_array($date, $row)) {
            $response['valid'] = false;
            $response['message'] = 'This date is already assigned.';
            break;
        }
    }

    $query = "SELECT COUNT(*) AS count 
              FROM delivery_schedule 
              WHERE district = ? AND outlet_name = ? AND DATE_FORMAT(first_delivery_date, '%Y-%m') = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param('sss', $district, $outletName, $month);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row['count'] >= 3) {
        $response['valid'] = false;
        $response['message'] = 'All three delivery dates are already assigned for this outlet in this month.';
    }
} else {
    $response['valid'] = false;
    $response['message'] = 'Invalid input data.';
}

echo json_encode($response);
