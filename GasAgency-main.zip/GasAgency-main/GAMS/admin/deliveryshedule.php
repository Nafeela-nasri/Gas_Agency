<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();

// Delete Delivery Schedule
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $adn = "DELETE FROM delivery_schedule WHERE id = ?";
    $stmt = $mysqli->prepare($adn);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();
    if ($stmt) {
        $success = "Deleted";
        header("refresh:1; url=delivery_schedules.php");
    } else {
        $err = "Try Again Later";
    }
}

require_once('partials/_head.php');
?>

<body>
  <!-- Sidenav -->
  <?php require_once('partials/_sidebar.php'); ?>
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <?php require_once('partials/_topnav.php'); ?>
    <!-- Header -->
    <div style="background-image: url(assets/img/theme/delivery.jpg); background-size: cover;" class="header pb-8 pt-5 pt-md-8">
      <span class="mask bg-gradient-dark opacity-8"></span>
      <div class="container-fluid">
        <div class="header-body">
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--8">
      <!-- Table -->
      <div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0">
              <a href="add_delivery_shedule.php" class="btn btn-outline-success">
                <i class="fas fa-calendar-plus"></i>
                Add New Delivery Schedule
              </a>
            </div>
            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">District</th>
                    <th scope="col">Outlet Name</th>
                    <th scope="col">First Delivery Date</th>
                    <th scope="col">Second Delivery Date</th>
                    <th scope="col">Third Delivery Date</th>
                    <th scope="col">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $query = "
                    SELECT id, district, outlet_name, first_delivery_date, second_delivery_date, third_delivery_date, created_at
                    FROM delivery_schedule
                    ORDER BY created_at DESC
                  ";
                  $stmt = $mysqli->prepare($query);
                  $stmt->execute();
                  $result = $stmt->get_result();
                  while ($schedule = $result->fetch_object()) {
                  ?>
                    <tr>
                      <td><?php echo htmlspecialchars($schedule->district); ?></td>
                      <td><?php echo htmlspecialchars($schedule->outlet_name); ?></td>
                      <td><?php echo htmlspecialchars($schedule->first_delivery_date); ?></td>
                      <td><?php echo htmlspecialchars($schedule->second_delivery_date); ?></td>
                      <td><?php echo htmlspecialchars($schedule->third_delivery_date); ?></td>
                      <td>
                        <a href="delivery_schedules.php?delete=<?php echo $schedule->id; ?>" onclick="return confirm('Are you sure you want to delete this schedule?');">
                          <button class="btn btn-sm btn-danger">
                            <i class="fas fa-trash"></i>
                            Delete
                          </button>
                        </a>
                        <a href="update_delivery_schedule.php?update=<?php echo $schedule->id; ?>">
                          <button class="btn btn-sm btn-primary">
                            <i class="fas fa-edit"></i>
                            Update
                          </button>
                        </a>
                      </td>
                    </tr>
                  <?php
                  }
                  $stmt->close();
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
      <?php require_once('partials/_footer.php'); ?>
    </div>
  </div>
  <!-- Argon Scripts -->
  <?php require_once('partials/_scripts.php'); ?>
</body>

</html>
