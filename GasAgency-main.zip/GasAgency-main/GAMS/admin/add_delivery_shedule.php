<?php
session_start();
include('config/config.php');

// Handle form submission
if (isset($_POST['addSchedule'])) {
    $district = $_POST['district'] ?? '';
    $outlet_name = $_POST['outlet_name'] ?? '';
    $first_delivery_date = $_POST['first_delivery_date'] ?? '';
    $second_delivery_date = $_POST['second_delivery_date'] ?? '';
    $third_delivery_date = $_POST['third_delivery_date'] ?? '';

    // Validate inputs
    if (empty($district) || empty($outlet_name) || empty($first_delivery_date) || empty($second_delivery_date) || empty($third_delivery_date)) {
        $err = "All fields are required.";
    } elseif (date('Y-m', strtotime($first_delivery_date)) !== date('Y-m', strtotime($second_delivery_date)) ||
              date('Y-m', strtotime($second_delivery_date)) !== date('Y-m', strtotime($third_delivery_date))) {
        $err = "All delivery dates must be in the same month.";
    } else {
        // Check for existing records in the same month
        $month = date('Y-m', strtotime($first_delivery_date));
        $query = "SELECT first_delivery_date, second_delivery_date, third_delivery_date 
                  FROM delivery_schedule
                  WHERE district = ? AND outlet_name = ? AND DATE_FORMAT(first_delivery_date, '%Y-%m') = ?";
        $stmt = $mysqli->prepare($query);
        if ($stmt) {
            $stmt->bind_param('sss', $district, $outlet_name, $month);
            $stmt->execute();
            $result = $stmt->get_result();
            $existing_dates = [];

            while ($row = $result->fetch_assoc()) {
                $existing_dates[] = $row['first_delivery_date'];
                $existing_dates[] = $row['second_delivery_date'];
                $existing_dates[] = $row['third_delivery_date'];
            }

            // Remove duplicates and count existing dates
            $existing_dates = array_filter(array_unique($existing_dates));
            $existing_date_count = count($existing_dates);

            // Check if the total number of delivery dates exceeds 3
            if ($existing_date_count >= 3) {
                $err = "For this district and outlet, 3 delivery dates are already assigned in the selected month.";
            } elseif (in_array($first_delivery_date, $existing_dates) || in_array($second_delivery_date, $existing_dates) || in_array($third_delivery_date, $existing_dates)) {
                $err = "One or more selected dates are already assigned as delivery dates for this district and outlet in the selected month.";
            } else {
                // Insert into database
                $query = "INSERT INTO delivery_schedule (district, outlet_name, first_delivery_date, second_delivery_date, third_delivery_date) 
                          VALUES (?, ?, ?, ?, ?)";
                $stmt = $mysqli->prepare($query);
                if ($stmt) {
                    $stmt->bind_param('sssss', $district, $outlet_name, $first_delivery_date, $second_delivery_date, $third_delivery_date);
                    $stmt->execute();
                    if ($stmt->affected_rows > 0) {
                        $success = "Delivery schedule added successfully.";
                    } else {
                        $err = "Error: Please try again.";
                    }
                } else {
                    $err = "Error preparing the insert statement.";
                }
            }
        } else {
            $err = "Error preparing the validation query.";
        }
    }
}

// Fetch districts and outlets
$districts = [
    "Colombo", "Gampaha", "Kandy", "Galle", "Jaffna", "Matara",
    "Kurunegala", "Anuradhapura", "Ratnapura", "Trincomalee",
    "Hambantota", "Badulla", "Batticaloa", "Polonnaruwa", "Monaragala"
];
$outlets = [];
if (!empty($_POST['district'])) {
    $selected_district = $_POST['district'];
    $query = "SELECT outlet_name FROM outlets WHERE district = ?";
    $stmt = $mysqli->prepare($query);
    if ($stmt) {
        $stmt->bind_param('s', $selected_district);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $outlets[] = $row['outlet_name'];
        }
    }
}

require_once('partials/_head.php');
?>
<body>
  <!-- Sidenav -->
  <?php require_once('partials/_sidebar.php'); ?>
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <?php require_once('partials/_topnav.php'); ?>
    <!-- Header -->
    <div style="background-image: url(assets/img/theme/delivery.jpg); background-size: cover;" class="header pb-8 pt-5 pt-md-8">
      <span class="mask bg-gradient-dark opacity-8"></span>
      <div class="container-fluid">
        <div class="header-body">
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--8">
      <!-- Table -->
      <div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0">
              <h3>Please Fill All Fields</h3>
            </div>
            <div id="validationMessage" class="alert alert-danger d-none" role="alert"></div>
            <div class="card-body">
              <?php if (isset($success)) { ?>
                <div class="alert alert-success">
                  <?php echo $success; ?>
                </div>
              <?php } ?>
              <?php if (isset($err)) { ?>
                <div class="alert alert-danger">
                  <?php echo $err; ?>
                </div>
              <?php } ?>
              <form method="POST" id="scheduleForm">
                  <!-- District Dropdown -->
                  <div class="mb-3">
                      <label for="district" class="form-label">Select District</label>
                      <select id="district" name="district" class="form-control" onchange="this.form.submit()" required>
                          <option value="" disabled selected>Select District</option>
                          <?php foreach ($districts as $district) { ?>
                              <option value="<?php echo $district; ?>" <?php echo (isset($_POST['district']) && $_POST['district'] == $district) ? 'selected' : ''; ?>>
                                  <?php echo $district; ?>
                              </option>
                          <?php } ?>
                      </select>
                  </div>

                  <!-- Outlet Dropdown -->
                  <?php if (!empty($outlets)) { ?>
                      <div class="mb-3">
                          <label for="outlet_name" class="form-label">Select Outlet</label>
                          <select id="outlet_name" name="outlet_name" class="form-control" required>
                              <option value="" disabled selected>Select Outlet</option>
                              <?php foreach ($outlets as $outlet) { ?>
                                  <option value="<?php echo $outlet; ?>"><?php echo $outlet; ?></option>
                              <?php } ?>
                          </select>
                      </div>
                  <?php } ?>

                  <!-- Delivery Dates -->
                  <div class="mb-3">
                      <label for="first_delivery_date" class="form-label">First Delivery Date</label>
                      <input type="date" id="first_delivery_date" name="first_delivery_date" class="form-control" onchange="checkDate(this.value, 'first')" required>
                  </div>
                  <div class="mb-3">
                      <label for="second_delivery_date" class="form-label">Second Delivery Date</label>
                      <input type="date" id="second_delivery_date" name="second_delivery_date" class="form-control" onchange="checkDate(this.value, 'second')" required>
                  </div>
                  <div class="mb-3">
                      <label for="third_delivery_date" class="form-label">Third Delivery Date</label>
                      <input type="date" id="third_delivery_date" name="third_delivery_date" class="form-control" onchange="checkDate(this.value, 'third')" required>
                  </div>

                  <button type="submit" name="addSchedule" class="btn btn-primary">Add Schedule</button>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
      <?php require_once('partials/_footer.php'); ?>
    </div>
  </div>
  <!-- Argon Scripts -->
  <?php require_once('partials/_scripts.php'); ?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
 <!-- Add this section in your HTML where you want to display the validation messages -->


<script>
    function showValidationMessage(message, isError = true) {
        const validationMessage = document.getElementById('validationMessage');
        validationMessage.textContent = message;
        validationMessage.className = isError 
            ? 'alert alert-danger' 
            : 'alert alert-success';
        validationMessage.classList.remove('d-none');
    }

    function hideValidationMessage() {
        const validationMessage = document.getElementById('validationMessage');
        validationMessage.textContent = '';
        validationMessage.classList.add('d-none');
    }

    function checkDate(selectedDate, fieldName) {
        const district = document.getElementById('district').value;
        const outletName = document.getElementById('outlet_name').value;

        hideValidationMessage(); // Clear any previous messages

        if (district && outletName) {
            fetch('validate_date.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    district: district,
                    outletName: outletName,
                    date: selectedDate
                })
            })
            .then(response => response.json())
            .then(data => {
                if (!data.valid) {
                    showValidationMessage(data.message); // Show validation message
                    document.getElementById(fieldName + '_delivery_date').value = '';
                } else {
                    showValidationMessage('Date is valid.', false); // Show success message
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showValidationMessage('An error occurred while validating the date.');
            });
        } else {
            showValidationMessage('Please select both district and outlet before choosing a date.');
        }
    }
</script>

  </body>
</html>
