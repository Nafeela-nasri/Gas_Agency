<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();

if (isset($_POST['requestId']) && isset($_POST['status'])) {
    $requestId = intval($_POST['requestId']); // Ensure the parameter is an integer
    $status = $_POST['status'];

    // Validate the status value
    $validStatuses = ['Pending', 'Approved', 'Rejected', 'Hold', 'Progress'];
    if (!in_array($status, $validStatuses)) {
        die("Invalid status provided.");
    }

    // Update Query to change the status of the refill request
    $updateQuery = "UPDATE refill_requests SET status = ? WHERE id = ?";
    $stmt = $mysqli->prepare($updateQuery);

    if (!$stmt) {
        die("Error preparing statement: " . $mysqli->error);
    }

    $stmt->bind_param('si', $status, $requestId);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "Status updated successfully!";
    } else {
        echo "Failed to update status. Please try again.";
    }
} else {
    die("Request ID or Status not provided.");
}
?>
