
<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();

header('Content-Type: application/json');

$response = [];


// Fetch total outlets
$outlets_query = "SELECT COUNT(*) as total FROM outlets";
$outlets_result = $mysqli->query($outlets_query);
$outlets_data = $outlets_result->fetch_assoc();
$response['total_outlets'] = $outlets_data['total'];

// Fetch total refill requests
$refill_query = "SELECT COUNT(*) as total FROM refill_requests";
$refill_result = $mysqli->query($refill_query);
$refill_data = $refill_result->fetch_assoc();
$response['total_refill_requests'] = $refill_data['total'];

// Fetch total inventory
$inventory_query = "SELECT COUNT(*) as total FROM rpos_products";
$inventory_result = $mysqli->query($inventory_query);
$inventory_data = $inventory_result->fetch_assoc();
$response['total_inventory'] = $inventory_data['total'];

// Fetch total income
$income_query = "SELECT SUM(pay_amt) as total FROM rpos_payments";
$income_result = $mysqli->query($income_query);
$income_data = $income_result->fetch_assoc();
$response['total_income'] = $income_data['total'] ?: 0;

// Fetch total orders
$orders_query = "SELECT COUNT(*) as total FROM rpos_orders";
$orders_result = $mysqli->query($orders_query);
$orders_data = $orders_result->fetch_assoc();
$response['total_orders'] = $orders_data['total'];

// Return JSON response
echo json_encode($response);
$mysqli->close();
?>
