<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();
require_once('partials/_head.php');

// Fetch customer refill requests
$table1_query = "SELECT request_id, category, description, refill_qty, outlet_district, outlet_name, expected_delivery_date, status FROM refill_requests_customer ORDER BY expected_delivery_date ASC";
$table1_result = mysqli_query($mysqli, $table1_query);
$customer_refills = [];
while ($row = mysqli_fetch_assoc($table1_result)) {
    $customer_refills[] = $row;
}

// Fetch outlet refill requests
$table2_query = "SELECT id, manager_id, description, category, refill_qty, outlet_district, outlet_name, expected_delivery_date, status, scheduled_date FROM refill_requests ORDER BY expected_delivery_date ASC";
$table2_result = mysqli_query($mysqli, $table2_query);
$outlet_refills = [];
while ($row = mysqli_fetch_assoc($table2_result)) {
    $outlet_refills[] = $row;
}
?>

<body>
    <!-- Sidebar -->
    <?php require_once('partials/_sidebar.php'); ?>

    <div class="main-content">
        <!-- Top navbar -->
        <?php require_once('partials/_topnav.php'); ?>

        <!-- Header -->
        <div class="bg-gradient-primary pt-5 pb-8">
            <div class="container-fluid">
                <div class="header-body text-center">
                    <h2 class="text-white display-3">Refill Request Report</h2>
                    <p class="text-white mb-0">Overview of customer and outlet refill requests</p>
                </div>
            </div>
        </div>

        <!-- Page content -->
        <div class="container-fluid mt--8">
            <div class="row">
                <div class="col-xl-8 col-lg-12 col-md-12">
                    <div class="card shadow border-0">
                        <div class="card-body">
                            <h5 class="card-title">Customer Refill Requests</h5>
                            <div class="table-responsive p-3">
                                <table class="table table-striped table-bordered" id="customer_table">
                                    <thead class="thead-light">
                                        <tr>
                                            <th>Category</th>
                                            <th>Description</th>
                                            <th>Refill Qty</th>
                                            <th>District</th>
                                            <th>Outlet</th>
                                            <th>Delivery Date</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($customer_refills as $row) { ?>
                                            <tr>
                                                <td><?php echo $row['category']; ?></td>
                                                <td><?php echo $row['description']; ?></td>
                                                <td><?php echo $row['refill_qty']; ?></td>
                                                <td><?php echo $row['outlet_district']; ?></td>
                                                <td><?php echo $row['outlet_name']; ?></td>
                                                <td><?php echo date('d-m-Y', strtotime($row['expected_delivery_date'])); ?></td>
                                                <td><?php echo $row['status']; ?></td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-12 col-md-12">
                    <div class="card shadow border-0">
                        <div class="card-body">
                            <h5 class="card-title">Actions</h5>
                            <div class="btn-group-vertical w-100">
                                <button class="btn btn-outline-primary btn-lg mb-3" onclick="downloadPDF()">
                                    <i class="fas fa-file-pdf"></i> Download PDF
                                </button>
                                <button class="btn btn-outline-success btn-lg mb-3" onclick="downloadExcel()">
                                    <i class="fas fa-file-excel"></i> Download Excel
                                </button>
                                <button class="btn btn-outline-info btn-lg" onclick="downloadCSV()">
                                    <i class="fas fa-file-csv"></i> Download CSV
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col">
                    <div class="card shadow border-0">
                        <div class="card-header bg-transparent">
                            <h5 class="mb-0">Outlet Refill Requests</h5>
                        </div>
                        <div class="table-responsive p-3">
                            <table class="table table-striped table-bordered" id="outlet_table">
                                <thead class="thead-light">
                                    <tr>
                                        <th>Category</th>
                                        <th>Description</th>
                                        <th>Refill Qty</th>
                                        <th>District</th>
                                        <th>Outlet</th>
                                        <th>Expected Delivery</th>
                                        <th>Scheduled Date</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($outlet_refills as $row) { ?>
                                        <tr>
                                            <td><?php echo $row['category']; ?></td>
                                            <td><?php echo $row['description']; ?></td>
                                            <td><?php echo $row['refill_qty']; ?></td>
                                            <td><?php echo $row['outlet_district']; ?></td>
                                            <td><?php echo $row['outlet_name']; ?></td>
                                            <td><?php echo date('d-m-Y', strtotime($row['expected_delivery_date'])); ?></td>
                                            <td><?php echo date('d-m-Y', strtotime($row['scheduled_date'])); ?></td>
                                            <td><?php echo $row['status']; ?></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Footer -->
        <?php require_once('partials/_footer.php'); ?>
    </div>

    <!-- Include jsPDF & jsPDF AutoTable -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.23/jspdf.plugin.autotable.min.js"></script>

    <script>
        function downloadPDF() {
            const { jsPDF } = window.jspdf;
            let doc = new jsPDF();
            doc.text("Refill Request Report", 20, 10);
            
            doc.autoTable({ html: '#customer_table', startY: 20 });
            doc.autoTable({ html: '#outlet_table', startY: doc.autoTable.previous.finalY + 10 });
            doc.save("Refill_Request_Report.pdf");
        }

        function downloadCSV() {
            let table = document.getElementById("customer_table");
            let rows = Array.from(table.rows);
            let csvContent = rows.map(row => Array.from(row.cells).map(cell => cell.textContent).join(",")).join("\n");
            let blob = new Blob([csvContent], { type: "text/csv" });
            let link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = "Refill_Request_Report.csv";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        function downloadExcel() {
            let table = document.getElementById("customer_table");
            let rows = Array.from(table.rows);
            let xlsContent = rows.map(row => `<tr>${Array.from(row.cells).map(cell => `<td>${cell.textContent}</td>`).join("")}</tr>`).join("");
            let excelFile = `<table>${xlsContent}</table>`;
            let blob = new Blob([excelFile], { type: "application/vnd.ms-excel" });
            let link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = "Refill_Request_Report.xls";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    </script>

    <!-- Argon Scripts -->
    <?php require_once('partials/_scripts.php'); ?>
</body>
</html>
