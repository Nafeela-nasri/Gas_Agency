<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();

header('Content-Type: application/json');

$response = [];



// Fetch monthly income data
$income_query = "SELECT MONTH(created_at) as month, SUM(pay_amt) as total FROM rpos_payments GROUP BY MONTH(created_at)";
$income_result = $mysqli->query($income_query);
$income_data = [];
while ($row = $income_result->fetch_assoc()) {
    $income_data[] = $row;
}
$response['monthly_income'] = $income_data;

// Fetch monthly orders data
$orders_query = "SELECT MONTH(created_at) as month, COUNT(*) as total FROM rpos_orders GROUP BY MONTH(created_at)";
$orders_result = $mysqli->query($orders_query);
$orders_data = [];
while ($row = $orders_result->fetch_assoc()) {
    $orders_data[] = $row;
}
$response['monthly_orders'] = $orders_data;

// Return JSON response
echo json_encode($response);
$mysqli->close();
?>
