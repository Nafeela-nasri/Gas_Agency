<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();
require_once('partials/_head.php');

// Retrieve data from database
$sql = "SELECT * FROM rpos_orders";
$result = mysqli_query($mysqli, $sql);

$productname = [];
$sales = [];
while ($row = mysqli_fetch_assoc($result)) {
    $productname[]  = $row['prod_name'];
    $sales[] = $row['prod_qty'];
}

?>

<body>
    <!-- Sidebar -->
    <?php require_once('partials/_sidebar.php'); ?>

    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php require_once('partials/_topnav.php'); ?>

        <!-- Header with Background Image -->
        <div class="bg-gradient-primary pt-5 pb-8">
            <div class="container-fluid">
                <div class="header-body text-center">
                    <h2 class="text-white display-3">Sales Report</h2>
                    <p class="text-white mb-0">Overview of Sales </p>
                </div>
            </div>
        </div>


        <!-- Page content -->
        <div class="container-fluid mt--8">
            <div class="row">
                <!-- Actions Section (Download buttons) -->
                <div class="col-xl-4 col-lg-12 col-md-12">
                    <div class="card shadow border-0">
                        <div class="card-header bg-transparent">
                            <h5 class="mb-0">Actions</h5>
                        </div>
                        <div class="card-body">
                            <div class="btn-group-vertical w-100">
                                <button class="btn btn-outline-danger btn-lg mb-3" onclick="downloadPDF()">
                                    <i class="fas fa-file-pdf"></i> Download PDF
                                </button>
                                <button class="btn btn-outline-success btn-lg mb-3" onclick="downloadExcel()">
                                    <i class="fas fa-file-excel"></i> Download Excel
                                </button>
                                <button class="btn btn-outline-primary btn-lg" onclick="downloadCSV()">
                                    <i class="fas fa-file-csv"></i> Download CSV
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sales Report Section (Chart) -->
                <div class="col-xl-8 col-lg-12 col-md-12">
                    <div class="card shadow border-0">
                        <div class="card-header bg-transparent">
                            <h5 class="mb-0">Sales Report Overview</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="chartjs_bar" style="height: 400px; width: 100%;"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <?php require_once('partials/_footer.php'); ?>
        </div>
    </div>

    <!-- Argon Scripts -->
    <?php require_once('partials/_scripts.php'); ?>

    <!-- Include Chart.js and jsPDF -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.23/jspdf.plugin.autotable.min.js"></script>

    <script>
        window.onload = function() {
            var ctx = document.getElementById("chartjs_bar").getContext('2d');
            var myChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($productname); ?>,
                    datasets: [{
                        backgroundColor: [
                            "#5969ff", "#ff407b", "#25d5f2", "#ffc750", "#2ec551", "#7040fa", "#ff004e"
                        ],
                        data: <?php echo json_encode($sales); ?>,
                    }]
                },
                options: {
                    legend: {
                        display: true,
                        position: 'bottom',
                        labels: {
                            fontColor: '#71748d',
                            fontFamily: 'Circular Std Book',
                            fontSize: 14,
                        }
                    },
                }
            });
        }

        function downloadPDF() {
            const { jsPDF } = window.jspdf;
            let doc = new jsPDF('p', 'mm', 'a4');
            doc.text("Sales Report", 14, 10);

            // Table Data (Dummy table for this example)
            let rows = [];
            document.querySelectorAll("#chartjs_bar").forEach((chart) => {
                rows.push([chart.innerText]);
            });

            doc.autoTable({
                head: [['Product Name', 'Sales Quantity']],
                body: rows,
                startY: 20
            });

            // Chart to Image
            let canvas = document.getElementById("chartjs_bar");
            let imgData = canvas.toDataURL("image/png");
            doc.addImage(imgData, 'PNG', 14, doc.autoTable.previous.finalY + 10, 180, 80);

            doc.save("Sales_Report.pdf");
        }

        function downloadExcel() {
            let table = document.getElementById("chartjs_bar");
            let csv = [];
            for (let row of table.rows) {
                let cols = [];
                for (let cell of row.cells) {
                    cols.push(cell.innerText);
                }
                csv.push(cols.join(","));
            }
            let csvContent = "data:text/csv;charset=utf-8," + csv.join("\n");
            let encodedUri = encodeURI(csvContent);
            let link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", "Sales_Report.csv");
            document.body.appendChild(link);
            link.click();
        }

        function downloadCSV() {
            let table = document.getElementById("chartjs_bar");
            let rows = Array.from(table.rows);
            let csvContent = rows.map(row => Array.from(row.cells).map(cell => cell.textContent).join(",")).join("\n");
            let blob = new Blob([csvContent], { type: "text/csv" });
            let link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = "Sales_Report.csv";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    </script>
</body>
</html>
