<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();
require_once('partials/_head.php');

// Retrieve customer data
$sql = "SELECT customer_name, customer_phoneno, customer_email, customer_nic, customer_dob, customer_address, customer_typ FROM rpos_customers ORDER BY customer_name ASC";
$result = mysqli_query($mysqli, $sql);

$customers = [];
$customerTypes = [];
while ($row = mysqli_fetch_assoc($result)) {
    $customers[] = $row;
    $customerTypes[$row['customer_typ']] = isset($customerTypes[$row['customer_typ']]) ? $customerTypes[$row['customer_typ']] + 1 : 1;
}
?>

<body>
    <!-- Sidebar -->
    <?php require_once('partials/_sidebar.php'); ?>

    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php require_once('partials/_topnav.php'); ?>

        <!-- Header with background image -->
        <div class="bg-gradient-primary pt-5 pb-8" style="background-image: url(assets/img/theme/customer-bg.jpg); background-size: cover;">
            <div class="container-fluid">
                <div class="header-body text-center">
                    <h2 class="text-white display-3">Customer Report</h2>
                    <p class="text-white mb-0">Overview of customer details</p>
                </div>
            </div>
        </div>

        <!-- Page content -->
        <div class="container-fluid mt--8">
            <div class="row">
                <!-- Customer Table Section -->
                <div class="col-xl-8 col-lg-12 col-md-12">
                    <div class="card shadow border-0">
                        <div class="card-body">
                            <h5 class="card-title">Customer List</h5>
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="customer_table">
                                    <thead class="thead-light">
                                        <tr>
                                            <th>Name</th>
                                            <th>Phone</th>
                                            <th>Email</th>
                                            <th>NIC</th>
                                            <th>DOB</th>
                                            <th>Address</th>
                                            <th>Type</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($customers as $customer) { ?>
                                            <tr>
                                                <td><?php echo $customer['customer_name']; ?></td>
                                                <td><?php echo $customer['customer_phoneno']; ?></td>
                                                <td><?php echo $customer['customer_email']; ?></td>
                                                <td><?php echo $customer['customer_nic']; ?></td>
                                                <td><?php echo date('d-m-Y', strtotime($customer['customer_dob'])); ?></td>
                                                <td><?php echo $customer['customer_address']; ?></td>
                                                <td><?php echo $customer['customer_typ']; ?></td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Chart Section -->
                        <div class="card-body">
                            <h4 class="card-title">Customer Distribution</h4>
                            <canvas id="customer_chart" style="height: 400px; width: 100%;"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Report and Actions Section -->
                <div class="col-xl-4 col-lg-12 col-md-12">
                    <div class="card shadow border-0">
                        <div class="card-header bg-transparent">
                            <h5 class="mb-0">Actions</h5>
                        </div>
                        <div class="card-body">
                            <div class="btn-group-vertical w-100">
                                <button class="btn btn-outline-danger btn-lg mb-3" onclick="downloadPDF()">
                                    <i class="fas fa-file-pdf"></i> Download PDF
                                </button>
                                <button class="btn btn-outline-success btn-lg mb-3" onclick="downloadExcel()">
                                    <i class="fas fa-file-excel"></i> Download Excel
                                </button>
                                <button class="btn btn-outline-primary btn-lg" onclick="downloadCSV()">
                                    <i class="fas fa-file-csv"></i> Download CSV
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <!-- Footer -->
            <?php require_once('partials/_footer.php'); ?>
        </div>
    </div>

    <!-- Include Bootstrap, Chart.js, and jsPDF -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.23/jspdf.plugin.autotable.min.js"></script>

    <script>
        window.onload = function() {
            var ctx = document.getElementById("customer_chart").getContext('2d');
            var myChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: <?php echo json_encode(array_keys($customerTypes)); ?>,
                    datasets: [{
                        label: 'Customer Types',
                        backgroundColor: ["#4e73df", "#1cc88a", "#36b9cc", "#f6c23e", "#e74a3b"],
                        data: <?php echo json_encode(array_values($customerTypes)); ?>,
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { display: true, position: 'top' }
                    }
                }
            });
        }

        function downloadPDF() {
            const { jsPDF } = window.jspdf;
            let doc = new jsPDF('p', 'mm', 'a4');
            doc.text("Customer Report", 14, 10);
            
            // Table Data
            let rows = [];
            document.querySelectorAll("#customer_table tbody tr").forEach(row => {
                let rowData = [];
                row.querySelectorAll("td").forEach(cell => rowData.push(cell.innerText));
                rows.push(rowData);
            });

            doc.autoTable({
                head: [['Name', 'Phone', 'Email', 'NIC', 'DOB', 'Address', 'Type']],
                body: rows,
                startY: 20
            });

            // Chart to Image
            let canvas = document.getElementById("customer_chart");
            let imgData = canvas.toDataURL("image/png");
            doc.addImage(imgData, 'PNG', 14, doc.autoTable.previous.finalY + 10, 180, 80);

            doc.save("Customer_Report.pdf");
        }

        function downloadExcel() {
            let table = document.getElementById("customer_table");
            let csv = [];
            for (let row of table.rows) {
                let cols = [];
                for (let cell of row.cells) {
                    cols.push(cell.innerText);
                }
                csv.push(cols.join(","));
            }
            let csvContent = "data:text/csv;charset=utf-8," + csv.join("\n");
            let encodedUri = encodeURI(csvContent);
            let link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", "Customer_Report.csv");
            document.body.appendChild(link);
            link.click();
        }

        function downloadCSV() {
            let table = document.getElementById("customer_table");
            let rows = Array.from(table.rows);
            let csvContent = rows.map(row => Array.from(row.cells).map(cell => cell.textContent).join(",")).join("\n");
            let blob = new Blob([csvContent], { type: "text/csv" });
            let link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = "Customer_Report.csv";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    </script>

    <!-- Argon Scripts -->
    <?php require_once('partials/_scripts.php'); ?>
</body>
</html>
