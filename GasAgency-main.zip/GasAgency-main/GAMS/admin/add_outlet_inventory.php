<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
include('config/code-generator.php');

check_login();
if (isset($_POST['addProduct'])) {
  //Prevent Posting Blank Values
  if (empty($_POST["prod_code"]) || empty($_POST["prod_name"]) || empty($_POST["district"]) || empty($_POST["outlet_name"]) || empty($_POST['prod_desc']) || empty($_POST['prod_price']) || empty($_POST['prod_qty']) || empty($_POST['prod_category'])) {
    $err = "Blank Values Not Accepted";
  } else {
    $prod_id = $_POST['prod_id'];
    $prod_code  = $_POST['prod_code'];
    $prod_name = $_POST['prod_name'];
    $prod_img = $_FILES['prod_img']['name'];
    move_uploaded_file($_FILES["prod_img"]["tmp_name"], "assets/img/products/" . $_FILES["prod_img"]["name"]);
    $prod_desc = $_POST['prod_desc'];
    $prod_price = $_POST['prod_price'];
    $prod_qty = $_POST['prod_qty'];  // New field
    $prod_category = $_POST['prod_category'];  // New field
    $district = $_POST['district'];  // New field
    $outlet_name = $_POST['outlet_name'];  // New field
    $type  = "inventory1";

    //Insert Captured information to a database table
    $postQuery = "INSERT INTO rpos_products (prod_id, prod_code, prod_name, prod_img, prod_desc, prod_price, prod_qty, prod_category,district,outlet,inventorytype) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
    $postStmt = $mysqli->prepare($postQuery);
    //bind paramaters
    $rc = $postStmt->bind_param('sssssssssss', $prod_id, $prod_code, $prod_name, $prod_img, $prod_desc, $prod_price, $prod_qty, $prod_category, $district ,$outlet_name ,  $type );
    $postStmt->execute();
    //declare a varible which will be passed to alert function
    if ($postStmt) {
      $success = "Product Added" && header("refresh:1; url=add_product.php");
    } else {
      $err = "Please Try Again Or Try Later";
    }
  }
}

$districts = [
    "Colombo", "Gampaha", "Kandy", "Galle", "Jaffna", "Matara",
    "Kurunegala", "Anuradhapura", "Ratnapura", "Trincomalee",
    "Hambantota", "Badulla", "Batticaloa", "Polonnaruwa", "Monaragala"
];
$outlets = [];
if (!empty($_POST['district'])) {
    $selected_district = $_POST['district'];
    $query = "SELECT outlet_name FROM outlets WHERE district = ?";
    $stmt = $mysqli->prepare($query);
    if ($stmt) {
        $stmt->bind_param('s', $selected_district);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $outlets[] = $row['outlet_name'];
        }
    }
}



require_once('partials/_head.php');
?>

<body>
  <!-- Sidenav -->
  <?php
  require_once('partials/_sidebar.php');
  ?>
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <?php
    require_once('partials/_topnav.php');
    ?>
    <!-- Header -->
    <div style="background-image: url(assets/img/theme/restro00.jpg); background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
      <span class="mask bg-gradient-dark opacity-8"></span>
      <div class="container-fluid">
        <div class="header-body">
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--8">
      <!-- Table -->
      <div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0">
              <h3>Please Fill All Fields</h3>
            </div>
            <div class="card-body">
              <form method="POST" enctype="multipart/form-data">
                <div class="form-row">
                  <div class="col-md-6">
                    <label>Product Name</label>
                    <input type="text" name="prod_name" class="form-control">
                    <input type="hidden" name="prod_id" value="<?php echo $prod_id; ?>" class="form-control">
                  </div>
                  <div class="col-md-6">
                    <label>Product Code</label>
                    <input type="text" name="prod_code" value="<?php echo $alpha; ?>-<?php echo $beta; ?>" class="form-control" value="">
                  </div>
                </div><br>

                <div class="form-row">
                <div class="col-md-6">
                      <label for="district" class="form-label">Select District</label>
                      <select id="district" name="district" class="form-control" onchange="this.form.submit()" required>
                          <option value="" disabled selected>Select District</option>
                          <?php foreach ($districts as $district) { ?>
                              <option value="<?php echo $district; ?>" <?php echo (isset($_POST['district']) && $_POST['district'] == $district) ? 'selected' : ''; ?>>
                                  <?php echo $district; ?>
                              </option>
                          <?php } ?>
                      </select>
                  </div>

                  <!-- Outlet Dropdown -->
                  <?php if (!empty($outlets)) { ?>
                      <div class="col-md-6">
                          <label for="outlet_name" class="form-label">Select Outlet</label>
                          <select id="outlet_name" name="outlet_name" class="form-control" required>
                              <option value="" disabled selected>Select Outlet</option>
                              <?php foreach ($outlets as $outlet) { ?>
                                  <option value="<?php echo $outlet; ?>"><?php echo $outlet; ?></option>
                              <?php } ?>
                          </select>
                      </div>
                  <?php }else { ?>
                    <div class="col-md-6">
                          <label for="outlet_name" class="form-label">Select Outlet</label>
                          <select id="outlet_name" name="outlet_name" class="form-control" required>
                              <option value="" disabled selected>Select District First</option>
                          </select>
                      </div>

                    <?php } ?>
                  </div>

                <div class="form-row">
                  <div class="col-md-6">
                    <label>Product Image</label>
                    <input type="file" name="prod_img" class="btn btn-outline-success form-control" value="">
                  </div>
                  <div class="col-md-6">
                    <label>Product Price</label>
                    <input type="text" name="prod_price" class="form-control" value="">
                  </div>
                </div>
                <hr>
                <div class="form-row">
                  <div class="col-md-6">
                    <label>Quantity (Qty)</label>
                    <input type="number" name="prod_qty" class="form-control" value="" min="1">
                  </div>
                  <div class="col-md-6">
                    <label>Category</label>
                    <select name="prod_category" class="form-control">
                      <option value="LPG 5 kg">LPG 5 kg</option>
                      <option value="LPG 12.5 kg">LPG 12.5 kg</option>
                      <option value="LPG 15 kg">LPG 15 kg</option>
                      <option value="LPG 19 kg">LPG 19 kg</option>
                      <option value="LPG 35 kg">LPG 35 kg</option>
                      <option value="LPG 45 kg">LPG 45 kg</option>
                    </select>
                  </div>
                </div>
                <hr>
                <div class="form-row">
                  <div class="col-md-12">
                    <label>Product Description</label>
                    <textarea rows="5" name="prod_desc" class="form-control" value=""></textarea>
                  </div>
                </div>
                <br>
                <div class="form-row">
                  <div class="col-md-6">
                    <input type="submit" name="addProduct" value="Add Product" class="btn btn-success" value="">
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
      <?php
      require_once('partials/_footer.php');
      ?>
    </div>
  </div>
  <!-- Argon Scripts -->
  <?php
  require_once('partials/_scripts.php');
  ?>
</body>

</html>
