<?php
session_start();
include('config/config.php');

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = sha1(md5($_POST['password'])); // Double encryption for security

    // Check in Admin table
    $stmt = $mysqli->prepare("SELECT admin_mail, admin_password, aadmin_id FROM rpos_aadmin WHERE admin_mail = ? AND admin_password = ?");
    $stmt->bind_param('ss', $email, $password);
    $stmt->execute();
    $stmt->bind_result($admin_email, $admin_password, $admin_id);
    if ($stmt->fetch()) {
        $_SESSION['aadmin_id'] = $admin_id;
        header("location: http://localhost/GasAgency/GasAgency/GAMS/admin/dashboard.php");
        exit;
    }
    $stmt->close();

    // Check if the database connection is working
if ($mysqli->connect_error) {
    die("Database connection failed: " . $mysqli->connect_error);
}

// Check in Customer table
    $query = "SELECT customer_email, customer_password, customer_id, outletid FROM rpos_customers WHERE customer_email = ? AND customer_password = ?";
    $stmt = $mysqli->prepare($query);

    if (!$stmt) {
        die("Prepare failed: " . $mysqli->error); // Debugging error message
    }

    $stmt->bind_param('ss', $email, $password);
    $stmt->execute();
    $stmt->bind_result($customer_email, $customer_password, $customer_id, $outletid);

    if ($stmt->fetch()) {
        $_SESSION['customer_id'] = $customer_id;
        
        // Fetch outlet details
        $stmt->close();
        $stmt = $mysqli->prepare("SELECT id, district, outlet_name FROM outlets WHERE id = ?");
        
        if (!$stmt) {
            die("Prepare failed: " . $mysqli->error);
        }
        
        $stmt->bind_param('i', $outletid);
        $stmt->execute();
        $stmt->bind_result($id, $district, $outlet_name);

        if ($stmt->fetch()) { 
            $_SESSION['district'] = $district;
            $_SESSION['outlet_name'] = $outlet_name;
            $_SESSION['outlet_id'] = $id;
        }

        header("location: http://localhost/GasAgency/GasAgency/GAMS/customer/dashboard.php");
        exit;
    }

    $stmt->close();


        // Check in outlet manager
    $stmt = $mysqli->prepare("SELECT staff_email, staff_password, staff_id FROM rpos_staff WHERE staff_email = ? AND staff_password = ?");
    $stmt->bind_param('ss', $email, $password);
    $stmt->execute();
    $stmt->bind_result($staff_email, $staff_password, $staff_id);

    if ($stmt->fetch()) {
        // Staff authenticated successfully
        $_SESSION['staff_id'] = $staff_id;

        // Close the first statement
        $stmt->close();

        // Check if the staff is an outlet manager
        $stmt = $mysqli->prepare("SELECT id,district, outlet_name FROM outlets WHERE outletmanager = ?");
        $stmt->bind_param('i', $staff_id);
        $stmt->execute();
        $stmt->bind_result( $id,$district, $outlet_name);

        if ($stmt->fetch()) {
            // Assign district and outlet_name to session variables
            $_SESSION['district'] = $district;
            $_SESSION['outlet_name'] = $outlet_name;
            $_SESSION['outlet_id'] = $id;

            // Close the second statement
            $stmt->close();

            // Redirect to the dashboard
            header("location: http://localhost/GasAgency/GasAgency/GAMS/cashier/dashboard.php");
            exit;
        } else {
            // Staff is authenticated but not assigned as an outlet manager
            $error = "You are not assigned as an outlet manager.";
        }

        // Close the second statement if no fetch occurs
        $stmt->close();
    }


    // Check in outlet Staff 
    $stmt = $mysqli->prepare("SELECT staff_email, staff_password, staff_id,district,outlet_name FROM outlet_staff WHERE staff_email = ? AND staff_password = ?");
    $stmt->bind_param('ss', $email, $password);
    $stmt->execute();
    $stmt->bind_result($staff_email, $staff_password, $staff_id, $district, $outlet_name);
    if ($stmt->fetch()) {
        $_SESSION['outlet_staff_id'] = $staff_id;
        $_SESSION['district'] = $district;
        $_SESSION['outlet_name'] = $outlet_name;

        header("location:http://localhost/GasAgency/GasAgency/GAMS/staff/dashboard.php");
        exit;
    }
    $stmt->close();

    // If no match is found
    $err = "Incorrect Authentication Credentials";
}
require_once('partials/_head.php');
?>

<body class="bg-dark">
    <div class="main-content">
        <div class="header bg-gradient-primary py-7">
            <div class="container">
                <div class="header-body text-center mb-7">
                    <div class="row justify-content-center">
                        <div class="col-lg-5 col-md-6">
                            <h1 class="text-white">GasbyGas Management</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page content -->
        <div class="container mt--8 pb-5">
            <div class="row justify-content-center">
                <div class="col-lg-5 col-md-7">
                    <div class="card bg-secondary shadow border-0">
                        <div class="card-body px-lg-5 py-lg-5">
                            <?php if (isset($err)) { ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo $err; ?>
                                </div>
                            <?php } ?>
                            <form method="post" role="form">
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                                        </div>
                                        <input 
                                            class="form-control" 
                                            required 
                                            name="email" 
                                            placeholder="Email" 
                                            type="email" 
                                            autocomplete="username"
                                        >
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                                        </div>
                                        <input 
                                            class="form-control" 
                                            required 
                                            name="password" 
                                            placeholder="Password" 
                                            type="password" 
                                            autocomplete="current-password"
                                        >
                                    </div>
                                </div>
                                <div class="custom-control custom-control-alternative custom-checkbox">
                                    <input class="custom-control-input" id="customCheckLogin" type="checkbox">
                                    <label class="custom-control-label" for="customCheckLogin">
                                        <span class="text-muted">Remember Me</span>
                                    </label>
                                </div>
                                <div class="text-center">
                                    <button type="submit" name="login" class="btn btn-primary my-4">Log In</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-6"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <?php require_once('partials/_footer.php'); ?>
    <!-- Argon Scripts -->
    <?php require_once('partials/_scripts.php'); ?>
</body>
</html>
