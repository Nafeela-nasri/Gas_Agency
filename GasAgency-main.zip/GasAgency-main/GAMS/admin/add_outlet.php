<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
include('config/code-generator.php');

check_login();

// Add Outlet
if (isset($_POST['addOutlet'])) {
    // Prevent posting blank values
    if (empty($_POST['district']) || empty($_POST['outlet_name'])) {
        $err = "Blank Values Not Accepted";
    } else {
        $district = $_POST['district'];
        $outlet_name = $_POST['outlet_name'];

        // Insert captured information into the database
        $postQuery = "INSERT INTO outlets (district, outlet_name) VALUES(?, ?)";
        $postStmt = $mysqli->prepare($postQuery);
        // Bind parameters
        $rc = $postStmt->bind_param('ss', $district, $outlet_name);
        $postStmt->execute();

        // Declare a variable which will be passed to alert function
        if ($postStmt) {
            $success = "Outlet Added" && header("refresh:1; url=outletmanagement.php");
        } else {
            $err = "Please Try Again Or Try Later";
        }
    }
}
require_once('partials/_head.php');
?>

<body>
  <!-- Sidenav -->
  <?php
  require_once('partials/_sidebar.php');
  ?>
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <?php
    require_once('partials/_topnav.php');
    ?>
    <!-- Header -->
    <div style="background-image: url(assets/img/theme/restro00.jpg); background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
      <span class="mask bg-gradient-dark opacity-8"></span>
      <div class="container-fluid">
        <div class="header-body"></div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--8">
      <div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0">
              <h3>Add New Outlet</h3>
            </div>
            <div class="card-body">
              <form method="POST">
                <div class="form-row">
                  <div class="col-md-6">
                    <label>District</label>
                    <select name="district" class="form-control">
                      <option value="" disabled selected>-- Select District --</option>
                      <option value="Colombo">Colombo</option>
                      <option value="Gampaha">Gampaha</option>
                      <option value="Kandy">Kandy</option>
                      <option value="Galle">Galle</option>
                      <option value="Jaffna">Jaffna</option>
                      <option value="Matara">Matara</option>
                      <option value="Kurunegala">Kurunegala</option>
                      <option value="Anuradhapura">Anuradhapura</option>
                      <option value="Ratnapura">Ratnapura</option>
                      <option value="Trincomalee">Trincomalee</option>
                      <option value="Hambantota">Hambantota</option>
                      <option value="Badulla">Badulla</option>
                      <option value="Batticaloa">Batticaloa</option>
                      <option value="Polonnaruwa">Polonnaruwa</option>
                      <option value="Monaragala">Monaragala</option>
                      <!-- Add more districts as needed -->
                    </select>
                  </div>
                  <div class="col-md-6">
                    <label>Outlet Name</label>
                    <input type="text" name="outlet_name" class="form-control" value="">
                  </div>
                </div>
                <br>
                <div class="form-row">
                  <div class="col-md-6">
                    <input type="submit" name="addOutlet" value="Add Outlet" class="btn btn-success">
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
      <?php
      require_once('partials/_footer.php');
      ?>
    </div>
  </div>
  <!-- Argon Scripts -->
  <?php
  require_once('partials/_scripts.php');
  ?>
</body>
</html>
